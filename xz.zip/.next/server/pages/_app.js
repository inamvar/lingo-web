(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const ClientSideRenderer = (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
        children: props.children
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(ClientSideRenderer), {
    ssr: false
}));


/***/ }),

/***/ 4859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./public/picture/eNamad.png
/* harmony default export */ const eNamad = ({"src":"/_next/static/media/eNamad.c4a71d40.png","height":150,"width":138,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAu0lEQVR42mPQCJ3GyAAEQJoLiMuBOIQBBoAcFijtAsRhQBykETaNBUjzMTAAgapfDxOQ0w/E/hqhU02AtIdG6HQpBuPQydwmEdO9dSJmztSPmhOuFzU7igEOAlZzQBiRugwOzWUMDAz8DMjgZKuhXmFhrmdDRYJ1SXGxx8wZs7Tv37vHwvBrJgPf56XOMRs274rctGl7zJYt28M3b9oSv2nDRlEGCDjGwSDUpcbA0KUMxEoMDFqsDAwMDACGCTyCTee57gAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/picture/bazaar-badge2 1.png
/* harmony default export */ const bazaar_badge2_1 = ({"src":"/_next/static/media/bazaar-badge2 1.46ecffce.png","height":52,"width":176,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR4nGO0SdP+w6N9nZnpoAeDq40bw8lTxxlu3LjJICYmxvD+/ft/jCYZRn/ean5ktr1s9d/XzY/xzLkzDFs2b2FQUVFhePPmzV8Ae2sdTBRpnzgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/picture/image_sibapp_black_badge 1.png
/* harmony default export */ const image_sibapp_black_badge_1 = ({"src":"/_next/static/media/image_sibapp_black_badge 1.2b32024c.png","height":80,"width":209,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAOklEQVR42mOwdtadYN7O0Mne6d3uMkHbmYFpsv3/ZiAs+N/4P/E/w2QGeefgCY3tzZ0lnbntoROUnAEGaBV0/laUQwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/picture/google-play-download 1.png
/* harmony default export */ const google_play_download_1 = ({"src":"/_next/static/media/google-play-download 1.04a140f7.png","height":52,"width":181,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAASklEQVR4nGNUbu/9ZfX/HuvdvqkMPKZeDJxsrAzv3r1j4OXlZXj58uVvRp+irt96f+6wbNw8i0FE3onh/78/DB8/fgQr+PTp0x8Ao/ceG75AP3cAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
// EXTERNAL MODULE: ./public/picture/Logo.png
var Logo = __webpack_require__(4598);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./common/constants.js
var constants = __webpack_require__(9642);
;// CONCATENATED MODULE: ./components/footer.jsx








function footer(siteSetting) {
    const result = siteSetting.siteSetting;
    console.log(result);
    const instagram = result?.find((x)=>x.key === constants/* Constants.InstagramAddress */.g.InstagramAddress)?.value ?? "#";
    const whatsapp = result?.find((x)=>x.key === constants/* Constants.WhatsAppAddress */.g.WhatsAppAddress)?.value ?? "#";
    const telegram = result?.find((x)=>x.key === constants/* Constants.TelegramAddress */.g.TelegramAddress)?.value ?? "#";
    const twitter = result?.find((x)=>x.key === constants/* Constants.TwitterAddress */.g.TwitterAddress)?.value ?? "#";
    const MobileAppAndroidDownloadLink = result?.find((x)=>x.key === constants/* Constants.MobileAppAndroidDownloadLink */.g.MobileAppAndroidDownloadLink)?.value ?? "#";
    const MobileAppBazarDownloadLink = result?.find((x)=>x.key === constants/* Constants.MobileAppBazarDownloadLink */.g.MobileAppBazarDownloadLink)?.value ?? "#";
    const MobileAppIOSDownloadLink = result?.find((x)=>x.key === constants/* Constants.MobileAppIOSDownloadLink */.g.MobileAppIOSDownloadLink)?.value ?? "#";
    const footerDescription = "";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "h-px my-5 sm:my-8 bg-paleBlue w-4/5 border-0"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-4 flex sm:flex-row flex-col sm:items-start items-center w-full justify-evenly gap-9 sm:gap-0 text-lg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden sm:block sm:w-1/3 mt-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col  justify-center items-center gap-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-bold darkBlue-color",
                                    children: "اطلاعات تماس"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-evenly lg:w-80 w-full justify-between",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            href: twitter,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "29",
                                                height: "23",
                                                viewBox: "0 0 39 33",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M38.9262 4.21867C37.5086 4.8458 35.991 5.27725 34.3915 5.47293C36.0235 4.48484 37.2713 2.92188 37.8663 1.05995C36.3355 1.95932 34.6421 2.61075 32.8414 2.97901C31.4058 1.42821 29.3534 0.452271 27.0759 0.452271C22.7098 0.452271 19.1712 4.02179 19.1712 8.42139C19.1712 9.05459 19.2471 9.66228 19.3784 10.2384C12.8106 9.92844 6.98841 6.74419 3.0945 1.9338C2.41038 3.1054 2.02135 4.46661 2.02135 5.94813C2.02135 8.72037 3.41969 11.1511 5.53346 12.5804C4.24111 12.5427 3.02464 12.1817 1.95872 11.5874V11.6834C1.95872 15.5495 4.68073 18.7726 8.29401 19.5067C7.63519 19.6829 6.93181 19.785 6.21758 19.785C5.71052 19.785 5.22634 19.7352 4.74336 19.6452C5.7599 22.81 8.66979 25.1144 12.1385 25.1837C9.44183 27.3166 6.02367 28.5879 2.34053 28.5879C1.71302 28.5879 1.08672 28.5575 0.458008 28.4809C3.97132 30.7415 8.11817 32.0638 12.5974 32.0638C27.1313 32.0638 35.0733 19.9163 35.0733 9.39611C35.0733 9.06067 35.0732 8.71916 35.048 8.37642C36.5981 7.26194 37.9398 5.84969 38.9997 4.24906L38.9262 4.21867Z",
                                                    fill: "#143794"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            href: whatsapp,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "29",
                                                height: "30",
                                                viewBox: "0 0 39 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M28.2915 23.598C27.8084 23.3506 25.4555 22.1893 25.0158 22.0235C24.5761 21.8651 24.2568 21.7822 23.9364 22.2709C23.6231 22.7474 22.7003 23.8381 22.4184 24.1562C22.1365 24.4743 21.8594 24.4986 21.3836 24.2829C20.9005 24.0355 19.3572 23.5273 17.5248 21.8651C16.0936 20.577 15.1406 18.9902 14.8575 18.5016C14.5756 18.019 14.8262 17.746 15.0647 17.5047C15.284 17.2829 15.5478 16.9465 15.7924 16.6541C16.0249 16.3616 16.0996 16.1654 16.2695 15.8485C16.4261 15.5061 16.3454 15.2392 16.2261 14.9979C16.1068 14.7566 15.1467 12.3643 14.7455 11.4113C14.3624 10.4657 13.9612 10.5863 13.666 10.5863C13.3902 10.5607 13.0697 10.5607 12.7504 10.5607C12.4312 10.5607 11.9095 10.6814 11.4698 11.1445C11.0301 11.6331 9.78801 12.8006 9.78801 15.1624C9.78801 17.5303 11.5072 19.8214 11.7457 20.1638C11.9903 20.4807 15.1274 25.3554 19.9403 27.4502C21.0884 27.9389 21.9799 28.2314 22.6762 28.4727C23.8243 28.8407 24.8725 28.7896 25.7001 28.6689C26.6157 28.5166 28.536 27.4941 28.9384 26.3522C29.3468 25.203 29.3468 24.2512 29.2276 24.0355C29.1083 23.8137 28.7951 23.6931 28.312 23.4774L28.2915 23.598ZM19.5632 35.569H19.5379C16.6887 35.569 13.872 34.7878 11.412 33.3279L10.8349 32.9793L4.81126 34.5661L6.43042 28.6372L6.04129 28.0279C4.45346 25.4699 3.60653 22.5183 3.60653 19.485C3.60653 10.6375 10.7663 3.42053 19.5753 3.42053C23.8424 3.42053 27.8457 5.10229 30.8576 8.14896C33.8694 11.17 35.5319 15.2197 35.5319 19.5106C35.5199 28.3521 28.3662 35.569 19.5692 35.569H19.5632ZM33.1478 5.83227C29.483 2.25182 24.664 0.227615 19.5379 0.227615C8.96518 0.227615 0.356162 8.89845 0.350139 19.5545C0.350139 22.957 1.22839 26.2767 2.91019 29.2149L0.1875 39.225L10.3651 36.5403C13.1697 38.0697 16.3261 38.8887 19.5391 38.8948H19.5451C30.1239 38.8948 38.7329 30.2239 38.7389 19.5606C38.7389 14.4007 36.7499 9.54434 33.1237 5.89443L33.1478 5.83227Z",
                                                    fill: "#143794"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            href: instagram,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "30",
                                                height: "30",
                                                viewBox: "0 0 40 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M20.0628 0.237434C14.8241 0.237434 14.1712 0.263023 12.121 0.350756C10.0624 0.453111 8.66993 0.776017 7.44126 1.25855C6.17405 1.76058 5.09474 2.4271 4.02869 3.51158C2.95541 4.58996 2.29049 5.68175 1.80143 6.96363C1.32442 8.20651 1.0052 9.61512 0.904018 11.6976C0.811265 13.7727 0.791992 14.4319 0.791992 19.7312C0.791992 25.0305 0.817288 25.691 0.904018 27.7649C1.0052 29.8412 1.32442 31.2559 1.80143 32.4988C2.29771 33.7807 2.95662 34.8725 4.02869 35.9509C5.09474 37.0365 6.17405 37.7092 7.44126 38.2039C8.66993 38.6803 10.0684 39.0093 12.121 39.1117C14.1724 39.2055 14.8241 39.225 20.0628 39.225C25.3015 39.225 25.9544 39.1994 28.0046 39.1117C30.0572 39.0093 31.4557 38.6791 32.6844 38.2039C33.9516 37.7019 35.0309 37.0353 36.097 35.9509C37.1702 34.8725 37.8352 33.7868 38.3242 32.4988C38.7952 31.2559 39.1205 29.8412 39.2216 27.7649C39.3144 25.6897 39.3337 25.0305 39.3337 19.7312C39.3337 14.4319 39.3084 13.7715 39.2216 11.6976C39.1205 9.62121 38.794 8.1992 38.3242 6.96363C37.8279 5.68175 37.169 4.58996 36.097 3.51158C35.0309 2.42588 33.9576 1.75327 32.6844 1.25855C31.4557 0.776017 30.0572 0.453111 28.0046 0.350756C25.9532 0.256931 25.3015 0.237434 20.0628 0.237434ZM20.0628 3.74675C25.2076 3.74675 25.8219 3.77234 27.8552 3.86008C29.7308 3.94903 30.7523 4.26584 31.4304 4.53391C32.3351 4.8885 32.9675 5.30767 33.6517 5.99247C34.3226 6.67119 34.737 7.31822 35.0875 8.23332C35.3525 8.91934 35.6657 9.95264 35.7537 11.8499C35.8404 13.9067 35.8657 14.5294 35.8657 19.7324C35.8657 24.9355 35.8404 25.5581 35.7464 27.615C35.6453 29.5122 35.3321 30.5455 35.0683 31.2315C34.7033 32.1467 34.2961 32.7864 33.624 33.4785C32.9458 34.1572 32.3001 34.5764 31.4027 34.931C30.733 35.199 29.697 35.5158 27.8143 35.6048C25.7701 35.6925 25.1678 35.7181 20.0098 35.7181C14.8518 35.7181 14.2507 35.6925 12.2042 35.5975C10.3286 35.4951 9.2939 35.1783 8.61573 34.9115C7.70025 34.5422 7.07266 34.1304 6.40051 33.4505C5.72233 32.7644 5.29109 32.1113 4.95863 31.2035C4.6888 30.526 4.38043 29.4781 4.28045 27.5736C4.21179 25.5301 4.17927 24.8965 4.17927 19.7032C4.17927 14.5123 4.21179 13.8775 4.28045 11.8084C4.38043 9.9039 4.6888 8.85842 4.95863 8.17849C5.29109 7.2512 5.72354 6.61757 6.40051 5.93155C7.07146 5.25284 7.70025 4.81417 8.61573 4.47055C9.2939 4.2037 10.3033 3.88688 12.1861 3.79184C14.2303 3.71751 14.8326 3.6907 19.9833 3.6907L20.0628 3.74675ZM20.0628 9.726C14.5928 9.726 10.1696 14.2065 10.1696 19.7337C10.1696 25.2669 14.5989 29.7413 20.0628 29.7413C25.5328 29.7413 29.956 25.2608 29.956 19.7337C29.956 14.2004 25.5268 9.726 20.0628 9.726ZM20.0628 26.232C16.5117 26.232 13.6388 23.3258 13.6388 19.7337C13.6388 16.1415 16.5117 13.2353 20.0628 13.2353C23.6139 13.2353 26.4868 16.1415 26.4868 19.7337C26.4868 23.3258 23.6139 26.232 20.0628 26.232ZM32.6675 9.32633C32.6675 10.6216 31.6256 11.6671 30.3511 11.6671C29.0707 11.6671 28.0371 10.6204 28.0371 9.32633C28.0371 8.03836 29.0779 6.99044 30.3511 6.99044C31.6244 6.99044 32.6675 8.03836 32.6675 9.32633Z",
                                                    fill: "#143794"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            target: "_blank",
                                            href: telegram,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "29",
                                                height: "30",
                                                viewBox: "0 0 39 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19.2708 0.237434C8.62463 0.237434 0 8.9631 0 19.7312C0 30.4993 8.62588 39.225 19.2708 39.225C29.917 39.225 38.5417 30.4993 38.5417 19.7312C38.5417 8.9631 29.9158 0.237434 19.2708 0.237434ZM28.7359 13.5926L25.573 28.6694C25.3393 29.7384 24.7102 29.9975 23.8324 29.4944L19.0147 25.9026L16.691 28.1664C16.4349 28.4254 16.2173 28.6455 15.72 28.6455L16.0619 23.6853L24.9899 15.5256C25.3791 15.1797 24.9041 14.9835 24.3907 15.3294L13.3566 22.356L8.60101 20.8543C7.56784 20.5248 7.54422 19.8092 8.81858 19.3061L27.3982 12.0582C28.261 11.7438 29.0144 12.2708 28.7347 13.5913L28.7359 13.5926Z",
                                                    fill: "#143794"
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        quality: 100,
                        className: "block sm:hidden",
                        src: Logo/* default */.Z,
                        alt: "logo"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center items-center text-center block sm:hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "darkBlue-color",
                            children: footerDescription
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-evenly block sm:hidden w-full justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "29",
                                    height: "23",
                                    viewBox: "0 0 39 33",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M38.9262 4.21867C37.5086 4.8458 35.991 5.27725 34.3915 5.47293C36.0235 4.48484 37.2713 2.92188 37.8663 1.05995C36.3355 1.95932 34.6421 2.61075 32.8414 2.97901C31.4058 1.42821 29.3534 0.452271 27.0759 0.452271C22.7098 0.452271 19.1712 4.02179 19.1712 8.42139C19.1712 9.05459 19.2471 9.66228 19.3784 10.2384C12.8106 9.92844 6.98841 6.74419 3.0945 1.9338C2.41038 3.1054 2.02135 4.46661 2.02135 5.94813C2.02135 8.72037 3.41969 11.1511 5.53346 12.5804C4.24111 12.5427 3.02464 12.1817 1.95872 11.5874V11.6834C1.95872 15.5495 4.68073 18.7726 8.29401 19.5067C7.63519 19.6829 6.93181 19.785 6.21758 19.785C5.71052 19.785 5.22634 19.7352 4.74336 19.6452C5.7599 22.81 8.66979 25.1144 12.1385 25.1837C9.44183 27.3166 6.02367 28.5879 2.34053 28.5879C1.71302 28.5879 1.08672 28.5575 0.458008 28.4809C3.97132 30.7415 8.11817 32.0638 12.5974 32.0638C27.1313 32.0638 35.0733 19.9163 35.0733 9.39611C35.0733 9.06067 35.0732 8.71916 35.048 8.37642C36.5981 7.26194 37.9398 5.84969 38.9997 4.24906L38.9262 4.21867Z",
                                        fill: "#143794"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "29",
                                    height: "30",
                                    viewBox: "0 0 39 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M28.2915 23.598C27.8084 23.3506 25.4555 22.1893 25.0158 22.0235C24.5761 21.8651 24.2568 21.7822 23.9364 22.2709C23.6231 22.7474 22.7003 23.8381 22.4184 24.1562C22.1365 24.4743 21.8594 24.4986 21.3836 24.2829C20.9005 24.0355 19.3572 23.5273 17.5248 21.8651C16.0936 20.577 15.1406 18.9902 14.8575 18.5016C14.5756 18.019 14.8262 17.746 15.0647 17.5047C15.284 17.2829 15.5478 16.9465 15.7924 16.6541C16.0249 16.3616 16.0996 16.1654 16.2695 15.8485C16.4261 15.5061 16.3454 15.2392 16.2261 14.9979C16.1068 14.7566 15.1467 12.3643 14.7455 11.4113C14.3624 10.4657 13.9612 10.5863 13.666 10.5863C13.3902 10.5607 13.0697 10.5607 12.7504 10.5607C12.4312 10.5607 11.9095 10.6814 11.4698 11.1445C11.0301 11.6331 9.78801 12.8006 9.78801 15.1624C9.78801 17.5303 11.5072 19.8214 11.7457 20.1638C11.9903 20.4807 15.1274 25.3554 19.9403 27.4502C21.0884 27.9389 21.9799 28.2314 22.6762 28.4727C23.8243 28.8407 24.8725 28.7896 25.7001 28.6689C26.6157 28.5166 28.536 27.4941 28.9384 26.3522C29.3468 25.203 29.3468 24.2512 29.2276 24.0355C29.1083 23.8137 28.7951 23.6931 28.312 23.4774L28.2915 23.598ZM19.5632 35.569H19.5379C16.6887 35.569 13.872 34.7878 11.412 33.3279L10.8349 32.9793L4.81126 34.5661L6.43042 28.6372L6.04129 28.0279C4.45346 25.4699 3.60653 22.5183 3.60653 19.485C3.60653 10.6375 10.7663 3.42053 19.5753 3.42053C23.8424 3.42053 27.8457 5.10229 30.8576 8.14896C33.8694 11.17 35.5319 15.2197 35.5319 19.5106C35.5199 28.3521 28.3662 35.569 19.5692 35.569H19.5632ZM33.1478 5.83227C29.483 2.25182 24.664 0.227615 19.5379 0.227615C8.96518 0.227615 0.356162 8.89845 0.350139 19.5545C0.350139 22.957 1.22839 26.2767 2.91019 29.2149L0.1875 39.225L10.3651 36.5403C13.1697 38.0697 16.3261 38.8887 19.5391 38.8948H19.5451C30.1239 38.8948 38.7329 30.2239 38.7389 19.5606C38.7389 14.4007 36.7499 9.54434 33.1237 5.89443L33.1478 5.83227Z",
                                        fill: "#143794"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "30",
                                    height: "30",
                                    viewBox: "0 0 40 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M20.0628 0.237434C14.8241 0.237434 14.1712 0.263023 12.121 0.350756C10.0624 0.453111 8.66993 0.776017 7.44126 1.25855C6.17405 1.76058 5.09474 2.4271 4.02869 3.51158C2.95541 4.58996 2.29049 5.68175 1.80143 6.96363C1.32442 8.20651 1.0052 9.61512 0.904018 11.6976C0.811265 13.7727 0.791992 14.4319 0.791992 19.7312C0.791992 25.0305 0.817288 25.691 0.904018 27.7649C1.0052 29.8412 1.32442 31.2559 1.80143 32.4988C2.29771 33.7807 2.95662 34.8725 4.02869 35.9509C5.09474 37.0365 6.17405 37.7092 7.44126 38.2039C8.66993 38.6803 10.0684 39.0093 12.121 39.1117C14.1724 39.2055 14.8241 39.225 20.0628 39.225C25.3015 39.225 25.9544 39.1994 28.0046 39.1117C30.0572 39.0093 31.4557 38.6791 32.6844 38.2039C33.9516 37.7019 35.0309 37.0353 36.097 35.9509C37.1702 34.8725 37.8352 33.7868 38.3242 32.4988C38.7952 31.2559 39.1205 29.8412 39.2216 27.7649C39.3144 25.6897 39.3337 25.0305 39.3337 19.7312C39.3337 14.4319 39.3084 13.7715 39.2216 11.6976C39.1205 9.62121 38.794 8.1992 38.3242 6.96363C37.8279 5.68175 37.169 4.58996 36.097 3.51158C35.0309 2.42588 33.9576 1.75327 32.6844 1.25855C31.4557 0.776017 30.0572 0.453111 28.0046 0.350756C25.9532 0.256931 25.3015 0.237434 20.0628 0.237434ZM20.0628 3.74675C25.2076 3.74675 25.8219 3.77234 27.8552 3.86008C29.7308 3.94903 30.7523 4.26584 31.4304 4.53391C32.3351 4.8885 32.9675 5.30767 33.6517 5.99247C34.3226 6.67119 34.737 7.31822 35.0875 8.23332C35.3525 8.91934 35.6657 9.95264 35.7537 11.8499C35.8404 13.9067 35.8657 14.5294 35.8657 19.7324C35.8657 24.9355 35.8404 25.5581 35.7464 27.615C35.6453 29.5122 35.3321 30.5455 35.0683 31.2315C34.7033 32.1467 34.2961 32.7864 33.624 33.4785C32.9458 34.1572 32.3001 34.5764 31.4027 34.931C30.733 35.199 29.697 35.5158 27.8143 35.6048C25.7701 35.6925 25.1678 35.7181 20.0098 35.7181C14.8518 35.7181 14.2507 35.6925 12.2042 35.5975C10.3286 35.4951 9.2939 35.1783 8.61573 34.9115C7.70025 34.5422 7.07266 34.1304 6.40051 33.4505C5.72233 32.7644 5.29109 32.1113 4.95863 31.2035C4.6888 30.526 4.38043 29.4781 4.28045 27.5736C4.21179 25.5301 4.17927 24.8965 4.17927 19.7032C4.17927 14.5123 4.21179 13.8775 4.28045 11.8084C4.38043 9.9039 4.6888 8.85842 4.95863 8.17849C5.29109 7.2512 5.72354 6.61757 6.40051 5.93155C7.07146 5.25284 7.70025 4.81417 8.61573 4.47055C9.2939 4.2037 10.3033 3.88688 12.1861 3.79184C14.2303 3.71751 14.8326 3.6907 19.9833 3.6907L20.0628 3.74675ZM20.0628 9.726C14.5928 9.726 10.1696 14.2065 10.1696 19.7337C10.1696 25.2669 14.5989 29.7413 20.0628 29.7413C25.5328 29.7413 29.956 25.2608 29.956 19.7337C29.956 14.2004 25.5268 9.726 20.0628 9.726ZM20.0628 26.232C16.5117 26.232 13.6388 23.3258 13.6388 19.7337C13.6388 16.1415 16.5117 13.2353 20.0628 13.2353C23.6139 13.2353 26.4868 16.1415 26.4868 19.7337C26.4868 23.3258 23.6139 26.232 20.0628 26.232ZM32.6675 9.32633C32.6675 10.6216 31.6256 11.6671 30.3511 11.6671C29.0707 11.6671 28.0371 10.6204 28.0371 9.32633C28.0371 8.03836 29.0779 6.99044 30.3511 6.99044C31.6244 6.99044 32.6675 8.03836 32.6675 9.32633Z",
                                        fill: "#143794"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "29",
                                    height: "30",
                                    viewBox: "0 0 39 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M19.2708 0.237434C8.62463 0.237434 0 8.9631 0 19.7312C0 30.4993 8.62588 39.225 19.2708 39.225C29.917 39.225 38.5417 30.4993 38.5417 19.7312C38.5417 8.9631 29.9158 0.237434 19.2708 0.237434ZM28.7359 13.5926L25.573 28.6694C25.3393 29.7384 24.7102 29.9975 23.8324 29.4944L19.0147 25.9026L16.691 28.1664C16.4349 28.4254 16.2173 28.6455 15.72 28.6455L16.0619 23.6853L24.9899 15.5256C25.3791 15.1797 24.9041 14.9835 24.3907 15.3294L13.3566 22.356L8.60101 20.8543C7.56784 20.5248 7.54422 19.8092 8.81858 19.3061L27.3982 12.0582C28.261 11.7438 29.0144 12.2708 28.7347 13.5913L28.7359 13.5926Z",
                                        fill: "#143794"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex w-full sm:w-1/3 flex-col gap-9 items-center justify-center lg:w-96 mt-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-bold darkBlue-color whitespace-nowrap",
                                children: "دسترسی های سریع"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row items-center gap-2 w-full justify-evenly sm:justify-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "darkBlue-color whitespace-nowrap",
                                        children: "سوالات متداول"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "darkBlue-color whitespace-nowrap",
                                        children: "نمونه پکیج"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "darkBlue-color whitespace-nowrap",
                                        children: "تخفیف"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden sm:block sm:w-1/3 sm:justify-center sm:mt-0 my-9 items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col gap-9 items-center w-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    quality: 100,
                                    alt: "enamad",
                                    src: eNamad
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-4 flex flex-col w-full justify-center items-center gap-5 sm:gap-0 sm:mt-0 mt-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-bold block sm:hidden darkBlue-color text-lg",
                        children: "دانلود اپلیکیشن"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-center items-center flex-wrap",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                target: "_blank",
                                href: MobileAppBazarDownloadLink,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    quality: 100,
                                    className: "h-3",
                                    alt: "bazaar",
                                    src: bazaar_badge2_1
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                target: "_blank",
                                href: MobileAppIOSDownloadLink,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    target: "_blank",
                                    quality: 100,
                                    alt: "applestore",
                                    src: image_sibapp_black_badge_1
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                target: "_blank",
                                href: MobileAppAndroidDownloadLink,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    quality: 100,
                                    className: "h-3",
                                    alt: "googleplay",
                                    src: google_play_download_1
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-paleBlue w-full p-4 mt-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "darkBlue-color text-center",
                    children: "\xa9 تمامی حقوق مادی و معنوی سایت متعلق به سایت لینگو می باشد."
                })
            })
        ]
    });
}


/***/ }),

/***/ 5833:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_picture_Logo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4598);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3361);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6316);
/* harmony import */ var _slidingSidebar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8513);
/* harmony import */ var _services_appServices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7512);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1599);
/* harmony import */ var _clientSideRenderer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3671);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_7__, _services_appServices__WEBPACK_IMPORTED_MODULE_9__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_10__]);
([_modal__WEBPACK_IMPORTED_MODULE_7__, _services_appServices__WEBPACK_IMPORTED_MODULE_9__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











// import {BarLoader} from "react-spinner-animated";


const Header = ()=>{
    const [result, setResult] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const authCtx = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z);
    const SignOut = async ()=>{
        await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_10__/* .logout */ .kS)();
        authCtx.setAuthState({
            authenticated: false,
            user: null
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_clientSideRenderer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-between mb-3 mt-4 lg:px-16 px-3",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "block md:hidden mt-7",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slidingSidebar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Main */ .Z.Main,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "w-32",
                            alt: "logo",
                            src: _public_picture_Logo_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "lg:w-1/3 w-1/2 xl:w-1/4 hidden md:block",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row justify-between items-center h-full xl:gap-10 whitespace-nowrap",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Main */ .Z.Main,
                                className: "darkBlue-color hover:drop-shadow-lg",
                                children: "خانه"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].FREEPACKAGE */ .Z.FREEPACKAGE,
                                className: "darkBlue-color hover:drop-shadow-lg",
                                children: "پکیج های رایگان"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].packages */ .Z.packages,
                                className: "darkBlue-color hover:drop-shadow-lg",
                                children: "پکیج های آموزشی"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Discount */ .Z.Discount,
                                className: "darkBlue-color hover:drop-shadow-lg",
                                children: "تخفیفات"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex w-1/9 justify-between gap-1 items-center md:divide-x-2 md:divide-gray-300",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                text: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                    className: "hover:drop-shadow-lg",
                                    width: "28",
                                    height: "28",
                                    viewBox: "0 0 33 33",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                            "clip-path": "url(#clip0_408_921)",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M32.5488 28.5334L26.1229 22.1074C25.8328 21.8174 25.4396 21.6562 25.0271 21.6562H23.9766C25.7555 19.3811 26.8125 16.5193 26.8125 13.4062C26.8125 6.00059 20.8119 0 13.4062 0C6.00059 0 0 6.00059 0 13.4062C0 20.8119 6.00059 26.8125 13.4062 26.8125C16.5193 26.8125 19.3811 25.7555 21.6562 23.9766V25.0271C21.6562 25.4396 21.8174 25.8328 22.1074 26.1229L28.5334 32.5488C29.1393 33.1547 30.1189 33.1547 30.7184 32.5488L32.5424 30.7248C33.1482 30.1189 33.1482 29.1393 32.5488 28.5334ZM13.4062 21.6562C8.84941 21.6562 5.15625 17.9695 5.15625 13.4062C5.15625 8.84941 8.84297 5.15625 13.4062 5.15625C17.9631 5.15625 21.6562 8.84297 21.6562 13.4062C21.6562 17.9631 17.9695 21.6562 13.4062 21.6562Z",
                                                fill: "#143794"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                                                id: "clip0_408_921",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                    width: "33",
                                                    height: "33",
                                                    fill: "white"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                result: result
                            })
                        }),
                        authCtx.authState.authenticated ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Dashboard */ .Z.Dashboard,
                                    className: "hover:drop-shadow-lg darkBlue-color px-2 hidden md:block whitespace-nowrap",
                                    children: "داشبورد من"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: SignOut,
                                    className: "bg-darkBlue hover:bg-blue-900 text-white text-center btn-page sm:w-28 hidden md:block mr-2",
                                    children: "خروج"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: SignOut,
                                    className: "md:hidden block",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        width: "34",
                                        height: "26",
                                        viewBox: "0 0 34 26",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M33.5294 14.1501L22.1955 25.5232C21.1836 26.5387 19.4295 25.8279 19.4295 24.3724V17.8735H10.2545C9.35721 17.8735 8.63535 17.1491 8.63535 16.2487V9.74982C8.63535 8.84945 9.35721 8.12509 10.2545 8.12509H19.4295V1.62617C19.4295 0.177452 21.1768 -0.540137 22.1955 0.475319L33.5294 11.8484C34.1569 12.4848 34.1569 13.5138 33.5294 14.1501ZM12.953 25.1848V22.4769C12.953 22.0301 12.5887 21.6645 12.1435 21.6645H6.47651C5.2824 21.6645 4.31767 20.6964 4.31767 19.4982V6.50036C4.31767 5.30212 5.2824 4.33405 6.47651 4.33405H12.1435C12.5887 4.33405 12.953 3.96849 12.953 3.52169V0.813805C12.953 0.367004 12.5887 0.00143983 12.1435 0.00143983H6.47651C2.90094 0.00143983 0 2.91241 0 6.50036V19.4982C0 23.0861 2.90094 25.9971 6.47651 25.9971H12.1435C12.5887 25.9971 12.953 25.6316 12.953 25.1848Z",
                                            fill: "#143794"
                                        })
                                    })
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Login */ .Z.Login,
                                    className: "hover:drop-shadow-md darkBlue-color px-2 hidden md:block whitespace-nowrap",
                                    children: "ورود کاربران"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Signup */ .Z.Signup,
                                    className: "bg-red hover:bg-red-600 text-white text-center btn-page sm:w-28 hidden md:block whitespace-nowrap mr-2",
                                    children: "ثبت نام"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8769:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4859);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5833);
/* harmony import */ var _meta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9161);
/* harmony import */ var _loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8844);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_2__]);
_header__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Layout = ({ children , siteSetting  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_meta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                title: "صفحه اصلی"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "App min-h-screen bg-page flex flex-col justify-between relative w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                                className: "h-main",
                                children: children
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                siteSetting: siteSetting
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LoadingSpinner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function LoadingSpinner() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "spinner",
        className: "spinner",
        style: {
            display: "none"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "loading-spinner"
        })
    });
}


/***/ }),

/***/ 6316:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BasicUsage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1599);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_5__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function BasicUsage(props) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    function close() {
        setData([]);
        onClose();
    }
    async function handleChange(e) {
        const resultSearch = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_5__/* .getSearchResult */ .s)(e.target.value);
        console.log(resultSearch);
        setData(resultSearch);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "p-0 bg-inherit",
                onClick: onOpen,
                children: props.text
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
                isOpen: isOpen,
                onClose: close,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "bg-white rounded-lg",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex d-rtl justify-between rounded-lg border-2 border-blue-950",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                onChange: handleChange,
                                                type: "text",
                                                className: "rounded py-4 px-3 text-black text-xs md:text-sm focus:outline-none w-3/4",
                                                placeholder: "به دنبال یادگیری چه مهارتی هستید ؟"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "m-2",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                    className: "hover:drop-shadow-lg",
                                                    width: "28",
                                                    height: "28",
                                                    viewBox: "0 0 33 33",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                                            "clip-path": "url(#clip0_408_921)",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M32.5488 28.5334L26.1229 22.1074C25.8328 21.8174 25.4396 21.6562 25.0271 21.6562H23.9766C25.7555 19.3811 26.8125 16.5193 26.8125 13.4062C26.8125 6.00059 20.8119 0 13.4062 0C6.00059 0 0 6.00059 0 13.4062C0 20.8119 6.00059 26.8125 13.4062 26.8125C16.5193 26.8125 19.3811 25.7555 21.6562 23.9766V25.0271C21.6562 25.4396 21.8174 25.8328 22.1074 26.1229L28.5334 32.5488C29.1393 33.1547 30.1189 33.1547 30.7184 32.5488L32.5424 30.7248C33.1482 30.1189 33.1482 29.1393 32.5488 28.5334ZM13.4062 21.6562C8.84941 21.6562 5.15625 17.9695 5.15625 13.4062C5.15625 8.84941 8.84297 5.15625 13.4062 5.15625C17.9631 5.15625 21.6562 8.84297 21.6562 13.4062C21.6562 17.9631 17.9695 21.6562 13.4062 21.6562Z",
                                                                fill: "#143794"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                                                                id: "clip0_408_921",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                                    width: "33",
                                                                    height: "33",
                                                                    fill: "white"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                }),
                                data.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "bg-white w-full rounded divide-gray-200 divide-y-2 flex flex-col max-h-[20rem] overflow-y-auto",
                                    children: data.map((d)=>{
                                        switch(d.productType){
                                            case "Package":
                                                if (d.firstCourseSlug != "") {
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        onClick: close,
                                                        href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].Course */ .Z.Course(d.firstCourseSlug),
                                                        className: "pt-3 pb-3 hover:bg-gray-200 hover:rounded pr-4 sm:text-sm text-xs",
                                                        children: d.title
                                                    });
                                                } else {
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        onClick: close,
                                                        href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].Package */ .Z.Package(d.slug),
                                                        className: "pt-3 pb-3 hover:bg-gray-200 hover:rounded pr-4 sm:text-sm text-xs",
                                                        children: d.title
                                                    });
                                                }
                                                break;
                                            case "Course":
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    onClick: close,
                                                    href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].Course */ .Z.Course(d.slug),
                                                    className: "pt-3 pb-3 hover:bg-gray-200 hover:rounded pr-4 sm:text-sm text-xs",
                                                    children: d.title
                                                });
                                                break;
                                            case "GoldenPackage":
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    onClick: close,
                                                    href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].GoldenPackage */ .Z.GoldenPackage,
                                                    className: "pt-3 pb-3 hover:bg-gray-200 hover:rounded pr-4 sm:text-sm text-xs",
                                                    children: d.title
                                                });
                                                break;
                                        }
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_slidingSidebar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./common/appRoutes.js
var appRoutes = __webpack_require__(1403);
;// CONCATENATED MODULE: external "react-sliding-side-panel"
const external_react_sliding_side_panel_namespaceObject = require("react-sliding-side-panel");
var external_react_sliding_side_panel_default = /*#__PURE__*/__webpack_require__.n(external_react_sliding_side_panel_namespaceObject);
// EXTERNAL MODULE: ./node_modules/react-sliding-side-panel/lib/index.css
var lib = __webpack_require__(7558);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./context/authContext.js
var authContext = __webpack_require__(3361);
;// CONCATENATED MODULE: ./components/slidingSidebar.jsx








const slidingSidebar = ()=>{
    const authCtx = (0,external_react_.useContext)(authContext/* default */.Z);
    const [openPanel, setOpenPanel] = (0,external_react_.useState)(false);
    const handleLinkClick = ()=>{
        setOpenPanel(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "mt-0.5",
                    onClick: ()=>setOpenPanel(true),
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        width: "33",
                        height: "29",
                        viewBox: "0 0 33 29",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M1.17857 5.32653H31.8214C32.4724 5.32653 33 4.79662 33 4.14286V1.18367C33 0.529916 32.4724 0 31.8214 0H1.17857C0.527632 0 0 0.529916 0 1.18367V4.14286C0 4.79662 0.527632 5.32653 1.17857 5.32653ZM1.17857 17.1633H31.8214C32.4724 17.1633 33 16.6334 33 15.9796V13.0204C33 12.3667 32.4724 11.8367 31.8214 11.8367H1.17857C0.527632 11.8367 0 12.3667 0 13.0204V15.9796C0 16.6334 0.527632 17.1633 1.17857 17.1633ZM1.17857 29H31.8214C32.4724 29 33 28.4701 33 27.8163V24.8571C33 24.2034 32.4724 23.6735 31.8214 23.6735H1.17857C0.527632 23.6735 0 24.2034 0 24.8571V27.8163C0 28.4701 0.527632 29 1.17857 29Z",
                            fill: "#143794"
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_sliding_side_panel_default()), {
                type: "right",
                isOpen: openPanel,
                size: 70,
                backdropClicked: handleLinkClick,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col h-full justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col py-7 px-8 divide-y-2 divide-gray-300",
                            children: [
                                authCtx.authState.authenticated ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col justify-center items-center gap-6 mb-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-darkBlue w-40 h-40 rounded-full justify-center items-center flex text-white",
                                            children: authCtx.authState.user.first_name + " " + authCtx.authState.user.last_name
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.Dashboard */.Z.Dashboard,
                                            className: "darkBlue-color",
                                            children: "ورود به حساب کاربری"
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    onClick: handleLinkClick,
                                    href: appRoutes/* default.Login */.Z.Login,
                                    className: "darkBlue-color py-2 w-full text-right pb-5",
                                    children: "ورود/ثبت نام"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-end mb-4 pt-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.Main */.Z.Main,
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "خانه"
                                        }),
                                        authCtx.authState.authenticated && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.MyPackages */.Z.MyPackages,
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "دوره های من"
                                        }),
                                        authCtx.authState.authenticated && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.MyTransactions */.Z.MyTransactions,
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "تراکنش های من"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.FREEPACKAGE */.Z.FREEPACKAGE,
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "پکیج های رایگان"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: appRoutes/* default.packages */.Z.packages,
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "پکیج های آموزشی"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            onClick: handleLinkClick,
                                            href: "#",
                                            className: "darkBlue-color py-2 w-full text-right",
                                            children: "تخفیف ها"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex flex-col items-end pt-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        onClick: handleLinkClick,
                                        href: "#",
                                        className: "darkBlue-color py-2 w-full text-right",
                                        children: "تماس با ما"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 bg-darkBlue",
                            onClick: ()=>setOpenPanel(false),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                width: "26",
                                height: "26",
                                viewBox: "0 0 26 26",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M26 11.375H6.22375L15.3075 2.29125L13 0L0 13L13 26L15.2913 23.7087L6.22375 14.625H26V11.375Z",
                                    fill: "#F5F5F5"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_slidingSidebar = (slidingSidebar);


/***/ }),

/***/ 7002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getAuthenticatedUser)
/* harmony export */ });
/* unused harmony export getToken */
/* harmony import */ var _common_notifier__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(643);
/* harmony import */ var _common_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9642);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9382);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_3__]);
js_cookie__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function getToken() {
    // return localStorage.getItem(Constants.token);
    return js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].get(_common_constants__WEBPACK_IMPORTED_MODULE_1__/* .Constants.token */ .g.token);
}
async function getAuthenticatedUser() {
    const defaultObject = {
        authenticated: false,
        user: null
    };
    try {
        const token = getToken();
        if (!token) {
            return defaultObject;
        } else {
            const userInfo = jwt_decode__WEBPACK_IMPORTED_MODULE_2___default()(token);
            const userObject = {
                authenticated: true,
                user: userInfo
            };
            return userObject;
        }
    } catch (error) {
        (0,_common_notifier__WEBPACK_IMPORTED_MODULE_0__/* .pushAlert */ .V)({
            type: "error",
            message: "خطایی پیش آمده"
        });
        return defaultObject;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8769);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3361);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_getUser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7002);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2210);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1599);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7544);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout__WEBPACK_IMPORTED_MODULE_2__, _hooks_getUser__WEBPACK_IMPORTED_MODULE_5__, _chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_7__]);
([_components_layout__WEBPACK_IMPORTED_MODULE_2__, _hooks_getUser__WEBPACK_IMPORTED_MODULE_5__, _chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function MyApp({ Component , pageProps , siteSetting  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const [authState, setAuthState] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        (0,_hooks_getUser__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)().then((res)=>{
            setAuthState(res);
        });
    }, [
        authState.authenticated
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const handleRouteChange = (url, { shallow  })=>{
            document.getElementById("spinner").style.display = "block";
            return;
        };
        const handleRouteComplete = (url, { shallow  })=>{
            document.getElementById("spinner").style.display = "none";
            return;
        };
        router.events.on("routeChangeStart", handleRouteChange);
        router.events.on("routeChangeComplete", handleRouteComplete);
        return ()=>{
            router.events.off("routeChangeStart", handleRouteChange);
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__.ChakraProvider, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_authContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"].Provider */ .Z.Provider, {
            value: {
                authState,
                setAuthState
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                siteSetting: siteSetting,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            })
        })
    });
}
MyApp.getInitialProps = async (appContext)=>{
    const siteSetting = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_7__/* .getSiteSetting */ .df)(appContext);
    const appProps = await next_app__WEBPACK_IMPORTED_MODULE_8___default().getInitialProps(appContext);
    return {
        ...appProps,
        siteSetting
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 9344:
/***/ ((module) => {

"use strict";
module.exports = require("jsonwebtoken");

/***/ }),

/***/ 9382:
/***/ ((module) => {

"use strict";
module.exports = require("jwt-decode");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

"use strict";
module.exports = require("sweetalert2");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = import("@chakra-ui/react");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

"use strict";
module.exports = import("js-cookie");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,664,675,604,403,85,512,161,599,621], () => (__webpack_exec__(6004)));
module.exports = __webpack_exports__;

})();