"use strict";
exports.id = 184;
exports.ids = [184];
exports.modules = {

/***/ 4184:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1599);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__]);
_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ProgressBarTimer = ({ expireTime , requestTime , onProgressFinished  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [finished, setFinished] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let currentTime = new Date().getTime();
    let expTime = new Date(expireTime).getTime();
    let reqTime = new Date(requestTime).getTime();
    let remain = expTime - currentTime;
    const [remainingTime, setRemainingTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(remain);
    const [finalProgress, setFinalProgress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(100);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setFinished(false);
        const interval = setInterval(()=>{
            setRemainingTime((prev)=>{
                let currentTime = new Date().getTime();
                let remain = expTime - currentTime;
                return remain;
            });
        }, 1000);
        return ()=>clearInterval(interval);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // console.log('remain time:'+remainingTime);
        if (remainingTime <= 0) {
            setFinished(true);
            setFinalProgress(0);
        } else {
            setFinalProgress((prev)=>{
                let vv = expTime - currentTime;
                let total = expTime - reqTime;
                let res = vv / total;
                return res;
            });
        }
    }, [
        remainingTime
    ]);
    async function handleClick() {
        const email = localStorage.getItem("ResetPassword-Key");
        const result = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__/* .postResetPasswordRequest */ .n_)(email);
        if (result != undefined && result.success) {
            localStorage.removeItem("ResetPassword-expireTime");
            localStorage.removeItem("ResetPassword-Key");
            localStorage.removeItem("ResetPassword-RequestTime");
            localStorage.setItem("ResetPassword-Key", email);
            localStorage.setItem("ResetPassword-expireTime", result.data.expirationTime);
            localStorage.setItem("ResetPassword-RequestTime", moment__WEBPACK_IMPORTED_MODULE_3___default()());
            await router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].NewPassword */ .Z.NewPassword);
            window.location.reload();
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: finished === false ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-grey rounded flex justify-end",
            style: {
                height: "10px",
                width: "100%"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-darkGreen rounded",
                style: {
                    height: "10px",
                    width: `${finalProgress * 100}%`
                }
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            onClick: handleClick,
            className: "darkBlue-color text-sm text-center cursor-pointer",
            children: "ارسال مجدد پیام"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBarTimer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;