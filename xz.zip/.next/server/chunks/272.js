"use strict";
exports.id = 272;
exports.ids = [272];
exports.modules = {

/***/ 2305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ validator)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);

// Define a reusable validation method for the gender field
// yup.addMethod(yup.string, 'selectNotNull', function (name) {
//     return this.notOneOf([null, '---انتخاب کنید ---'],`انتخاب ${name} اجباری است`)
// });
yup__WEBPACK_IMPORTED_MODULE_0__.addMethod(yup__WEBPACK_IMPORTED_MODULE_0__.string, "isMatch", function(pattern, message) {
    return this.matches(pattern, message);
});
yup__WEBPACK_IMPORTED_MODULE_0__.addMethod(yup__WEBPACK_IMPORTED_MODULE_0__.string, "isPhoneNumber", function() {
    return this.matches(/[abcdefghijklmnopqrstuvwxyz]+/, "فرمت شماره همراه وارد شده صحیح نمی باشد");
});
// Export the customized yup object with the global gender method
const validator = yup__WEBPACK_IMPORTED_MODULE_0__;


/***/ }),

/***/ 7080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const InputText = ({ name , register , placeholder , className , type , error  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-auto",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    name: name,
                    type: type,
                    className: className,
                    placeholder: placeholder,
                    ...register(name)
                }),
                error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-red-600 text-xs mt-1",
                    children: error
                })
            ]
        })
    });
};
InputText.defaultProps = {
    type: "text",
    className: "rounded w-full py-3 px-3 text-black text-sm bg-grey darkgrey-color focus:outline-none"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputText);


/***/ })

};
;