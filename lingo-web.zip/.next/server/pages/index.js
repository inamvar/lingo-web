(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/banner.f42add81.png","height":629,"width":1320,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAb0lEQVR42gFkAJv/AHY1FU48NKuemc7Mz6GSdX1sS5h0V1gDAABvCwB+d3bOy82/vcCgmZDBurWfgHhbLx8Abi8ZW0VDRERJQTs7z9Pc2tjdyLq2d3ByADoEAHhaVLGVi4ODh7m6v8O4uNbKxlNVW9YkL3PIKgqHAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 7452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ packageMultiItemCarousel)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-multi-carousel"
var external_react_multi_carousel_ = __webpack_require__(5804);
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_);
// EXTERNAL MODULE: ./node_modules/react-multi-carousel/lib/styles.css
var styles = __webpack_require__(2694);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./common/appRoutes.js
var appRoutes = __webpack_require__(1403);
;// CONCATENATED MODULE: ./components/packageCarouselItem.jsx




function PackageCarouselItem(props) {
    if (props.firstCourse != undefined && props.firstCourse != null) {
        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            className: "item-size flex justify-center",
            href: appRoutes/* default.Course */.Z.Course(props.firstCourse),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    width: "90%"
                },
                className: "flex flex-col rounded-xl bg-white p-3 w-full h-full justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            height: "80%"
                        },
                        className: "relative w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            quality: 100,
                            className: "w-full h-full rounded",
                            alt: "picture",
                            height: 900,
                            width: 900,
                            src: props.picture
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            height: "10%"
                        },
                        className: "flex justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "grey-color",
                                children: props.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "grey-color",
                                children: props.title
                            })
                        ]
                    })
                ]
            })
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            className: "item-size flex justify-center",
            href: appRoutes/* default.Package */.Z.Package(props.slug),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    width: "90%"
                },
                className: "flex flex-col rounded-xl bg-white p-3 w-full h-full justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            height: "80%"
                        },
                        className: "relative w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            quality: 100,
                            className: "w-full h-full rounded",
                            alt: "picture",
                            height: 450,
                            width: 450,
                            src: props.picture
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            height: "10%"
                        },
                        className: "flex justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "grey-color",
                                children: props.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "grey-color",
                                children: props.title
                            })
                        ]
                    })
                ]
            })
        });
    }
}

;// CONCATENATED MODULE: ./components/packageMultiItemCarousel.jsx





const PackageMultiItemCarousel = ({ packages  })=>{
    const [dragging, setDragging] = (0,external_react_.useState)(false);
    const responsive = {
        screen: {
            breakpoint: {
                max: 3000,
                min: 1700
            },
            items: 4,
            slidesToSlide: 1
        },
        desktop: {
            breakpoint: {
                max: 1700,
                min: 1300
            },
            items: 3,
            slidesToSlide: 1
        },
        tablet: {
            breakpoint: {
                max: 1300,
                min: 850
            },
            items: 2,
            slidesToSlide: 1
        },
        mobile: {
            breakpoint: {
                max: 850,
                min: 1
            },
            items: 1,
            slidesToSlide: 1
        }
    };
    const handleDragStart = ()=>{
        setDragging(true);
    };
    const handleDragEnd = ()=>{
        setDragging(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_multi_carousel_default()), {
        className: "flex flex-row",
        swipeable: true,
        draggable: false,
        showDots: false,
        responsive: responsive,
        ssr: true,
        infinite: true,
        autoPlay: false,
        keyBoardControl: true,
        customTransition: "transform 600ms ease-in-out",
        transitionDuration: 600,
        containerClass: "carousel-container",
        // removeArrowOnDeviceType={["tablet", "mobile"]}
        itemClass: "multi-pack-item",
        children: packages.map((i)=>/*#__PURE__*/ jsx_runtime_.jsx(PackageCarouselItem, {
                firstCourse: i.firstCourseSlug,
                id: i.id,
                name: i.name,
                title: i.title,
                picture: i.thumbnailUrl,
                slug: i.slug
            }))
    });
};
/* harmony default export */ const packageMultiItemCarousel = (PackageMultiItemCarousel);


/***/ }),

/***/ 7631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useScript = (url)=>{
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = url;
        script.async = true;
        document.body.appendChild(script);
        return ()=>{
            document.body.removeChild(script);
        };
    }, [
        url
    ]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScript);


/***/ }),

/***/ 6616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_picture_banner_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8395);
/* harmony import */ var _public_picture_Logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4598);
/* harmony import */ var _services_appServices__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7512);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3361);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_packageMultiItemCarousel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7452);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_useScript__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_appServices__WEBPACK_IMPORTED_MODULE_4__]);
_services_appServices__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const Home = (props)=>{
    const authCtx = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
    const Packages = props.packages;
    const banner = props.banner;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full flex items-center justify-center relative overflow-hidden m-h-50",
                children: [
                    banner != null && banner.length >= 1 && banner != undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                        className: "vid-div-banner",
                        src: banner[0].fileUrl,
                        autoPlay: true,
                        loop: true,
                        muted: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                            src: banner[0].fileUrl
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        quality: 100,
                        className: "w-full vid-div-banner",
                        alt: "picture",
                        src: _public_picture_banner_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "w-full div-banner object-center bg-darkBlue opacity-60 absolute"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "div-v-banner w-11/12 sm:w-1/2 bg-white flex-col opacity-80 pb-5 md:pt-10 md:pb-20 sm:pb-20 gap-5 rounded",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                quality: 100,
                                className: "w-32 md:w-56",
                                src: _public_picture_Logo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                alt: "logo"
                            }),
                            authCtx.authState.authenticated ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "darkBlue-color",
                                children: [
                                    "کاربر ",
                                    authCtx.authState.user.first_name + " " + authCtx.authState.user.last_name,
                                    " عزیز، خوش آمدید."
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "darkBlue-color",
                                children: " خوش آمدید."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col justify-center gap-9 items-center px-5 mt-9",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-2xl font-bold darkBlue-color",
                        children: "پکیج ها"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_packageMultiItemCarousel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                packages: Packages
            })
        ]
    });
};
async function getServerSideProps(context) {
    const packages = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_4__/* .getPackagesList */ .sf)(context);
    const banner = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_4__/* .getBanner */ .Eg)(context);
    return {
        props: {
            packages,
            banner
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2694:
/***/ (() => {



/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 3053:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5804:
/***/ ((module) => {

"use strict";
module.exports = require("react-multi-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

"use strict";
module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,664,675,403,85,512,621], () => (__webpack_exec__(6616)));
module.exports = __webpack_exports__;

})();