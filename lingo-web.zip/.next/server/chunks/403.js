"use strict";
exports.id = 403;
exports.ids = [403];
exports.modules = {

/***/ 1403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const AppRoutes = {
    Signup: "/auth/signup",
    SignupReturn: (url)=>{
        return `/auth/signup?returnUrl=${url}`;
    },
    Login: "/auth/login",
    LoginReturn: (url)=>{
        return `/auth/login?returnUrl=${url}`;
    },
    Main: "/",
    Profile: "/dashboard/myProfile",
    Dashboard: "/dashboard",
    Package: (slug)=>{
        return `/package/${slug}`;
    },
    Course: (slug)=>{
        return `/package/course/${slug}`;
    },
    DetailCourse: "/package/course/courseEpisodes",
    Video: (slug)=>{
        return `/package/course/courseEpisodes/${slug}`;
    },
    Cart: "/dashboard/cart",
    MyPackages: "/dashboard/myPackages",
    MyProfile: "/dashboard/myProfile",
    MyTransactions: "/dashboard/myTransactions",
    FREEPACKAGE: "/freePackage",
    packages: "/packages",
    Discount: "/discount",
    GoldenPackage: "/goldenPackage",
    PaymentDetail: (slug)=>{
        return `/coursePaymentDetail/${slug}`;
    },
    ChangePassword: "/dashboard/changePassword",
    SendMessages: "/dashboard/myMessages/sendMessages",
    NewMessage: "/dashboard/myMessages/newMessage",
    DetailMessage: (id)=>{
        return `/dashboard/myMessages/sendMessages/${id}`;
    },
    ForgetPassword: "/auth/forgetPassword",
    NewPassword: "/auth/forgetPassword/newPassword"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppRoutes);


/***/ })

};
;