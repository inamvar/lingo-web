(() => {
var exports = {};
exports.id = 814;
exports.ids = [814];
exports.modules = {

/***/ 6166:
/***/ (() => {

throw new Error("Module build failed (from ./node_modules/next/dist/build/webpack/loaders/next-swc-loader.js):\nError: \n  \u001b[38;2;255;30;30m×\u001b[0m Expected '}', got ';'\n    ╭─[\u001b[38;2;92;157;255;1;4mD:\\Projects\\lingo-web\\pages\\package\\course\\courseEpisodes\\[...slug].jsx\u001b[0m:50:1]\n \u001b[2m50\u001b[0m │             </div>\n \u001b[2m51\u001b[0m │             <script>\n \u001b[2m52\u001b[0m │                 setTimeout(function() {\n \u001b[2m53\u001b[0m │                 window.message = [\"DEMO\", \"Negavid\", \"0990993888\", \"negavid@gmail.com\", \"#fff\", \"3\"];\n    · \u001b[38;2;246;87;248m                                                                                                    ─\u001b[0m\n \u001b[2m54\u001b[0m │             }, 1);\n \u001b[2m55\u001b[0m │             </script>\n \u001b[2m56\u001b[0m │             <script src=\"https://negavid.com/uploads/native/dynamic-watermark/latest/negavid-dynamic-watermark-production-min.js\"></script>\n    ╰────\n\n\nCaused by:\n    Syntax Error");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6166));
module.exports = __webpack_exports__;

})();