"use strict";
(() => {
var exports = {};
exports.id = 154;
exports.ids = [154];
exports.modules = {

/***/ 4184:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1599);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__]);
_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ProgressBarTimer = ({ expireTime , requestTime , onProgressFinished  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [finished, setFinished] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let currentTime = new Date().getTime();
    let expTime = new Date(expireTime).getTime();
    let reqTime = new Date(requestTime).getTime();
    let remain = expTime - currentTime;
    const [remainingTime, setRemainingTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(remain);
    const [finalProgress, setFinalProgress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(100);
    console.log(`${finalProgress * 100}%`);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setFinished(false);
        const interval = setInterval(()=>{
            setRemainingTime((prev)=>{
                let currentTime = new Date().getTime();
                let remain = expTime - currentTime;
                return remain;
            });
        }, 1000);
        return ()=>clearInterval(interval);
    }, []);
    console.log(remainingTime);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // console.log('remain time:'+remainingTime);
        if (remainingTime <= 0) {
            setFinished(true);
            setFinalProgress(0);
        } else {
            setFinalProgress((prev)=>{
                let vv = expTime - currentTime;
                let total = expTime - reqTime;
                let res = vv / total;
                return res;
            });
        }
    }, [
        remainingTime
    ]);
    async function handleClick() {
        const email = localStorage.getItem("ResetPassword-Key");
        const result = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__/* .postResetPasswordRequest */ .n_)(email);
        if (result != undefined && result.success) {
            localStorage.removeItem("ResetPassword-expireTime");
            localStorage.removeItem("ResetPassword-Key");
            localStorage.removeItem("ResetPassword-RequestTime");
            localStorage.setItem("ResetPassword-Key", email);
            localStorage.setItem("ResetPassword-expireTime", result.data.expirationTime);
            localStorage.setItem("ResetPassword-RequestTime", moment__WEBPACK_IMPORTED_MODULE_3___default()());
            await router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].NewPassword */ .Z.NewPassword);
            window.location.reload();
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: finished === false ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-grey rounded flex justify-end",
            style: {
                height: "10px",
                width: "100%"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-darkGreen rounded",
                style: {
                    height: "10px",
                    width: `${finalProgress * 100}%`
                }
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            onClick: handleClick,
            className: "darkBlue-color text-sm text-center cursor-pointer",
            children: "ارسال مجدد پیام"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBarTimer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3008:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ NewPassword)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_meta__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9161);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1403);
/* harmony import */ var _components_form_inputs_InputText__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7080);
/* harmony import */ var _common_validator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2305);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1908);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1599);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_progressTimer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4184);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__, _components_progressTimer__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__, _components_progressTimer__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function NewPassword() {
    const [requestExpTime, setRequestExpTime] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const [requestTime, setRequestTime] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(null);
    const [progressFinished, setProgressFinished] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const handleProgressFinished = ()=>{
        setProgressFinished(true);
        setProgressFinished(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        if (true) return;
        const expireTime = localStorage.getItem("ResetPassword-expireTime");
        const reqTime = localStorage.getItem("ResetPassword-RequestTime");
        setRequestExpTime(expireTime);
        setRequestTime(reqTime);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        if (requestExpTime === null) {
            next_router__WEBPACK_IMPORTED_MODULE_9__.router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].ForgetPassword */ .Z.ForgetPassword);
        }
    }, [
        requestExpTime
    ]);
    const schema = _common_validator__WEBPACK_IMPORTED_MODULE_5__/* .validator.object */ .s.object({
        securityCode: _common_validator__WEBPACK_IMPORTED_MODULE_5__/* .validator.string */ .s.string().required("نوشتن کد تایید اجباری است"),
        NewPass: _common_validator__WEBPACK_IMPORTED_MODULE_5__/* .validator.string */ .s.string().required("نوشتن  رمز عبور اجباری است"),
        RetryNewPass: _common_validator__WEBPACK_IMPORTED_MODULE_5__/* .validator.string */ .s.string().required("نوشتن تکرار رمز عبور اجباری است")
    });
    const { register , handleSubmit , watch , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(schema)
    });
    const onSubmit = async (data)=>{
        const email = localStorage.getItem("ResetPassword-Key");
        const result = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_8__/* .postResetPassword */ .PQ)(data.securityCode, data.NewPass, data.RetryNewPass, email);
        if (result) {
            next_router__WEBPACK_IMPORTED_MODULE_9__.router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].Login */ .Z.Login);
        }
    };
    if (requestExpTime === undefined) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    } else {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_meta__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    title: "فراموشی رمز"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col w-full items-center mt-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex flex-row w-5/6 sm:w-96",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full p-5 bg-white rounded-tr-lg rounded-tl-lg bg-darkBlue text-white text-sm text-center font-bold",
                                children: "تغییر رمز عبور"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            onSubmit: handleSubmit(onSubmit),
                            className: "flex flex-col p-5 bg-white rounded w-5/6 sm:w-96 gap-7",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-sm darkBlue-color text-center",
                                    children: "لطفا برای تغییر رمز عبور اطلاعات زیر را تکمیل کنید "
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col gap-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_form_inputs_InputText__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            error: errors.securityCode?.message,
                                            required: true,
                                            register: register,
                                            placeholder: "کد تایید",
                                            name: "securityCode"
                                        }),
                                        !progressFinished && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_progressTimer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            expireTime: requestExpTime,
                                            requestTime: requestTime,
                                            onProgressFinished: handleProgressFinished
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_form_inputs_InputText__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            error: errors.NewPass?.message,
                                            type: "password",
                                            required: true,
                                            register: register,
                                            placeholder: "رمز عبور",
                                            name: "NewPass"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_form_inputs_InputText__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            error: errors.RetryNewPass?.message,
                                            type: "password",
                                            required: true,
                                            register: register,
                                            placeholder: "تکرار رمز عبور",
                                            name: "RetryNewPass"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-row justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "submit",
                                        className: "bg-cyan-500 p-1 text-sm btn-page bg-red text-white w-full hover:bg-red-600",
                                        children: "تغییر رمز عبور"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,664,403,85,161,599,272], () => (__webpack_exec__(3008)));
module.exports = __webpack_exports__;

})();