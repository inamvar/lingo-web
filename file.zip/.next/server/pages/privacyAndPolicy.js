"use strict";
(() => {
var exports = {};
exports.id = 178;
exports.ids = [178];
exports.modules = {

/***/ 7826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ privacyAndPolicy)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function privacyAndPolicy() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col justify-center items-center relative z-[1] mt-16 gap-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lable", {
                        className: "font-bold text-white text-xl text-center",
                        children: "راهنمای خرید، قوانین و مقررات ، شرایط استرداد"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col leading-8 gap-5 bg-white lg:w-[60rem] w-11/12 p-8",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lable", {
                                className: "grey-color",
                                children: "برای تهیه پکیج های آموزشی لینگو4030 ابتدا می‌بایست از قسمت منوی عضویت ، عضو‌ شوید و برای احراز هویت شماره تلفن همراه خود را وارد نمایید، پس از انتخاب پکیج آموزشی و مطالعه توضیحات و شرایط آن، اقدام به خرید نمایید. پس از خرید، محصول در پروفایل شما قرار خواهد گرفت و‌ از طریق منوی \xab دوره های من \xbbبه آنها دسترسی پیدا کنید."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "font-bold darkBlue-color",
                                children: "شرایط ارسال: "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lable", {
                                className: "grey-color",
                                children: "محصولات وبسایت بدون نیاز به ارسال میباشد و از طریق پروفایل کاربری در اختیار شما قرار خواهد گرفت."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "font-bold darkBlue-color",
                                children: "شرایط استرداد: "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lable", {
                                className: "grey-color",
                                children: "‌با توجه به آنلاین بودن محصولات مشمول حق کپی رایت شده و تماشای محصولات بصورت فردی است. همچنین با توجه به اینکه تعدادی از دروس هر محصول، قبل از خرید و بصورت رایگان در اختیار شما می‌باشد، لذا امکان استرداد برای محصولات وجود نخواهد داشت. در صورت نیاز به اطلاعات بیشتر می‌توانید از طریق پشتیبانی با کارشناسان ما در ارتباط باشید."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "font-bold darkBlue-color",
                                children: "مدت زمان استفاده از ویدیو: "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lable", {
                                className: "grey-color",
                                children: "مدت زمان استفاده از پکیج های آموزشی خریداری شده برای کاربران به صورت مادام العمر می باشد."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-darkBlue w-full h-[30rem] absolute top-0 z-[0]"
            })
        ]
    });
}


/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7826));
module.exports = __webpack_exports__;

})();