"use strict";
(() => {
var exports = {};
exports.id = 814;
exports.ids = [814];
exports.modules = {

/***/ 7926:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/black.17db5545.jpg","height":618,"width":1028,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAjIP/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oACAEBAAE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const authContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authContext);


/***/ }),

/***/ 6166:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1403);
/* harmony import */ var _components_accordion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5869);
/* harmony import */ var _services_appServices__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7512);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3361);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _public_picture_black_jpg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_accordion__WEBPACK_IMPORTED_MODULE_2__, _services_appServices__WEBPACK_IMPORTED_MODULE_3__]);
([_components_accordion__WEBPACK_IMPORTED_MODULE_2__, _services_appServices__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Slug = (props)=>{
    const result = props.result;
    const currentVideo = result.currentVideo;
    const [videoPayerExist, setVideoPlayerExist] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const isNavigatedByLink = router.asPath !== router.pathname;
    const authCtx = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z);
    if (isNavigatedByLink) {
        console.log("User arrived via link");
    } else {
        console.log("User did not arrive via link");
    }
    const [video, setVideo] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(currentVideo);
    console.log(video);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const hasSession = sessionStorage.getItem("reloadVideo");
        if (hasSession) {
            sessionStorage.removeItem("reloadVideo");
            window.location.reload();
        }
        setVideoPlayerExist(true);
    }, [
        currentVideo.id
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        // Create the video div element
        const videoDiv = document.getElementById("videoPlayerTag");
        if (videoDiv == null) {
            return;
        } else if (videoPayerExist === true) {
            if (authCtx.authState != null && authCtx.authState != undefined) {
                const script = document.createElement("script");
                script.src = "https://negavid.com/uploads/native/dynamic-watermark/latest/negavid-dynamic-watermark-production-min.js";
                script.async = true;
                videoDiv.innerHTML = currentVideo.embedPlayer;
                const existingScript = document.querySelector(`script[src="${script.src}"]`);
                if (existingScript) {
                    return;
                }
                // Load the script asynchronously
                document.body.appendChild(script);
                let key = "test";
                // Define the window.message variable after the script has loaded
                if (authCtx.authState.authenticated == true) {
                    key = authCtx.authState.user.phone_number;
                }
                script.onload = ()=>{
                    setTimeout(function() {
                        window.message = [
                            "",
                            key,
                            "",
                            "",
                            "#fff",
                            "3"
                        ];
                    }, 1);
                // window.message = [null,key, key, key, "#fff", "2"];
                };
            }
        }
    // Cleanup function to remove the video div when the component unmounts
    }, [
        videoPayerExist,
        authCtx.authState
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center items-center mt-16",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col md:flex-row gap-5 px-0 md:p-3 justify-center items-center md:items-start w-full lg:w-10/12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-11/12 md:w-1/3 order-last md:order-first",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_accordion__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        chapters: result.chapters
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full md:w-2/3 flex order-first md:order-last flex-col gap-5 rounded-none",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    src: _public_picture_black_jpg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                    className: "z-0 absolute",
                                    alt: ""
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "videoPlayerTag",
                                    className: "video-div rounded-none bg-black"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col gap-4 px-6 md:px-0 w-full",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "font-bold text-lg",
                                    children: currentVideo.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "leading-8",
                                    dangerouslySetInnerHTML: {
                                        __html: currentVideo.description
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col sm:flex-row gap-3",
                                    children: [
                                        currentVideo.examFileName != null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex gap-2 w-1/3 lg:w-1/4 items-center",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        width: "25",
                                                        height: "25",
                                                        viewBox: "0 0 42 42",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M17.7188 0H24.2812C25.3723 0 26.25 0.877734 26.25 1.96875V15.75H33.4441C34.9043 15.75 35.6344 17.5137 34.6008 18.5473L22.1238 31.0324C21.5086 31.6477 20.4996 31.6477 19.8844 31.0324L7.39102 18.5473C6.35742 17.5137 7.0875 15.75 8.54766 15.75H15.75V1.96875C15.75 0.877734 16.6277 0 17.7188 0ZM42 30.8438V40.0312C42 41.1223 41.1223 42 40.0312 42H1.96875C0.877734 42 0 41.1223 0 40.0312V30.8438C0 29.7527 0.877734 28.875 1.96875 28.875H14.0027L18.0223 32.8945C19.6711 34.5434 22.3289 34.5434 23.9777 32.8945L27.9973 28.875H40.0312C41.1223 28.875 42 29.7527 42 30.8438ZM31.8281 38.0625C31.8281 37.1602 31.0898 36.4219 30.1875 36.4219C29.2852 36.4219 28.5469 37.1602 28.5469 38.0625C28.5469 38.9648 29.2852 39.7031 30.1875 39.7031C31.0898 39.7031 31.8281 38.9648 31.8281 38.0625ZM37.0781 38.0625C37.0781 37.1602 36.3398 36.4219 35.4375 36.4219C34.5352 36.4219 33.7969 37.1602 33.7969 38.0625C33.7969 38.9648 34.5352 39.7031 35.4375 39.7031C36.3398 39.7031 37.0781 38.9648 37.0781 38.0625Z",
                                                            fill: "#F84C4D"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "darkBlue-color whitespace-nowrap lg:text-base text-sm",
                                                        href: currentVideo.examFileUrl,
                                                        children: "فایل ضمیمه دانلود"
                                                    })
                                                ]
                                            })
                                        }),
                                        currentVideo.podcastEmbedPlayer != null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex lg:w-3/4 w-full sm:w-8/12 h-[4rem] relative overflow-hidden",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full top-[-9rem] absolute",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "rounded-none w-full",
                                                    dangerouslySetInnerHTML: {
                                                        __html: currentVideo.podcastEmbedPlayer
                                                    }
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center items-center mt-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: _common_appRoutes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].Course */ .Z.Course(result.slug),
                                className: "bg-red btn-page hover:bg-red-600 text-white text-center w-fit hidden md:block",
                                children: "بازکشت به صفحه ی خرید دوره"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
async function getServerSideProps(ctx) {
    const res = ctx.query.slug;
    const slug = `${res[0]}/${res[1]}`;
    const result = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_3__/* .getVideoDetail */ .O2)(slug, ctx);
    return {
        props: {
            result
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slug);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 2210:
/***/ ((module) => {

module.exports = import("@chakra-ui/react");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,664,675,403,85,512,869], () => (__webpack_exec__(6166)));
module.exports = __webpack_exports__;

})();