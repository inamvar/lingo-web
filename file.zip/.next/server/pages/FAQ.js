"use strict";
(() => {
var exports = {};
exports.id = 210;
exports.ids = [210];
exports.modules = {

/***/ 764:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ accordion)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__]);
_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function accordion() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Accordion, {
            allowToggle: true,
            className: "flex flex-col gap-2",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "راهنمای خرید، قوانین و مقررات ، شرایط استرداد"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "برای تهیه پکیج های آموزشی لینگو4030 ابتدا می‌بایست از قسمت منوی عضویت ، عضو‌ شوید و برای احراز هویت شماره تلفن همراه خود را وارد نمایید، پس از انتخاب پکیج آموزشی و مطالعه توضیحات و شرایط آن، اقدام به خرید نمایید. پس از خرید، محصول در پروفایل شما قرار خواهد گرفت و‌ از طریق منوی \xab دوره های من \xbbبه آنها دسترسی پیدا کنید.",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "شرایط ارسال : محصولات وبسایت بدون نیاز به ارسال میباشد و از طریق پروفایل کاربری در اختیار شما قرار خواهد گرفت.",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "شرایط استرداد: ‌با توجه به آنلاین بودن محصولات مشمول حق کپی رایت شده و تماشای محصولات بصورت فردی است. همچنین با توجه به اینکه تعدادی از دروس هر محصول، قبل از خرید و بصورت رایگان در اختیار شما می‌باشد، لذا امکان استرداد برای محصولات وجود نخواهد داشت. در صورت نیاز به اطلاعات بیشتر می‌توانید از طریق پشتیبانی با کارشناسان ما در ارتباط باشید.",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "مدت زمان استفاده از ویدیو: مدت زمان استفاده از پکیج های آموزشی خریداری شده برای کاربران به صورت مادام العمر می باشد."
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "چگونه ثبت ‌نام کنم؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "برای تهیه پکیج های آموزشی لینگو4030 ابتدا می‌بایست از قسمت منوی عضویت ، عضو‌ شوید و برای احراز هویت شماره تلفن همراه خود را وارد نمایید، پس از انتخاب پکیج آموزشی و مطالعه توضیحات و شرایط آن، اقدام به خرید نمایید. نحوه ی دسترسی به محصولات آموزشی از چه طریقی است؟ از طریق سایت مجموعه (LINGO4030.COM) شما می توانید از طریق اپلیکیشن های موبایل برای گوشی های اندروید و I.O.S نیز به محصولات دسترسی پیدا کنید."
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "اگر بخواهم از پایه شروع کنم آیا باید تعیین سطح شوم؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "خیر، نیازی نیست. شما می توانید بدون پیشینه آموزش زبان، یادگیری خود را شروع کنید. از اینرو برای افراد مبتدی، ما کتاب speak now1 و مجموعه lingo1 را تهیه کردیم."
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "برای تحصیل در دوره‌ی بزرگسالان چه کتاب‌هایی باید تهیه کنم؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "PDF کتاب برای تمامی دوره هایی که از روی کتاب تدریس شده است، بعد از خرید دوره برای شما قابل دانلود می باشد."
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "نحوه‌ی سطح‌بندی سیستم LINGO4030 چگونه است؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "از A1 تا C2"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "هدف از یادگیری/آموزش چیست؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "هدف نهایی در دوره‌های نوجوانان لینگو4030، تربیت زبان‌آموزانی است که روان و صحیح، انگلیسی صحبت می‌کنند و می‌توانند از دانسته‌های خود به بهترین شکل برای ساختن جملات انگلیسی و برقراری ارتباط در موقعیت‌های مختلف استفاده نمایند. مهمترین ویژگی بعد از تمرین دوره‌ها، توانایی آن‌ها در شرکت در مکالمات روزمره انگلیسی بدون مشکل و استرس است"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "فرزند من از چه سنی می تواند در این دوره‌ها شرکت کند؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7 ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "دوره آموزش مکالمه نوجوانان لینگو4030 مخصوص رده سنی 8 تا 14 سال است."
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "چگونه می‌توانم فرزندم را آنلاین ثبت ‌نام کنم؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "برای تهیه پکیج های آموزشی لینگو4030 ابتدا می‌بایست از قسمت منوی عضویت ، عضو‌ شوید و برای احراز هویت شماره تلفن همراه خود را وارد نمایید، پس از انتخاب پکیج آموزشی و مطالعه توضیحات و شرایط آن، اقدام به خرید نمایید. سیستم آموزشی در این گروه سنی بسیار پویا و به‌روز بوده و از اساتید مجربی بهره می‌برد که کلاس‌های ویژه‌ی آموزش و کار با کودکان را فراگرفته‌اند و مسئولیت برگزاری این کلاس‌ها را دارند."
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                    className: "hover:bg-blue-900 bg-darkBlue rounded",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                className: "bg-darkBlue hover:bg-darkBlue rounded text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        as: "span",
                                        flex: "1",
                                        textAlign: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-md font-bold",
                                            children: "بعد از دیدن ویدیوها و تمرین آن در منزل چه اتفاقاتی می‌افتد؟"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                className: "bg-white text-darkBlue rounded leading-7 ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "عموما در ویدیئوها کودکان به شکل بازی و سرگرمی، سرود و نمایش به این رده ی سنی ارائه می‌شود."
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5311:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FAQ)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_FAQAccordion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(764);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_FAQAccordion__WEBPACK_IMPORTED_MODULE_1__]);
_components_FAQAccordion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function FAQ() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col mt-16 lg:w-[90rem] w-full p-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "whitespace-nowrap font-bold text-lg sm:text-xl whitespace-pre-wrap darkBlue-color",
                    children: " سوالات متداول"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex w-full mt-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:w-1/2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FAQAccordion__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-1/2 flex justify-center hidden md:block",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                className: "w-full",
                                width: "532",
                                height: "504",
                                viewBox: "0 0 532 504",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M55 301.93L63.65 296.33C63.65 296.33 67.85 274.02 64.73 254.33C60.35 226.55 41.47 217 34.61 219.74C27.75 222.48 26.13 230.74 38.52 246.74C45.83 256.2 55.23 276.19 55 301.93Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                        opacity: "0.3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M55 301.93L63.65 296.33C63.65 296.33 67.85 274.02 64.73 254.33C60.35 226.55 41.47 217 34.61 219.74C27.75 222.48 26.13 230.74 38.52 246.74C45.83 256.2 55.23 276.19 55 301.93Z",
                                            fill: "white"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M58.15 290.92H58.06C57.8979 290.895 57.7519 290.808 57.653 290.678C57.554 290.547 57.5099 290.383 57.53 290.22C61.12 264.22 50.68 235.8 38.94 224.33C38.822 224.215 38.7546 224.057 38.7527 223.892C38.7509 223.727 38.8146 223.568 38.93 223.45C39.0453 223.332 39.2029 223.265 39.3679 223.263C39.5329 223.261 39.692 223.325 39.81 223.44C51.76 235.11 62.4 264 58.76 290.38C58.7407 290.528 58.6682 290.665 58.5561 290.764C58.444 290.864 58.2997 290.919 58.15 290.92Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M33.22 316C31.92 316.74 28.22 313.89 27.22 313.2C25.4637 312.003 24.0449 310.374 23.1 308.47C22.0456 306.298 21.696 303.851 22.1 301.47C22.308 300.215 22.602 298.975 22.98 297.76C23.33 296.56 23.67 295.36 23.98 294.16C24.4006 292.999 24.5776 291.763 24.5 290.53C24.19 288.07 22 286.35 20.02 284.86C17.82 283.22 15.54 281.05 15.55 278.09C15.7076 275.791 16.6259 273.61 18.16 271.89C19.58 270.09 21.26 268.51 22.54 266.61C23.5477 265.292 24.0735 263.669 24.03 262.01C23.8922 260.996 23.5522 260.02 23.03 259.14C22.03 257.21 20.61 255.44 19.89 253.37C19.17 251.3 19.27 248.72 20.89 247.24C22.21 246.02 24.19 245.85 25.98 245.97C27.6625 246.176 29.28 246.746 30.72 247.64C35.42 250.25 38.11 255.82 43.1 257.83C45.0667 258.45 47.0707 258.944 49.1 259.31C51.1 259.84 53.15 260.87 54.1 262.72C55.93 266.38 52.53 270.89 53.82 274.77C54.96 278.21 58.3 279.52 60.17 282.62C60.9343 283.988 61.2426 285.565 61.05 287.12C60.8868 289.748 60.2428 292.324 59.15 294.72C57.9162 297.206 56.5302 299.614 55 301.93L33.22 316Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                        opacity: "0.65",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M33.22 316C31.92 316.74 28.22 313.89 27.22 313.2C25.4637 312.003 24.0449 310.374 23.1 308.47C22.0456 306.298 21.696 303.851 22.1 301.47C22.308 300.215 22.602 298.975 22.98 297.76C23.33 296.56 23.67 295.36 23.98 294.16C24.4006 292.999 24.5776 291.763 24.5 290.53C24.19 288.07 22 286.35 20.02 284.86C17.82 283.22 15.54 281.05 15.55 278.09C15.7076 275.791 16.6259 273.61 18.16 271.89C19.58 270.09 21.26 268.51 22.54 266.61C23.5477 265.292 24.0735 263.669 24.03 262.01C23.8922 260.996 23.5522 260.02 23.03 259.14C22.03 257.21 20.61 255.44 19.89 253.37C19.17 251.3 19.27 248.72 20.89 247.24C22.21 246.02 24.19 245.85 25.98 245.97C27.6625 246.176 29.28 246.746 30.72 247.64C35.42 250.25 38.11 255.82 43.1 257.83C45.0667 258.45 47.0707 258.944 49.1 259.31C51.1 259.84 53.15 260.87 54.1 262.72C55.93 266.38 52.53 270.89 53.82 274.77C54.96 278.21 58.3 279.52 60.17 282.62C60.9343 283.988 61.2426 285.565 61.05 287.12C60.8868 289.748 60.2428 292.324 59.15 294.72C57.9162 297.206 56.5302 299.614 55 301.93L33.22 316Z",
                                            fill: "white"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M45.78 308.64C45.7029 308.637 45.6272 308.62 45.5571 308.587C45.487 308.555 45.4241 308.509 45.3719 308.452C45.3198 308.396 45.2795 308.329 45.2534 308.257C45.2273 308.184 45.216 308.107 45.22 308.03C46.22 284.79 35.22 259.12 27.22 251.67C27.1227 251.56 27.0697 251.418 27.0715 251.271C27.0732 251.125 27.1295 250.984 27.2294 250.877C27.3293 250.769 27.4657 250.703 27.6118 250.691C27.758 250.678 27.9035 250.721 28.02 250.81C36.14 258.42 47.32 284.51 46.34 308.08C46.3327 308.226 46.2714 308.364 46.1679 308.468C46.0644 308.571 45.9262 308.633 45.78 308.64Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M42 280.23H41.83C36.3356 278.709 30.6928 277.787 25 277.48C24.9229 277.477 24.8472 277.46 24.7771 277.427C24.707 277.395 24.6441 277.349 24.592 277.293C24.5398 277.236 24.4995 277.169 24.4734 277.097C24.4473 277.024 24.436 276.947 24.44 276.87C24.4412 276.793 24.4581 276.716 24.4898 276.645C24.5216 276.575 24.5674 276.511 24.6245 276.459C24.6816 276.406 24.7487 276.366 24.8219 276.34C24.8951 276.315 24.9727 276.305 25.05 276.31C30.8564 276.612 36.6131 277.541 42.22 279.08C42.3667 279.13 42.4882 279.235 42.5591 279.373C42.6299 279.511 42.6446 279.671 42.6 279.82C42.5601 279.946 42.4793 280.054 42.3706 280.128C42.2619 280.203 42.1314 280.238 42 280.23Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M253.68 485.02C381.252 485.02 484.67 425.313 484.67 351.66C484.67 278.007 381.252 218.3 253.68 218.3C126.108 218.3 22.69 278.007 22.69 351.66C22.69 425.313 126.108 485.02 253.68 485.02Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M130.92 294.81C179.85 266.57 259.17 266.57 308.09 294.81C349.56 318.75 355.86 355.3 327.03 383.09L434.68 444.45C441.24 448.24 441.24 454.38 434.68 458.17L425 463.76C418.44 467.55 408 467.25 401.64 463.1L307.64 397.36C258.64 425.36 179.72 425.25 130.96 397.1C82 368.85 82 323.06 130.92 294.81Z",
                                        fill: "#E6E6E6"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M150.75 46.4998L142.27 51.3998C142.313 51.028 142.336 50.6541 142.34 50.2798V47.8198C142.34 43.4398 139.27 41.6698 135.48 43.8198C133.847 44.8164 132.451 46.1577 131.39 47.7498C130.76 42.2498 126.45 40.1998 121.2 43.2198C115.53 46.4998 110.94 54.4598 110.94 61.0098V64.6798C110.901 66.1509 111.198 67.6114 111.81 68.9498L104.81 73.0198C103.694 73.7434 102.767 74.7221 102.105 75.8749C101.442 77.0277 101.064 78.3217 101 79.6498C101 82.0798 102.7 83.0598 104.81 81.8498L150.81 55.2898C151.92 54.5701 152.844 53.5978 153.506 52.4524C154.169 51.307 154.55 50.021 154.62 48.6998C154.56 46.2698 152.86 45.2898 150.75 46.4998Z",
                                        fill: "#EBEBEB"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M38.9 68.5599L43.68 64.8699V54.3299C43.68 45.9699 50.35 36.2699 57.58 32.0999C64.82 27.9199 70.69 31.3099 70.69 39.6599V41.1899C72.216 38.7178 74.2979 36.6359 76.77 35.1099C81.98 32.1099 86.2 34.5399 86.2 40.5499V41.2499L92.87 37.3999C96.3 35.3999 99.08 37.0199 99.08 40.9799C98.9636 43.1353 98.3406 45.2329 97.2616 47.1025C96.1826 48.972 94.6781 50.5608 92.87 51.7399L38.9 82.8999C35.47 84.8999 32.69 83.2699 32.69 79.3099C32.8064 77.1559 33.4294 75.0597 34.5085 73.1917C35.5875 71.3238 37.0922 69.7369 38.9 68.5599Z",
                                        fill: "#EBEBEB"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M109.83 313.19V343.62C109.83 360.14 120.75 376.62 142.58 389.27C186.24 414.48 257.04 414.48 300.7 389.27C322.53 376.66 333.45 360.14 333.45 343.62V313.19C333.45 296.67 322.53 280.19 300.7 267.55C257.04 242.34 186.24 242.34 142.58 267.55C120.75 280.15 109.83 296.67 109.83 313.19ZM322.63 313.19C322.63 326.41 312.92 339.29 295.29 349.47C275.79 360.73 249.64 366.93 221.64 366.93C193.64 366.93 167.49 360.73 147.99 349.47C130.36 339.29 120.65 326.41 120.65 313.19C120.65 299.97 130.36 287.09 147.99 276.91C167.49 265.65 193.64 259.45 221.64 259.45C249.64 259.45 275.8 265.65 295.29 276.91C312.93 287.09 322.63 300 322.63 313.19Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M109.83 313.19V343.62C109.83 360.14 120.75 376.62 142.58 389.27C186.24 414.48 257.04 414.48 300.7 389.27C322.53 376.66 333.45 360.14 333.45 343.62V313.19C333.45 296.67 322.53 280.19 300.7 267.55C257.04 242.34 186.24 242.34 142.58 267.55C120.75 280.15 109.83 296.67 109.83 313.19ZM322.63 313.19C322.63 326.41 312.92 339.29 295.29 349.47C275.79 360.73 249.64 366.93 221.64 366.93C193.64 366.93 167.49 360.73 147.99 349.47C130.36 339.29 120.65 326.41 120.65 313.19C120.65 299.97 130.36 287.09 147.99 276.91C167.49 265.65 193.64 259.45 221.64 259.45C249.64 259.45 275.8 265.65 295.29 276.91C312.93 287.09 322.63 300 322.63 313.19Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.6",
                                        d: "M333.34 346.46C331.6 356.93 326.99 364.81 308.42 379.3C282.17 399.8 215.7 408.17 177.12 395.44C140.73 383.44 129.12 359.95 129.12 343.84L129.22 334.37C123.6 327.68 120.64 320.49 120.64 313.19C120.64 305.71 123.75 298.34 129.64 291.51L129.77 278.17H127.7C115.79 288.8 109.83 300.99 109.83 313.17V343.6C109.83 360.12 120.75 376.6 142.58 389.25C186.24 414.46 257.04 414.46 300.7 389.25C321.28 377.39 332.16 362 333.34 346.46Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M300.71 267.55C257.04 242.34 186.25 242.34 142.59 267.55C98.93 292.76 98.92 333.63 142.59 358.84C186.26 384.05 257.04 384.05 300.71 358.84C344.38 333.63 344.37 292.76 300.71 267.55ZM295.3 349.47C275.8 360.73 249.64 366.93 221.65 366.93C193.66 366.93 167.5 360.73 147.99 349.47C130.36 339.29 120.65 326.41 120.65 313.19C120.65 299.97 130.36 287.09 147.99 276.91C167.49 265.65 193.65 259.45 221.65 259.45C249.65 259.45 275.8 265.65 295.3 276.91C312.93 287.09 322.64 299.98 322.64 313.19C322.64 326.4 312.93 339.29 295.3 349.47Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M300.71 267.55C257.04 242.34 186.25 242.34 142.59 267.55C98.93 292.76 98.92 333.63 142.59 358.84C186.26 384.05 257.04 384.05 300.71 358.84C344.38 333.63 344.37 292.76 300.71 267.55ZM295.3 349.47C275.8 360.73 249.64 366.93 221.65 366.93C193.66 366.93 167.5 360.73 147.99 349.47C130.36 339.29 120.65 326.41 120.65 313.19C120.65 299.97 130.36 287.09 147.99 276.91C167.49 265.65 193.65 259.45 221.65 259.45C249.65 259.45 275.8 265.65 295.3 276.91C312.93 287.09 322.64 299.98 322.64 313.19C322.64 326.4 312.93 339.29 295.3 349.47Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M322.65 313.19C322.586 318.564 321.076 323.821 318.28 328.41C313.85 320.74 306.04 313.54 295.28 307.35C275.8 296.08 249.63 289.88 221.63 289.88C193.63 289.88 167.48 296.08 147.99 307.35C137.24 313.54 129.44 320.74 124.99 328.41C122.216 323.813 120.718 318.559 120.65 313.19C120.65 299.98 130.36 287.09 148 276.9C167.49 265.66 193.65 259.45 221.64 259.45C249.63 259.45 275.81 265.66 295.29 276.9C312.94 287.09 322.65 300 322.65 313.19Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.3",
                                        d: "M322.65 313.19C322.586 318.564 321.076 323.821 318.28 328.41C313.85 320.74 306.04 313.54 295.28 307.35C275.8 296.08 249.63 289.88 221.63 289.88C193.63 289.88 167.48 296.08 147.99 307.35C137.24 313.54 129.44 320.74 124.99 328.41C122.216 323.813 120.718 318.559 120.65 313.19C120.65 299.98 130.36 287.09 148 276.9C167.49 265.66 193.65 259.45 221.64 259.45C249.63 259.45 275.81 265.66 295.29 276.9C312.94 287.09 322.65 300 322.65 313.19Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.6",
                                        d: "M148 276.9C130.36 287.09 120.65 299.98 120.65 313.19C120.721 318.56 122.223 323.814 125 328.41C129.46 320.74 137.26 313.54 148 307.35C152.542 304.753 157.26 302.477 162.12 300.54C157.86 302.19 144.78 306.4 149.55 293.93C155.22 279.12 182.89 263.08 203.22 260.42C182.31 262.49 163.14 268.17 148 276.9Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.4",
                                        d: "M295.3 290.69C275.8 279.43 249.64 273.23 221.65 273.23C193.66 273.23 167.49 279.43 147.99 290.69C133.45 299.09 124.31 309.33 121.55 320.08C124.31 330.83 133.45 341.08 147.99 349.47C167.5 360.73 193.65 366.93 221.65 366.93C249.65 366.93 275.8 360.73 295.3 349.47C309.85 341.07 318.99 330.83 321.74 320.08C319 309.33 309.85 299.09 295.3 290.69Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M140.52 327.06C146.77 331.96 153.86 335.06 161.09 337.52C168.34 339.921 175.766 341.753 183.3 343C198.355 345.445 213.624 346.316 228.86 345.6C236.47 345.26 244.09 344.55 251.66 343.53C259.206 342.517 266.683 341.044 274.05 339.12C281.381 337.286 288.473 334.601 295.18 331.12C296.836 330.238 298.439 329.26 299.98 328.19C301.528 327.134 302.995 325.964 304.37 324.69C305.757 323.41 306.994 321.978 308.06 320.42C309.163 318.82 310.003 317.055 310.55 315.19C310.583 317.234 310.244 319.267 309.55 321.19C308.816 323.123 307.856 324.963 306.69 326.67C305.537 328.39 304.225 329.997 302.77 331.47C301.33 332.949 299.796 334.336 298.18 335.62C291.663 340.587 284.44 344.551 276.75 347.38C269.168 350.237 261.347 352.416 253.38 353.89C245.455 355.39 237.436 356.342 229.38 356.74C213.21 357.585 197.009 355.861 181.38 351.63C173.562 349.488 166.01 346.469 158.87 342.63C155.314 340.681 151.935 338.426 148.77 335.89C147.98 335.26 147.24 334.57 146.48 333.89C145.72 333.21 145 332.52 144.31 331.79C142.917 330.322 141.649 328.74 140.52 327.06Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M297.38 378.21C297.514 375.491 298.289 372.841 299.641 370.478C300.993 368.115 302.884 366.104 305.16 364.61C307.3 363.36 309.25 363.23 310.67 364.03L335.59 378.28C337 379.09 337.88 380.84 337.89 383.28C337.753 385.999 336.977 388.647 335.626 391.01C334.274 393.373 332.384 395.384 330.11 396.88C327.95 398.14 325.99 398.27 324.57 397.45L299.66 383.21C298.28 382.47 297.39 380.72 297.38 378.21Z",
                                        fill: "#143794"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M299.71 383.28C298.28 382.47 297.39 380.72 297.38 378.21C297.416 376.186 297.868 374.191 298.71 372.35L334.52 392.87C333.355 394.509 331.872 395.896 330.16 396.95C328 398.21 326.04 398.34 324.62 397.52L299.71 383.28Z",
                                        fill: "#112A6A"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M420.44 418.81L341.14 378.4L341.04 378.34C339.2 377.34 336.7 377.52 333.95 379.12C328.33 382.4 323.8 390.32 323.83 396.82C323.83 400.08 325 402.36 326.83 403.42L401.36 451.42C403.504 452.777 405.9 453.689 408.405 454.1C410.909 454.512 413.47 454.414 415.936 453.814C418.402 453.215 420.722 452.124 422.757 450.608C424.793 449.092 426.502 447.182 427.783 444.991C429.064 442.8 429.891 440.374 430.214 437.857C430.537 435.34 430.35 432.783 429.664 430.34C428.978 427.896 427.807 425.616 426.22 423.635C424.634 421.655 422.664 420.013 420.43 418.81H420.44Z",
                                        fill: "#143794"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M326.84 403.44L401.37 451.44C404.141 453.179 407.316 454.169 410.584 454.312C413.853 454.455 417.102 453.746 420.014 452.254C422.926 450.763 425.4 448.541 427.195 445.805C428.989 443.07 430.042 439.915 430.25 436.65C428.82 442.86 418.56 448.14 405.84 441.03C393.12 433.92 346 404.13 324.59 391.8C324.087 393.42 323.825 395.104 323.81 396.8C323.82 400.1 325 402.38 326.84 403.44Z",
                                        fill: "#0E245B"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M326.84 403.44C324.98 402.38 323.84 400.1 323.84 396.84C323.84 390.34 328.34 382.42 333.96 379.14C336.71 377.54 339.21 377.37 341.05 378.36L348.05 381.92C346.16 380.92 343.61 381.08 340.78 382.72C335.02 386.08 330.37 394.21 330.4 400.88C330.4 404.22 331.55 406.61 333.45 407.69",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M333.44 407.69C331.54 406.61 330.44 404.22 330.39 400.88C330.401 399.113 330.674 397.357 331.2 395.67C328.81 394.25 326.58 392.95 324.59 391.8C324.338 392.636 324.141 393.488 324 394.35C323.94 394.77 323.89 395.19 323.85 395.61C323.85 396.03 323.8 396.44 323.85 396.84C323.85 400.1 325.02 402.38 326.85 403.44L333.44 407.69Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M137.21 449.76L77.21 419.75L53.31 430.33L137.21 449.76Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                        opacity: "0.15",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M137.21 449.76L77.21 419.75L53.31 430.33L137.21 449.76Z",
                                            fill: "white"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M137.21 449.76L84.36 414.43L93.82 400.83L137.21 449.76Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                        opacity: "0.15",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M137.21 449.76L84.36 414.43L93.82 400.83L137.21 449.76Z",
                                            fill: "white"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M84.36 414.43L85.35 423.82L137.21 449.76L84.36 414.43Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                        opacity: "0.2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M84.36 414.43L85.35 423.82L137.21 449.76L84.36 414.43Z",
                                            fill: "black"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M75.8 412.63C75.9453 412.627 76.0841 412.57 76.19 412.47C76.3124 412.349 76.3862 412.188 76.3972 412.016C76.4083 411.845 76.3559 411.675 76.25 411.54L75.1 410C75.0534 409.935 74.9934 409.881 74.9241 409.841C74.8548 409.801 74.7777 409.777 74.6982 409.769C74.6186 409.762 74.5383 409.771 74.4627 409.797C74.3872 409.823 74.318 409.865 74.26 409.92C74.138 410.04 74.0637 410.201 74.0509 410.372C74.038 410.543 74.0874 410.713 74.19 410.85C74.57 411.36 74.96 411.85 75.35 412.36C75.3991 412.437 75.4652 412.501 75.5433 412.548C75.6214 412.595 75.7092 412.623 75.8 412.63Z",
                                        fill: "#455A64"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M70.53 405.81C69.8167 404.77 69.1267 403.72 68.46 402.66C68.3698 402.514 68.3353 402.341 68.3629 402.172C68.3904 402.003 68.4782 401.849 68.61 401.74C68.6722 401.691 68.7444 401.655 68.8215 401.637C68.8986 401.618 68.9789 401.616 69.0568 401.631C69.1347 401.646 69.2084 401.678 69.2728 401.725C69.3373 401.771 69.3909 401.831 69.43 401.9C70.1 402.95 70.78 403.99 71.43 405.02C71.5279 405.161 71.5699 405.333 71.5477 405.503C71.5255 405.673 71.4408 405.829 71.31 405.94C71.213 406.024 71.0886 406.07 70.96 406.07C70.8736 406.061 70.7903 406.033 70.7159 405.988C70.6416 405.943 70.5781 405.882 70.53 405.81ZM65.24 397.22C64.63 396.11 64.03 394.98 63.46 393.85C63.3817 393.698 63.3618 393.522 63.4042 393.356C63.4466 393.19 63.5483 393.046 63.69 392.95C63.7588 392.908 63.836 392.88 63.9162 392.871C63.9965 392.861 64.0779 392.869 64.1548 392.893C64.2318 392.918 64.3025 392.959 64.3621 393.014C64.4217 393.068 64.4687 393.135 64.5 393.21C65.06 394.32 65.65 395.43 66.25 396.53C66.3352 396.679 66.3629 396.853 66.3279 397.021C66.2929 397.189 66.1975 397.338 66.06 397.44C65.9666 397.497 65.8595 397.528 65.75 397.53C65.6451 397.528 65.5426 397.499 65.4529 397.444C65.3633 397.39 65.2898 397.312 65.24 397.22ZM60.78 388.06C60.28 386.87 59.78 385.67 59.36 384.48C59.2986 384.322 59.2973 384.148 59.3563 383.989C59.4153 383.83 59.5305 383.699 59.68 383.62C59.7545 383.588 59.8347 383.573 59.9156 383.574C59.9965 383.575 60.0763 383.593 60.1497 383.627C60.2232 383.661 60.2887 383.71 60.3422 383.771C60.3956 383.831 60.4357 383.903 60.46 383.98C60.89 385.15 61.36 386.33 61.86 387.5C61.9272 387.657 61.9348 387.833 61.8814 387.995C61.828 388.157 61.7173 388.294 61.57 388.38C61.4923 388.419 61.4068 388.439 61.32 388.44C61.2027 388.436 61.089 388.398 60.993 388.331C60.897 388.263 60.823 388.169 60.78 388.06ZM57.32 378.38C56.96 377.13 56.62 375.86 56.32 374.63C56.2722 374.467 56.2893 374.292 56.3675 374.141C56.4457 373.99 56.5792 373.875 56.74 373.82C56.8183 373.799 56.8999 373.795 56.9799 373.807C57.0599 373.819 57.1365 373.848 57.205 373.891C57.2734 373.934 57.3323 373.991 57.3779 374.058C57.4235 374.125 57.4548 374.2 57.47 374.28C57.76 375.5 58.09 376.74 58.47 377.97C58.5209 378.131 58.5102 378.305 58.44 378.458C58.3697 378.612 58.245 378.733 58.09 378.8H57.91C57.7797 378.802 57.6521 378.763 57.5459 378.687C57.4398 378.611 57.3606 378.504 57.32 378.38ZM55 368.27C54.8 367 54.62 365.7 54.47 364.41C54.4407 364.244 54.4778 364.074 54.5733 363.935C54.6687 363.797 54.8148 363.701 54.98 363.67C55.144 363.659 55.3058 363.712 55.431 363.819C55.5561 363.925 55.6347 364.076 55.65 364.24C55.79 365.51 55.97 366.79 56.17 368.04C56.2037 368.203 56.1737 368.372 56.0863 368.513C55.9989 368.655 55.8607 368.757 55.7 368.8H55.59C55.4458 368.792 55.3085 368.736 55.2011 368.639C55.0937 368.543 55.0227 368.412 55 368.27ZM54 357.91C54 356.91 53.94 355.91 53.94 354.84V354C53.936 353.918 53.948 353.837 53.9755 353.76C54.003 353.683 54.0454 353.613 54.1002 353.552C54.155 353.492 54.2211 353.443 54.2949 353.408C54.3687 353.374 54.4485 353.354 54.53 353.35C54.6954 353.363 54.8491 353.44 54.9577 353.566C55.0663 353.691 55.121 353.854 55.11 354.02V354.84C55.11 355.84 55.11 356.84 55.11 357.84C55.124 358.007 55.0722 358.172 54.9657 358.301C54.8591 358.43 54.7063 358.512 54.54 358.53C54.3898 358.51 54.2519 358.436 54.1524 358.322C54.053 358.208 53.9987 358.061 54 357.91ZM54.79 348.22C54.6263 348.19 54.4801 348.099 54.3816 347.965C54.283 347.832 54.2395 347.665 54.26 347.5C54.37 346.21 54.51 344.9 54.67 343.61C54.6761 343.528 54.6988 343.449 54.7368 343.376C54.7748 343.303 54.8273 343.239 54.891 343.188C54.9547 343.136 55.0283 343.098 55.1073 343.076C55.1862 343.054 55.2688 343.049 55.35 343.06C55.5133 343.094 55.657 343.19 55.7504 343.328C55.8438 343.466 55.8795 343.636 55.85 343.8C55.69 345.07 55.55 346.36 55.44 347.62C55.4329 347.775 55.3688 347.922 55.2599 348.033C55.151 348.144 55.005 348.21 54.85 348.22H54.79ZM56.19 338C56.0299 337.949 55.8952 337.839 55.8135 337.692C55.7317 337.545 55.709 337.373 55.75 337.21C56.01 335.94 56.31 334.67 56.64 333.42C56.655 333.341 56.6863 333.265 56.732 333.199C56.7778 333.132 56.8369 333.076 56.9056 333.034C56.9743 332.991 57.0511 332.964 57.1311 332.953C57.211 332.942 57.2924 332.948 57.37 332.97C57.5283 333.031 57.6581 333.149 57.734 333.3C57.8098 333.452 57.8262 333.627 57.78 333.79C57.46 335.01 57.16 336.27 56.9 337.51C56.8792 337.648 56.8108 337.774 56.7068 337.867C56.6028 337.961 56.4695 338.014 56.33 338.02L56.19 338ZM58.89 328.11C58.7379 328.036 58.6193 327.907 58.5581 327.75C58.4969 327.592 58.4976 327.417 58.56 327.26C58.99 326.06 59.47 324.85 59.97 323.67C59.9983 323.595 60.0417 323.527 60.0976 323.469C60.1536 323.412 60.2207 323.367 60.2949 323.337C60.3692 323.307 60.4488 323.293 60.5288 323.295C60.6089 323.297 60.6876 323.316 60.76 323.35C60.9057 323.438 61.0151 323.575 61.0683 323.736C61.1216 323.898 61.115 324.073 61.05 324.23C60.55 325.39 60.05 326.57 59.66 327.75C59.6225 327.867 59.5493 327.97 59.4507 328.043C59.3521 328.117 59.233 328.157 59.11 328.16C59.0336 328.163 58.9577 328.145 58.89 328.11ZM63 318.82C62.8591 318.721 62.7598 318.573 62.7211 318.405C62.6823 318.237 62.7069 318.061 62.79 317.91C63.4 316.8 64.04 315.69 64.69 314.62C64.7284 314.549 64.7817 314.487 64.8462 314.439C64.9107 314.39 64.9849 314.356 65.0637 314.339C65.1425 314.322 65.2241 314.322 65.3028 314.34C65.3816 314.357 65.4557 314.391 65.52 314.44C65.6516 314.549 65.7401 314.702 65.7694 314.87C65.7987 315.039 65.767 315.213 65.68 315.36C65.03 316.41 64.4 317.5 63.81 318.59C63.7624 318.685 63.6897 318.765 63.5998 318.821C63.5098 318.878 63.4062 318.908 63.3 318.91C63.1934 318.91 63.0892 318.878 63 318.82ZM68.31 310.33C68.1888 310.211 68.1149 310.052 68.102 309.883C68.0891 309.714 68.1381 309.546 68.24 309.41C68.99 308.41 69.78 307.41 70.57 306.47C70.6216 306.409 70.686 306.36 70.7585 306.326C70.831 306.292 70.91 306.275 70.99 306.275C71.07 306.275 71.149 306.292 71.2215 306.326C71.294 306.36 71.3584 306.409 71.41 306.47C71.5239 306.598 71.5868 306.763 71.5868 306.935C71.5868 307.106 71.5239 307.272 71.41 307.4C70.63 308.33 69.86 309.29 69.12 310.28C69.0678 310.353 68.9989 310.414 68.9189 310.455C68.8389 310.497 68.7502 310.519 68.66 310.52C68.5837 310.518 68.5086 310.501 68.4396 310.468C68.3707 310.435 68.3095 310.388 68.26 310.33H68.31ZM74.74 302.85C74.6261 302.722 74.5632 302.556 74.5632 302.385C74.5632 302.213 74.6261 302.048 74.74 301.92C75.62 301.05 76.53 300.2 77.44 299.4C77.5 299.346 77.5708 299.307 77.6477 299.283C77.7245 299.259 77.8055 299.252 77.8851 299.263C77.9648 299.273 78.0414 299.301 78.1095 299.343C78.1776 299.386 78.2358 299.443 78.28 299.51C78.3768 299.651 78.4199 299.823 78.4016 299.993C78.3833 300.164 78.3047 300.322 78.18 300.44C77.28 301.22 76.39 302.05 75.52 302.9C75.4174 303.006 75.2773 303.067 75.13 303.07C75.0449 303.068 74.9612 303.048 74.885 303.01C74.8089 302.972 74.7423 302.917 74.69 302.85H74.74ZM82.1 296.52C82.0179 296.371 81.991 296.199 82.0239 296.032C82.0569 295.866 82.1476 295.716 82.28 295.61C83.28 294.89 84.28 294.22 85.28 293.61C85.3485 293.569 85.4248 293.544 85.5039 293.535C85.583 293.526 85.6631 293.534 85.7388 293.559C85.8145 293.584 85.8841 293.624 85.9429 293.678C86.0018 293.731 86.0485 293.797 86.08 293.87C86.1577 294.021 86.1772 294.195 86.1348 294.359C86.0924 294.523 85.991 294.666 85.85 294.76C84.85 295.36 83.85 296.02 82.85 296.76C82.7563 296.826 82.6445 296.861 82.53 296.86C82.4278 296.848 82.3302 296.811 82.2463 296.752C82.1624 296.692 82.0949 296.612 82.05 296.52H82.1Z",
                                        fill: "#455A64"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M90.9 292.2H91.08C91.6082 292 92.1539 291.849 92.71 291.75C92.8741 291.714 93.0179 291.615 93.1111 291.476C93.2043 291.336 93.2398 291.165 93.21 291C93.2037 290.919 93.1813 290.84 93.1441 290.767C93.1068 290.695 93.0554 290.631 92.993 290.579C92.9306 290.527 92.8583 290.487 92.7805 290.464C92.7027 290.44 92.6209 290.432 92.54 290.44C91.9205 290.556 91.3117 290.723 90.72 290.94C90.5616 291.003 90.4332 291.124 90.3607 291.278C90.2883 291.432 90.2773 291.608 90.33 291.77C90.3678 291.892 90.4432 292 90.5455 292.077C90.6478 292.154 90.7719 292.197 90.9 292.2Z",
                                        fill: "#455A64"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M371.7 62.1501L310.2 43.3L357.58 75.85L371.7 62.1501Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M371.7 62.1501L310.2 43.3L357.58 75.85L371.7 62.1501Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M310.2 43.3L376.39 53.95L390.51 40.25L310.2 43.3Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M310.2 43.3L376.39 53.95L390.51 40.25L310.2 43.3Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M376.39 53.9501L376.45 70.31L371.7 62.1501L310.2 43.3L376.39 53.9501Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M376.39 53.9501L376.45 70.31L371.7 62.1501L310.2 43.3L376.39 53.9501Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M376.45 70.3099L366.99 66.7199L371.7 62.1499L376.45 70.3099Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M371.7 62.1499L366.99 66.7199L368.5 67.2899L371.7 62.1499Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M388.86 59.27C388.802 59.3127 388.754 59.3666 388.718 59.4285C388.682 59.4904 388.659 59.5589 388.65 59.63C388.629 59.8007 388.67 59.9732 388.766 60.1163C388.861 60.2593 389.004 60.3635 389.17 60.41L390.99 60.9C391.066 60.9241 391.147 60.9311 391.226 60.9207C391.306 60.9104 391.382 60.8828 391.45 60.8399C391.517 60.7971 391.575 60.74 391.618 60.6727C391.661 60.6053 391.689 60.5293 391.7 60.45C391.724 60.2817 391.687 60.1104 391.595 59.9672C391.503 59.8241 391.363 59.7186 391.2 59.67L389.36 59.18C389.275 59.1553 389.186 59.1506 389.099 59.1662C389.013 59.1819 388.931 59.2174 388.86 59.27Z",
                                        fill: "#455A64"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M397.19 61.5001C398.38 61.9001 399.57 62.3201 400.74 62.7501C400.9 62.8108 401.034 62.9267 401.116 63.0771C401.199 63.2274 401.225 63.4022 401.19 63.5701C401.169 63.6475 401.132 63.7195 401.081 63.7813C401.03 63.8431 400.966 63.8932 400.894 63.9283C400.822 63.9633 400.744 63.9825 400.663 63.9846C400.583 63.9866 400.504 63.9715 400.43 63.9401C399.27 63.5101 398.09 63.1001 396.91 62.7001C396.749 62.6452 396.614 62.5338 396.529 62.3866C396.445 62.2395 396.417 62.0665 396.45 61.9001C396.473 61.7718 396.545 61.6573 396.65 61.5801C396.726 61.5226 396.815 61.4852 396.91 61.4712C397.004 61.4573 397.1 61.4672 397.19 61.5001ZM406.6 65.1201C407.77 65.6401 408.92 66.1201 410.06 66.7301C410.214 66.8023 410.337 66.9291 410.403 67.086C410.47 67.243 410.476 67.419 410.42 67.5801C410.39 67.6547 410.345 67.7222 410.287 67.7781C410.229 67.8339 410.161 67.877 410.085 67.9044C410.009 67.9318 409.929 67.9429 409.849 67.937C409.769 67.931 409.691 67.9083 409.62 67.8701C408.5 67.3201 407.36 66.7901 406.21 66.2901C406.055 66.2199 405.931 66.0966 405.859 65.9424C405.788 65.7883 405.774 65.6136 405.82 65.4501C405.853 65.3422 405.92 65.2476 406.01 65.1801C406.094 65.1179 406.193 65.0795 406.297 65.069C406.401 65.0584 406.505 65.0761 406.6 65.1201ZM415.7 69.7101C416.82 70.3501 417.92 71.0201 419 71.7101C419.144 71.7994 419.25 71.9377 419.3 72.0995C419.35 72.2613 419.339 72.4356 419.27 72.5901C419.23 72.6609 419.176 72.7225 419.111 72.7711C419.046 72.8196 418.971 72.8539 418.892 72.8718C418.813 72.8897 418.731 72.8908 418.651 72.875C418.572 72.8592 418.496 72.8269 418.43 72.7801C417.37 72.1101 416.28 71.4601 415.18 70.7801C415.032 70.6974 414.919 70.5629 414.864 70.4024C414.808 70.2419 414.814 70.0666 414.88 69.9101C414.913 69.8268 414.968 69.7541 415.04 69.7001C415.139 69.637 415.254 69.6044 415.371 69.6062C415.489 69.608 415.603 69.6441 415.7 69.7101ZM424.32 75.3201C425.37 76.0901 426.4 76.8901 427.39 77.6901C427.524 77.7934 427.614 77.9437 427.642 78.1106C427.67 78.2776 427.633 78.4489 427.54 78.5901C427.491 78.6548 427.428 78.7085 427.357 78.7475C427.286 78.7866 427.207 78.8102 427.126 78.8168C427.044 78.8234 426.963 78.8129 426.886 78.7859C426.809 78.7589 426.739 78.716 426.68 78.6601C425.68 77.8701 424.68 77.0901 423.68 76.3301C423.54 76.2326 423.441 76.0859 423.404 75.9192C423.367 75.7524 423.394 75.5778 423.48 75.4301C423.509 75.3777 423.55 75.3331 423.6 75.3001C423.707 75.228 423.834 75.1912 423.963 75.1948C424.092 75.1984 424.217 75.2422 424.32 75.3201ZM432.27 82.0001C433.21 82.8901 434.14 83.8101 435.04 84.7501C435.156 84.8711 435.221 85.0324 435.221 85.2001C435.221 85.3678 435.156 85.5291 435.04 85.6501C434.982 85.7081 434.914 85.7542 434.838 85.7857C434.763 85.8171 434.682 85.8333 434.6 85.8333C434.518 85.8333 434.437 85.8171 434.362 85.7857C434.286 85.7542 434.218 85.7081 434.16 85.6501C433.28 84.7301 432.36 83.8201 431.44 82.9501C431.315 82.8384 431.237 82.6831 431.222 82.5159C431.207 82.3487 431.256 82.1822 431.36 82.0501L431.44 81.9701C431.558 81.8715 431.707 81.82 431.861 81.8256C432.014 81.8311 432.16 81.8933 432.27 82.0001ZM439.36 89.6201C440.01 90.4101 440.64 91.2101 441.27 92.0301L441.77 92.7001C441.875 92.8279 441.925 92.9919 441.91 93.1565C441.895 93.3211 441.816 93.4732 441.69 93.5801C441.622 93.627 441.545 93.6598 441.464 93.6766C441.384 93.6934 441.3 93.6939 441.219 93.6781C441.138 93.6623 441.061 93.6304 440.993 93.5844C440.924 93.5384 440.865 93.4791 440.82 93.4101L440.32 92.7501C439.71 91.9501 439.09 91.1601 438.45 90.3801C438.335 90.2607 438.27 90.1012 438.27 89.9351C438.27 89.769 438.335 89.6094 438.45 89.4901C438.514 89.4327 438.589 89.3892 438.671 89.3625C438.753 89.3358 438.839 89.3264 438.925 89.3348C439.01 89.3433 439.093 89.3695 439.168 89.4117C439.243 89.4539 439.308 89.5113 439.36 89.5801V89.6201ZM444.61 97.8201C444.757 97.7427 444.928 97.7244 445.088 97.7691C445.248 97.8137 445.384 97.9178 445.47 98.0601C446.16 99.1601 446.84 100.28 447.47 101.41C447.514 101.479 447.543 101.555 447.557 101.636C447.57 101.716 447.568 101.798 447.549 101.877C447.53 101.956 447.496 102.031 447.448 102.097C447.4 102.163 447.34 102.218 447.27 102.26C447.118 102.328 446.946 102.336 446.788 102.282C446.63 102.228 446.499 102.117 446.42 101.97C445.78 100.86 445.11 99.7501 444.42 98.6801C444.331 98.553 444.293 98.3973 444.314 98.2437C444.334 98.0901 444.411 97.9497 444.53 97.8501L444.61 97.8201ZM449.68 106.82C449.84 106.763 450.015 106.768 450.171 106.835C450.327 106.901 450.452 107.025 450.52 107.18C451.07 108.35 451.61 109.54 452.1 110.73C452.135 110.803 452.154 110.883 452.157 110.964C452.16 111.045 452.147 111.126 452.118 111.201C452.089 111.277 452.045 111.346 451.989 111.404C451.932 111.463 451.865 111.509 451.79 111.54C451.627 111.586 451.452 111.57 451.3 111.494C451.149 111.418 451.031 111.288 450.97 111.13C450.49 109.96 449.97 108.79 449.42 107.65C449.351 107.526 449.328 107.382 449.356 107.243C449.383 107.104 449.459 106.979 449.57 106.89C449.596 106.836 449.634 106.788 449.68 106.75V106.82ZM453.53 116.32C453.696 116.289 453.869 116.32 454.013 116.409C454.157 116.498 454.263 116.637 454.31 116.8C454.69 118.02 455.05 119.27 455.36 120.51C455.384 120.587 455.391 120.668 455.382 120.748C455.372 120.828 455.346 120.905 455.304 120.974C455.262 121.043 455.207 121.102 455.141 121.148C455.074 121.194 454.999 121.225 454.92 121.24C454.753 121.262 454.583 121.221 454.445 121.125C454.306 121.029 454.208 120.884 454.17 120.72C453.86 119.5 453.51 118.27 453.17 117.08C453.128 116.965 453.122 116.84 453.155 116.721C453.187 116.603 453.255 116.498 453.35 116.42C453.395 116.349 453.457 116.291 453.53 116.25V116.32ZM455.93 126.17C456.101 126.166 456.268 126.225 456.399 126.335C456.53 126.446 456.616 126.601 456.64 126.77C456.84 128.02 457 129.29 457.13 130.55C457.14 130.628 457.133 130.708 457.11 130.784C457.087 130.859 457.048 130.929 456.996 130.988C456.944 131.048 456.88 131.096 456.809 131.129C456.737 131.162 456.659 131.179 456.58 131.18C456.409 131.178 456.244 131.113 456.118 130.996C455.993 130.88 455.915 130.721 455.9 130.55C455.77 129.32 455.62 128.08 455.42 126.85C455.402 126.747 455.412 126.64 455.449 126.542C455.486 126.443 455.548 126.356 455.63 126.29C455.707 126.196 455.812 126.129 455.93 126.1V126.17Z",
                                        fill: "#455A64"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M466.88 285.83C464.2 284.23 460.42 284.45 456.22 286.83L380.06 330.83C371.93 335.52 365.33 346.68 365.33 355.75C365.33 360.18 366.91 363.28 369.47 364.75L377.64 369.46C380.31 370.98 384.04 370.74 388.18 368.35L464.35 324.35C472.48 319.66 479.07 308.5 479.07 299.43C479.07 295.03 477.51 291.92 474.97 290.43C473.58 289.67 468.22 286.63 466.88 285.83Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M381.42 370C376.82 370 373.96 366.36 373.96 360.51C373.96 351.62 380.45 340.63 388.43 336.03L464.6 292.03C466.561 290.813 468.804 290.124 471.11 290.03C475.71 290.03 478.57 293.67 478.57 299.52C478.57 308.42 472.08 319.4 464.1 324.01L387.93 368.01C385.97 369.228 383.726 369.914 381.42 370Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M471.11 290.49C475.4 290.49 478.11 293.94 478.11 299.49C478.11 308.23 471.73 319.02 463.89 323.49L387.72 367.49C385.836 368.666 383.679 369.334 381.46 369.43C380.51 369.462 379.565 369.276 378.699 368.886C377.832 368.496 377.066 367.912 376.46 367.18C375.039 365.23 374.333 362.85 374.46 360.44C374.46 351.71 380.84 340.92 388.68 336.44L464.85 292.44C466.734 291.264 468.891 290.596 471.11 290.5M471.11 289.5C468.714 289.591 466.383 290.308 464.35 291.58L388.18 335.58C380.05 340.28 373.46 351.43 373.46 360.5C373.46 366.85 376.69 370.5 381.46 370.5C383.855 370.407 386.184 369.694 388.22 368.43L464.39 324.43C472.52 319.74 479.11 308.58 479.11 299.51C479.11 293.16 475.88 289.51 471.11 289.51V289.5Z",
                                        fill: "#EBEBEB"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M400.12 345.36C400.43 344.78 400.38 344.18 400.12 344.02L397.57 342.55C397.516 342.522 397.456 342.507 397.395 342.507C397.334 342.507 397.274 342.522 397.22 342.55L394.88 343.45L394.11 341.81C394.072 341.729 394.009 341.662 393.93 341.62L391.38 340.14C391.06 339.96 390.53 340.37 390.32 341.05L388.73 346.26C388.643 346.574 388.462 346.853 388.21 347.06L384.66 349.81C384.09 350.24 383.87 351.3 384.28 351.59L386.85 353.45C386.938 353.541 387.003 353.653 387.038 353.775C387.073 353.897 387.077 354.026 387.05 354.15L386.44 359.22C386.39 359.59 386.5 359.84 386.67 359.93L389.22 361.41C389.42 361.52 389.72 361.41 389.99 361.08L393.17 357.02C393.236 356.909 393.33 356.816 393.442 356.752C393.554 356.687 393.681 356.652 393.81 356.65L397 357C397.5 357.07 398.09 356.15 398 355.46L397.39 351.09C397.362 350.767 397.432 350.443 397.59 350.16L400.12 345.36Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M400.09 344C400.035 343.975 399.975 343.962 399.915 343.962C399.855 343.962 399.795 343.975 399.74 344L396.18 345.36C396.134 345.383 396.083 345.396 396.032 345.398C395.98 345.4 395.929 345.391 395.881 345.373C395.833 345.354 395.789 345.325 395.753 345.288C395.717 345.252 395.688 345.208 395.67 345.16L394.85 343.42L397.19 342.53C397.244 342.502 397.304 342.488 397.365 342.488C397.426 342.488 397.486 342.502 397.54 342.53L400.09 344Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M391.25 347.72C391.161 348.033 390.98 348.312 390.73 348.52L387.18 351.26C387.017 351.387 386.886 351.552 386.8 351.74L384.25 350.26C384.342 350.075 384.471 349.912 384.63 349.78L388.18 347.04C388.429 346.836 388.611 346.56 388.7 346.25L391.25 347.72Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M393.92 341.61C393.6 341.4 393.06 341.81 392.84 342.51L391.25 347.72L388.7 346.24L390.29 341.03C390.5 340.35 391.03 339.94 391.35 340.12C391.42 340.12 393.58 341.42 393.91 341.6L393.92 341.61Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.25",
                                        d: "M389.37 354.91L386.84 353.45L384.27 351.59C383.97 351.37 384.01 350.77 384.27 350.28L386.82 351.76C386.56 352.24 386.52 352.85 386.82 353.07L389.37 354.91Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M389 360.68C389 361.05 389.06 361.3 389.25 361.4L386.69 359.92C386.589 359.835 386.515 359.723 386.476 359.597C386.437 359.471 386.435 359.337 386.47 359.21L387.08 354.14C387.105 354.02 387.102 353.897 387.071 353.779C387.04 353.66 386.981 353.551 386.9 353.46L389.43 354.92C389.512 355.009 389.571 355.116 389.602 355.233C389.633 355.35 389.636 355.472 389.61 355.59L389 360.68Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M394.08 341.79L395.67 345.17C395.688 345.218 395.717 345.262 395.753 345.299C395.789 345.335 395.833 345.364 395.881 345.383C395.929 345.402 395.98 345.41 396.032 345.408C396.083 345.406 396.134 345.393 396.18 345.37L399.74 344.01C400.3 343.79 400.53 344.59 400.12 345.36L397.55 350.18C397.392 350.463 397.322 350.787 397.35 351.11L397.96 355.48C398.05 356.17 397.46 357.09 396.96 357.02L393.78 356.63C393.651 356.632 393.524 356.667 393.412 356.732C393.3 356.797 393.206 356.889 393.14 357L390 361.06C389.49 361.71 388.9 361.48 389 360.67L389.61 355.6C389.639 355.476 389.636 355.346 389.601 355.224C389.566 355.101 389.5 354.99 389.41 354.9L386.84 353.05C386.43 352.75 386.66 351.7 387.22 351.26L390.77 348.52C391.022 348.313 391.203 348.034 391.29 347.72L392.88 342.51C393.09 341.68 393.82 341.26 394.08 341.79Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M394.08 341.79L395.67 345.17C395.688 345.218 395.717 345.262 395.753 345.299C395.789 345.335 395.833 345.364 395.881 345.383C395.929 345.402 395.98 345.41 396.032 345.408C396.083 345.406 396.134 345.393 396.18 345.37L399.74 344.01C400.3 343.79 400.53 344.59 400.12 345.36L397.55 350.18C397.392 350.463 397.322 350.787 397.35 351.11L397.96 355.48C398.05 356.17 397.46 357.09 396.96 357.02L393.78 356.63C393.651 356.632 393.524 356.667 393.412 356.732C393.3 356.797 393.206 356.889 393.14 357L390 361.06C389.49 361.71 388.9 361.48 389 360.67L389.61 355.6C389.639 355.476 389.636 355.346 389.601 355.224C389.566 355.101 389.5 354.99 389.41 354.9L386.84 353.05C386.43 352.75 386.66 351.7 387.22 351.26L390.77 348.52C391.022 348.313 391.203 348.034 391.29 347.72L392.88 342.51C393.09 341.68 393.82 341.26 394.08 341.79Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M418 335.06C418.31 334.48 418.25 333.89 418 333.73L415.46 332.26C415.404 332.232 415.343 332.217 415.28 332.217C415.217 332.217 415.156 332.232 415.1 332.26L412.77 333.16L411.99 331.52C411.958 331.438 411.898 331.37 411.82 331.33L409.27 329.85C408.95 329.67 408.42 330.08 408.21 330.76L406.55 336C406.459 336.312 406.278 336.59 406.03 336.8L402.48 339.54C401.91 339.98 401.69 341.04 402.09 341.33L404.67 343.19C404.758 343.281 404.822 343.393 404.855 343.516C404.888 343.638 404.89 343.767 404.86 343.89L404.26 348.96C404.21 349.33 404.31 349.58 404.48 349.67L407 351.1C407.2 351.21 407.49 351.1 407.77 350.77L410.95 346.71C411.016 346.599 411.11 346.507 411.222 346.442C411.334 346.377 411.461 346.342 411.59 346.34L414.77 346.73C415.27 346.79 415.86 345.88 415.77 345.19L415.17 340.82C415.138 340.497 415.207 340.171 415.37 339.89L418 335.06Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M417.94 333.72C417.885 333.695 417.825 333.683 417.765 333.683C417.705 333.683 417.645 333.695 417.59 333.72L414 335.08C413.953 335.103 413.902 335.116 413.85 335.118C413.797 335.121 413.745 335.112 413.696 335.093C413.648 335.075 413.603 335.046 413.566 335.009C413.529 334.972 413.499 334.928 413.48 334.88L412.67 333.14L415 332.25C415.056 332.222 415.118 332.208 415.18 332.208C415.242 332.208 415.304 332.222 415.36 332.25L417.94 333.72Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M409.1 337.43C409.011 337.743 408.83 338.022 408.58 338.23L405 341C404.837 341.127 404.706 341.292 404.62 341.48L402.09 340C402.189 339.817 402.321 339.654 402.48 339.52L406.03 336.78C406.278 336.57 406.459 336.292 406.55 335.98L409.1 337.43Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M411.77 331.32C411.45 331.11 410.91 331.52 410.69 332.22L409.1 337.43L406.55 336L408.14 330.79C408.35 330.11 408.88 329.7 409.2 329.88C409.27 329.88 411.43 331.18 411.75 331.35L411.77 331.32Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.25",
                                        d: "M407.22 344.61L404.69 343.16L402.12 341.3C401.83 341.08 401.87 340.48 402.12 339.99L404.68 341.47C404.42 341.95 404.38 342.56 404.68 342.77L407.22 344.61Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M406.81 350.38C406.76 350.76 406.87 351.01 407.05 351.11L404.5 349.63C404.33 349.53 404.23 349.29 404.28 348.92L404.89 343.85C404.913 343.73 404.909 343.607 404.878 343.489C404.846 343.372 404.789 343.262 404.71 343.17L407.24 344.62C407.322 344.709 407.381 344.816 407.412 344.933C407.443 345.049 407.446 345.172 407.42 345.29L406.81 350.38Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M411.92 331.5L413.51 334.88C413.529 334.929 413.559 334.973 413.596 335.009C413.633 335.046 413.678 335.075 413.726 335.093C413.775 335.112 413.827 335.121 413.88 335.118C413.932 335.116 413.983 335.103 414.03 335.08L417.59 333.72C418.15 333.5 418.38 334.3 417.97 335.06L415.4 339.89C415.238 340.171 415.168 340.497 415.2 340.82L415.8 345.19C415.9 345.88 415.31 346.79 414.8 346.73L411.62 346.34C411.491 346.342 411.364 346.377 411.252 346.442C411.14 346.507 411.046 346.599 410.98 346.71L407.8 350.77C407.29 351.42 406.7 351.19 406.8 350.38L407.41 345.31C407.437 345.186 407.433 345.057 407.398 344.935C407.363 344.813 407.298 344.701 407.21 344.61L404.64 342.76C404.23 342.46 404.45 341.41 405.02 340.97L408.57 338.23C408.822 338.023 409.003 337.744 409.09 337.43L410.68 332.22C410.94 331.39 411.67 331 411.92 331.5Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M411.92 331.5L413.51 334.88C413.529 334.929 413.559 334.973 413.596 335.009C413.633 335.046 413.678 335.075 413.726 335.093C413.775 335.112 413.827 335.121 413.88 335.118C413.932 335.116 413.983 335.103 414.03 335.08L417.59 333.72C418.15 333.5 418.38 334.3 417.97 335.06L415.4 339.89C415.238 340.171 415.168 340.497 415.2 340.82L415.8 345.19C415.9 345.88 415.31 346.79 414.8 346.73L411.62 346.34C411.491 346.342 411.364 346.377 411.252 346.442C411.14 346.507 411.046 346.599 410.98 346.71L407.8 350.77C407.29 351.42 406.7 351.19 406.8 350.38L407.41 345.31C407.437 345.186 407.433 345.057 407.398 344.935C407.363 344.813 407.298 344.701 407.21 344.61L404.64 342.76C404.23 342.46 404.45 341.41 405.02 340.97L408.57 338.23C408.822 338.023 409.003 337.744 409.09 337.43L410.68 332.22C410.94 331.39 411.67 331 411.92 331.5Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M435.82 324.77C436.12 324.19 436.07 323.6 435.82 323.44L433.24 322C433.183 321.974 433.122 321.961 433.06 321.961C432.998 321.961 432.937 321.974 432.88 322L430.54 322.9L429.77 321.26C429.738 321.178 429.678 321.11 429.6 321.07L427.05 319.59C426.73 319.41 426.19 319.82 425.99 320.5L424.4 325.71C424.309 326.022 424.128 326.3 423.88 326.51L420.32 329.25C419.76 329.69 419.53 330.74 419.94 331.04L422.51 332.9C422.603 332.988 422.67 333.1 422.705 333.223C422.74 333.346 422.742 333.476 422.71 333.6L422.1 338.67C422.1 339.04 422.16 339.28 422.33 339.38L424.88 340.86C425.09 340.97 425.38 340.86 425.66 340.53L428.83 336.47C428.897 336.357 428.992 336.264 429.106 336.199C429.22 336.134 429.349 336.1 429.48 336.1L432.65 336.49C433.16 336.55 433.75 335.64 433.65 334.95L433.05 330.58C433.018 330.258 433.085 329.934 433.24 329.65L435.82 324.77Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M435.79 323.43C435.733 323.405 435.672 323.392 435.61 323.392C435.548 323.392 435.487 323.405 435.43 323.43L431.88 324.79C431.833 324.813 431.782 324.826 431.73 324.828C431.677 324.831 431.625 324.822 431.576 324.803C431.528 324.785 431.483 324.756 431.446 324.719C431.409 324.683 431.379 324.638 431.36 324.59L430.54 322.85L432.88 321.96C432.934 321.933 432.994 321.918 433.055 321.918C433.116 321.918 433.176 321.933 433.23 321.96L435.79 323.43Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M427 327.13C426.909 327.445 426.729 327.726 426.48 327.94L422.93 330.68C422.766 330.809 422.633 330.973 422.54 331.16L419.99 329.68C420.089 329.497 420.221 329.334 420.38 329.2L423.93 326.46C424.178 326.25 424.359 325.972 424.45 325.66L427 327.13Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M429.62 321C429.3 320.79 428.75 321.2 428.54 321.89L427 327.13L424.45 325.66L426.04 320.45C426.25 319.77 426.78 319.36 427.1 319.54C427.17 319.54 429.32 320.84 429.65 321.01L429.62 321Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.25",
                                        d: "M425.06 334.32L422.54 332.87L419.94 331C419.65 330.78 419.68 330.18 419.94 329.69L422.49 331.17C422.24 331.65 422.2 332.26 422.49 332.47L425.06 334.32Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M424.66 340.09C424.61 340.47 424.72 340.72 424.9 340.82L422.35 339.34C422.18 339.24 422.08 339 422.12 338.63L422.73 333.55C422.756 333.433 422.754 333.311 422.724 333.195C422.695 333.078 422.639 332.971 422.56 332.88L425.08 334.33C425.158 334.421 425.215 334.528 425.246 334.644C425.278 334.76 425.282 334.882 425.26 335L424.66 340.09Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M429.77 321.21L431.36 324.59C431.379 324.638 431.409 324.682 431.446 324.719C431.483 324.756 431.528 324.784 431.576 324.803C431.625 324.822 431.677 324.83 431.73 324.828C431.782 324.826 431.833 324.813 431.88 324.79L435.43 323.43C436 323.21 436.22 324.01 435.82 324.77L433.24 329.6C433.085 329.884 433.018 330.208 433.05 330.53L433.65 334.9C433.75 335.59 433.16 336.5 432.65 336.44L429.48 336.05C429.349 336.05 429.22 336.084 429.106 336.149C428.992 336.214 428.897 336.307 428.83 336.42L425.66 340.48C425.15 341.13 424.56 340.9 424.66 340.09L425.26 335.02C425.29 334.897 425.288 334.768 425.255 334.645C425.222 334.523 425.158 334.411 425.07 334.32L422.49 332.46C422.09 332.17 422.31 331.11 422.88 330.68L426.43 327.94C426.678 327.73 426.859 327.452 426.95 327.14L428.54 321.93C428.79 321.1 429.52 320.68 429.77 321.21Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M429.77 321.21L431.36 324.59C431.379 324.638 431.409 324.682 431.446 324.719C431.483 324.756 431.528 324.784 431.576 324.803C431.625 324.822 431.677 324.83 431.73 324.828C431.782 324.826 431.833 324.813 431.88 324.79L435.43 323.43C436 323.21 436.22 324.01 435.82 324.77L433.24 329.6C433.085 329.884 433.018 330.208 433.05 330.53L433.65 334.9C433.75 335.59 433.16 336.5 432.65 336.44L429.48 336.05C429.349 336.05 429.22 336.084 429.106 336.149C428.992 336.214 428.897 336.307 428.83 336.42L425.66 340.48C425.15 341.13 424.56 340.9 424.66 340.09L425.26 335.02C425.29 334.897 425.288 334.768 425.255 334.645C425.222 334.523 425.158 334.411 425.07 334.32L422.49 332.46C422.09 332.17 422.31 331.11 422.88 330.68L426.43 327.94C426.678 327.73 426.859 327.452 426.95 327.14L428.54 321.93C428.79 321.1 429.52 320.68 429.77 321.21Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M453.66 314.48C453.97 313.9 453.92 313.31 453.66 313.15L451.12 311.67C451.063 311.645 451.002 311.631 450.94 311.631C450.878 311.631 450.817 311.645 450.76 311.67L448.42 312.57L447.65 310.93C447.616 310.847 447.557 310.777 447.48 310.73C447.16 310.56 445 309.3 444.93 309.26C444.61 309.08 444.07 309.49 443.86 310.17L442.27 315.38C442.183 315.691 442.006 315.97 441.76 316.18L438.2 318.92C437.64 319.36 437.41 320.41 437.82 320.71L440.39 322.57C440.481 322.657 440.547 322.767 440.582 322.888C440.617 323.009 440.62 323.137 440.59 323.26L439.98 328.33C439.98 328.7 440.04 328.95 440.21 329.05L442.76 330.53C442.96 330.64 443.26 330.53 443.53 330.2L446.71 326.14C446.776 326.029 446.87 325.937 446.982 325.872C447.094 325.807 447.221 325.772 447.35 325.77L450.53 326.16C451.04 326.22 451.63 325.31 451.53 324.62L450.92 320.25C450.896 319.927 450.966 319.604 451.12 319.32L453.66 314.48Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M453.63 313.14C453.575 313.115 453.515 313.102 453.455 313.102C453.395 313.102 453.335 313.115 453.28 313.14L449.72 314.5C449.674 314.523 449.623 314.536 449.572 314.538C449.52 314.54 449.469 314.532 449.421 314.513C449.373 314.494 449.329 314.465 449.293 314.429C449.257 314.392 449.228 314.348 449.21 314.3L448.39 312.56L450.73 311.67C450.784 311.64 450.844 311.625 450.905 311.625C450.966 311.625 451.026 311.64 451.08 311.67L453.63 313.14Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M444.8 316.84C444.709 317.155 444.529 317.436 444.28 317.65L440.73 320.39C440.566 320.519 440.433 320.683 440.34 320.87L437.79 319.39C437.885 319.207 438.014 319.044 438.17 318.91L441.72 316.17C441.975 315.964 442.16 315.685 442.25 315.37L444.8 316.84Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M447.47 310.74C447.15 310.53 446.6 310.94 446.39 311.63L444.8 316.84L442.25 315.37L443.84 310.16C444.04 309.48 444.58 309.07 444.9 309.25C444.97 309.25 447.12 310.55 447.45 310.72L447.47 310.74Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.25",
                                        d: "M442.91 324L440.39 322.55L437.82 320.69C437.52 320.47 437.56 319.87 437.82 319.38L440.37 320.86C440.11 321.34 440.08 321.95 440.37 322.16L442.91 324Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M442.5 329.8C442.5 330.18 442.57 330.43 442.75 330.53L440.18 329C440.01 328.9 439.91 328.66 439.95 328.29L440.56 323.21C440.584 323.092 440.581 322.971 440.551 322.855C440.522 322.74 440.467 322.632 440.39 322.54L442.91 323.99C442.989 324.08 443.045 324.188 443.074 324.305C443.104 324.421 443.106 324.543 443.08 324.66L442.5 329.8Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M447.62 310.92L449.21 314.3C449.229 314.349 449.259 314.393 449.296 314.429C449.333 314.466 449.378 314.495 449.426 314.513C449.475 314.532 449.527 314.541 449.58 314.538C449.632 314.536 449.683 314.523 449.73 314.5L453.28 313.14C453.85 312.92 454.07 313.72 453.66 314.48L451.09 319.31C450.936 319.594 450.866 319.917 450.89 320.24L451.5 324.61C451.6 325.3 451.01 326.21 450.5 326.15L447.32 325.76C447.191 325.762 447.064 325.797 446.952 325.862C446.84 325.927 446.746 326.019 446.68 326.13L443.5 330.19C443 330.84 442.41 330.61 442.5 329.8L443.11 324.73C443.142 324.606 443.14 324.476 443.105 324.353C443.07 324.23 443.003 324.118 442.91 324.03L440.34 322.17C439.93 321.88 440.16 320.82 440.72 320.39L444.28 317.65C444.527 317.439 444.707 317.161 444.8 316.85L446.39 311.63C446.64 310.81 447.37 310.39 447.62 310.92Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M447.62 310.92L449.21 314.3C449.229 314.349 449.259 314.393 449.296 314.429C449.333 314.466 449.378 314.495 449.426 314.513C449.475 314.532 449.527 314.541 449.58 314.538C449.632 314.536 449.683 314.523 449.73 314.5L453.28 313.14C453.85 312.92 454.07 313.72 453.66 314.48L451.09 319.31C450.936 319.594 450.866 319.917 450.89 320.24L451.5 324.61C451.6 325.3 451.01 326.21 450.5 326.15L447.32 325.76C447.191 325.762 447.064 325.797 446.952 325.862C446.84 325.927 446.746 326.019 446.68 326.13L443.5 330.19C443 330.84 442.41 330.61 442.5 329.8L443.11 324.73C443.142 324.606 443.14 324.476 443.105 324.353C443.07 324.23 443.003 324.118 442.91 324.03L440.34 322.17C439.93 321.88 440.16 320.82 440.72 320.39L444.28 317.65C444.527 317.439 444.707 317.161 444.8 316.85L446.39 311.63C446.64 310.81 447.37 310.39 447.62 310.92Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M471.51 304.19C471.82 303.61 471.77 303.02 471.51 302.85L468.96 301.38C468.905 301.355 468.845 301.342 468.785 301.342C468.725 301.342 468.665 301.355 468.61 301.38L466.27 302.28L465.5 300.64C465.459 300.561 465.401 300.493 465.33 300.44C465 300.27 462.84 299.01 462.78 298.97C462.45 298.79 461.92 299.19 461.71 299.88L460.12 305.09C460.033 305.404 459.852 305.683 459.6 305.89L456 308.62C455.43 309.06 455.21 310.11 455.62 310.41L458.19 312.27C458.281 312.357 458.347 312.467 458.382 312.588C458.417 312.709 458.42 312.837 458.39 312.96L457.8 318C457.8 318.37 457.86 318.62 458.03 318.72L460.58 320.2C460.78 320.31 461.08 320.2 461.35 319.87L464.53 315.81C464.596 315.699 464.69 315.606 464.802 315.542C464.914 315.477 465.041 315.442 465.17 315.44L468.35 315.83C468.85 315.89 469.44 314.98 469.35 314.29L468.74 309.92C468.711 309.597 468.781 309.273 468.94 308.99L471.51 304.19Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M471.48 302.85C471.426 302.823 471.366 302.808 471.305 302.808C471.244 302.808 471.184 302.823 471.13 302.85L467.57 304.21C467.524 304.233 467.473 304.246 467.422 304.248C467.37 304.25 467.319 304.242 467.271 304.223C467.223 304.204 467.179 304.175 467.143 304.139C467.107 304.102 467.078 304.058 467.06 304.01L466.24 302.27L468.58 301.37C468.634 301.342 468.694 301.327 468.755 301.327C468.816 301.327 468.876 301.342 468.93 301.37L471.48 302.85Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M462.65 306.55C462.556 306.866 462.372 307.147 462.12 307.36L458.57 310.1C458.409 310.23 458.28 310.394 458.19 310.58L455.64 309.1C455.732 308.915 455.861 308.751 456.02 308.62L459.57 305.88C459.822 305.673 460.003 305.394 460.09 305.08L462.65 306.55Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M465.32 300.44C465 300.24 464.45 300.65 464.24 301.34L462.65 306.55L460.09 305.08L461.68 299.87C461.89 299.19 462.43 298.78 462.75 298.96C462.82 298.96 464.97 300.26 465.3 300.43L465.32 300.44Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.25",
                                        d: "M460.76 313.74L458.23 312.29L455.66 310.43C455.36 310.21 455.4 309.61 455.66 309.12L458.21 310.6C457.95 311.08 457.91 311.69 458.21 311.9L460.76 313.74Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.15",
                                        d: "M460.35 319.51C460.35 319.89 460.41 320.14 460.6 320.23L458 318.75C457.83 318.65 457.73 318.41 457.77 318.03L458.38 312.96C458.405 312.842 458.401 312.72 458.37 312.603C458.338 312.487 458.28 312.38 458.2 312.29L460.73 313.74C460.809 313.83 460.866 313.938 460.896 314.054C460.925 314.171 460.927 314.293 460.9 314.41L460.35 319.51Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M465.47 300.63L467.06 304.01C467.079 304.058 467.109 304.102 467.146 304.139C467.183 304.176 467.228 304.205 467.276 304.223C467.325 304.242 467.377 304.251 467.43 304.248C467.482 304.246 467.533 304.233 467.58 304.21L471.13 302.85C471.69 302.63 471.92 303.43 471.51 304.19L468.94 309C468.781 309.283 468.711 309.607 468.74 309.93L469.35 314.3C469.44 314.99 468.85 315.9 468.35 315.84L465.17 315.45C465.041 315.452 464.914 315.487 464.802 315.552C464.69 315.617 464.596 315.709 464.53 315.82L461.35 319.88C460.85 320.53 460.26 320.29 460.35 319.49L460.96 314.42C460.989 314.296 460.986 314.166 460.951 314.044C460.916 313.921 460.85 313.81 460.76 313.72L458.19 311.86C457.78 311.57 458.01 310.51 458.57 310.08L462.13 307.34C462.371 307.126 462.548 306.849 462.64 306.54L464.23 301.32C464.49 300.52 465.22 300.09 465.47 300.63Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.5",
                                        d: "M465.47 300.63L467.06 304.01C467.079 304.058 467.109 304.102 467.146 304.139C467.183 304.176 467.228 304.205 467.276 304.223C467.325 304.242 467.377 304.251 467.43 304.248C467.482 304.246 467.533 304.233 467.58 304.21L471.13 302.85C471.69 302.63 471.92 303.43 471.51 304.19L468.94 309C468.781 309.283 468.711 309.607 468.74 309.93L469.35 314.3C469.44 314.99 468.85 315.9 468.35 315.84L465.17 315.45C465.041 315.452 464.914 315.487 464.802 315.552C464.69 315.617 464.596 315.709 464.53 315.82L461.35 319.88C460.85 320.53 460.26 320.29 460.35 319.49L460.96 314.42C460.989 314.296 460.986 314.166 460.951 314.044C460.916 313.921 460.85 313.81 460.76 313.72L458.19 311.86C457.78 311.57 458.01 310.51 458.57 310.08L462.13 307.34C462.371 307.126 462.548 306.849 462.64 306.54L464.23 301.32C464.49 300.52 465.22 300.09 465.47 300.63Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M478.32 57.0001L470.32 60.4301L468.61 68.9601C468.561 69.1944 468.448 69.4105 468.283 69.5842C468.118 69.7579 467.909 69.8823 467.677 69.9436C467.446 70.0048 467.202 70.0004 466.973 69.9309C466.744 69.8614 466.538 69.7296 466.38 69.5501L460.65 63.0001L452 64.0001C451.752 64.0376 451.499 64.0016 451.272 63.8965C451.044 63.7914 450.852 63.6219 450.72 63.409C450.588 63.196 450.522 62.949 450.529 62.6986C450.536 62.4481 450.616 62.2053 450.76 62.0001L455.21 54.5301L451.59 46.6201C451.502 46.4077 451.473 46.1755 451.505 45.9479C451.538 45.7202 451.631 45.5056 451.776 45.3266C451.92 45.1475 452.11 45.0106 452.325 44.9303C452.541 44.85 452.774 44.8292 453 44.8701L461.48 46.8001L467.88 40.9101C468.056 40.7457 468.274 40.6343 468.51 40.5884C468.747 40.5426 468.991 40.5642 469.215 40.6508C469.44 40.7375 469.635 40.8856 469.779 41.0783C469.923 41.2709 470.01 41.5003 470.03 41.7401L470.82 50.4001L478.4 54.6601C478.623 54.768 478.81 54.9386 478.939 55.1509C479.067 55.3632 479.13 55.6082 479.122 55.8561C479.113 56.104 479.033 56.3441 478.891 56.5472C478.748 56.7502 478.55 56.9076 478.32 57.0001Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M434.23 42.18C434.159 42.2723 434.075 42.3533 433.98 42.42C433.81 42.5422 433.61 42.6144 433.401 42.6285C433.193 42.6426 432.985 42.5981 432.8 42.5L428.35 40.16L423.89 42.5C423.705 42.5981 423.497 42.6426 423.289 42.6285C423.08 42.6144 422.88 42.5422 422.71 42.42C422.538 42.2986 422.406 42.1302 422.328 41.935C422.249 41.7399 422.229 41.5263 422.27 41.32L423.12 36.32L419.51 32.81C419.36 32.6643 419.253 32.479 419.204 32.2755C419.154 32.072 419.163 31.8586 419.23 31.66C419.293 31.4611 419.41 31.284 419.57 31.1494C419.729 31.0149 419.923 30.9284 420.13 30.9L425.13 30.18L427.36 25.66C427.452 25.4734 427.594 25.3163 427.771 25.2066C427.948 25.097 428.152 25.0393 428.36 25.04C428.568 25.0416 428.771 25.1003 428.947 25.2096C429.123 25.319 429.266 25.4748 429.36 25.66L431.59 30.18L436.59 30.9C436.797 30.9303 436.991 31.0177 437.15 31.1524C437.31 31.2871 437.429 31.4638 437.493 31.6625C437.558 31.8611 437.565 32.0739 437.515 32.2767C437.465 32.4795 437.36 32.6642 437.21 32.81L433.6 36.32L434.46 41.32C434.499 41.6257 434.416 41.9344 434.23 42.18ZM420 31.79L419.94 31.92C419.915 31.9947 419.912 32.075 419.932 32.1512C419.951 32.2275 419.992 32.2965 420.05 32.35L423.91 36.12L423 41.44C422.988 41.5183 422.997 41.5985 423.028 41.6718C423.058 41.745 423.108 41.8084 423.172 41.8549C423.236 41.9015 423.312 41.9294 423.391 41.9356C423.47 41.9418 423.549 41.926 423.62 41.89L428.4 39.38L433.17 41.89C433.238 41.9295 433.316 41.9503 433.395 41.9503C433.474 41.9503 433.552 41.9295 433.62 41.89C433.686 41.8445 433.738 41.7804 433.768 41.7057C433.799 41.631 433.806 41.549 433.79 41.47L432.88 36.15L436.74 32.38C436.796 32.3252 436.835 32.2561 436.855 32.1803C436.874 32.1046 436.873 32.0249 436.85 31.95C436.827 31.874 436.783 31.8061 436.723 31.7547C436.663 31.7032 436.589 31.6703 436.51 31.66L431.16 30.88L428.72 26C428.687 25.9274 428.633 25.866 428.566 25.8233C428.498 25.7807 428.42 25.7587 428.34 25.76C428.268 25.768 428.199 25.7942 428.139 25.8362C428.08 25.8781 428.032 25.9345 428 26L425.62 30.84L420.27 31.62C420.162 31.6418 420.066 31.7023 420 31.79Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M378.54 109C371.01 104.64 360.66 105.23 349.22 111.83C326.22 125.13 307.53 157.7 307.53 184.59C307.53 198.12 312.27 207.59 319.9 212.02C321.67 213.02 328.59 217.02 328.59 217.02C328.266 220.063 327.214 222.984 325.524 225.535C323.835 228.087 321.556 230.194 318.88 231.68C318.44 231.93 318.71 232.36 319.1 232.58L329.67 238.69C329.813 238.775 329.974 238.823 330.14 238.83C340.55 238.83 352.6 231.83 355.96 217.29C357.22 216.69 358.49 216.04 359.78 215.29C382.78 202 401.47 169.42 401.47 142.54C401.47 129 396.74 119.54 389.11 115.08L378.54 109Z",
                                        fill: "#112A6A"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M359.78 117.93C336.78 131.22 318.09 163.8 318.09 190.68C318.09 208.93 326.68 219.85 339.4 220.85C338.92 226.65 337.23 233.17 329.4 237.78C328.78 238.15 329.59 238.84 330.11 238.84C340.52 238.84 352.57 231.84 355.93 217.3C357.19 216.7 358.46 216.05 359.75 215.3C382.75 202.01 401.44 169.43 401.44 142.55C401.44 115.67 382.8 104.64 359.78 117.93Z",
                                        fill: "#143794"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M329.43 237.78C329.05 238.02 329.22 238.37 329.54 238.61L319.1 232.61C318.71 232.37 318.44 231.96 318.88 231.7C321.561 230.211 323.844 228.098 325.534 225.538C327.225 222.979 328.273 220.05 328.59 217L329.74 217.68L330.8 218.3C333.449 219.756 336.384 220.616 339.4 220.82C338.93 226.65 337.23 233.17 329.43 237.78Z",
                                        fill: "#112A6A"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M355.38 194.89C354.27 194.1 353.71 192.68 353.71 190.63C353.734 188.494 354.298 186.399 355.35 184.54C356.305 182.682 357.76 181.127 359.55 180.05C361.25 179.07 362.647 178.953 363.74 179.7C364.83 180.44 365.38 181.84 365.38 183.89C365.348 186.063 364.774 188.194 363.71 190.09C362.778 191.967 361.336 193.544 359.55 194.64C357.89 195.59 356.5 195.68 355.38 194.89ZM353.89 140.53L365.2 134L363.31 172.12L355.78 176.47L353.89 140.53Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M365.34 211.65C377.62 202.65 388.21 188.38 394.69 173.06C382.41 182.07 371.82 196.33 365.34 211.65Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M443.86 263.75C439.6 263.8 436.43 260.82 434.44 257.07C447.2 241.38 455.83 220.48 455.83 202.2C455.83 188.65 451.08 179.13 443.43 174.73L432.88 168.65C425.35 164.3 415.01 164.9 403.58 171.49C380.58 184.79 361.89 217.36 361.89 244.25C361.89 257.78 366.62 267.25 374.25 271.7C376.03 272.7 383.04 276.76 384.77 277.77C392.31 282.16 402.68 281.58 414.14 274.96C417.209 273.174 420.122 271.133 422.85 268.86C430.59 274.99 440.03 268.31 443.77 265.11C444.27 264.69 444.33 263.75 443.86 263.75Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M395.69 280C381.75 280 373.1 268.65 373.1 250.39C373.1 223.75 391.66 191.39 414.46 178.2C420.84 174.52 426.94 172.65 432.59 172.65C446.52 172.65 455.18 183.99 455.18 202.26C455.18 219.73 447.04 240.6 433.94 256.71L433.67 257.05L433.87 257.43C436.22 261.86 439.63 264.34 443.49 264.43C443.463 264.514 443.415 264.59 443.35 264.65C440.69 266.93 435.41 270.74 429.94 270.74C427.504 270.751 425.14 269.917 423.25 268.38L422.84 268.06L422.43 268.39C419.728 270.625 416.844 272.632 413.81 274.39C407.44 278.08 401.34 280 395.69 280Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M432.59 172V173.3C446.12 173.3 454.53 184.4 454.53 202.25C454.53 219.59 446.45 240.3 433.44 256.3L432.89 256.97L433.3 257.73C435.46 261.81 438.5 264.32 441.99 264.95C439.22 267.16 434.63 270.11 429.94 270.11C427.65 270.121 425.426 269.336 423.65 267.89L422.83 267.24L422.02 267.91C419.346 270.141 416.493 272.148 413.49 273.91C407.21 277.53 401.22 279.37 395.69 279.37C382.16 279.37 373.75 268.27 373.75 250.37C373.75 223.94 392.16 191.81 414.75 178.74C421.03 175.12 427.02 173.28 432.55 173.28V172M432.55 172C426.99 172 420.73 173.81 414.1 177.64C391.1 190.93 372.41 223.5 372.41 250.39C372.41 269.54 381.88 280.65 395.65 280.65C401.21 280.65 407.47 278.84 414.1 275.01C417.169 273.224 420.082 271.183 422.81 268.91C424.81 270.543 427.318 271.428 429.9 271.41C435.62 271.41 441.09 267.41 443.73 265.16C444.23 264.74 444.29 263.8 443.82 263.8H443.72C439.52 263.8 436.38 260.85 434.4 257.12C447.16 241.43 455.79 220.53 455.79 202.25C455.79 183.1 446.32 172 432.55 172Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M412 230.85C413.213 227.94 414.606 225.108 416.17 222.37C417.248 220.491 418.229 218.559 419.11 216.58C419.717 215.223 420.04 213.756 420.06 212.27C420.06 210.27 419.46 209.04 418.26 208.56C417.06 208.08 415.48 208.43 413.49 209.56C411.522 210.715 409.8 212.243 408.42 214.06C406.879 216.072 405.621 218.286 404.68 220.64L397.33 219.13C398.974 214.787 401.304 210.736 404.23 207.13C407.093 203.591 410.585 200.611 414.53 198.34C419.197 195.673 422.933 194.84 425.74 195.84C428.547 196.84 429.953 199.7 429.96 204.42C429.973 206.551 429.697 208.673 429.14 210.73C428.647 212.593 427.977 214.404 427.14 216.14C426.35 217.76 425.32 219.69 424.07 221.93C422.858 223.997 421.763 226.13 420.79 228.32C420.119 229.901 419.779 231.603 419.79 233.32L410.62 238.62C410.583 235.966 411.051 233.329 412 230.85ZM411 256.58C409.89 255.79 409.33 254.37 409.33 252.31C409.354 250.174 409.918 248.079 410.97 246.22C411.925 244.365 413.375 242.81 415.16 241.73C416.87 240.73 418.26 240.63 419.36 241.38C420.46 242.13 421 243.53 421 245.58C420.966 247.75 420.392 249.877 419.33 251.77C418.398 253.65 416.952 255.228 415.16 256.32C413.55 257.28 412.17 257.36 411.05 256.58H411Z",
                                        fill: "#143794"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M200.78 185.3L154.78 211.94L173.05 243C173.402 243.838 174.016 244.54 174.8 245C176.98 246.23 189.89 253.71 190.6 254.12C191.154 254.44 191.773 254.63 192.41 254.676C193.048 254.722 193.688 254.623 194.281 254.386C194.875 254.149 195.408 253.781 195.839 253.309C196.27 252.837 196.588 252.273 196.77 251.66L216.61 194.48L200.78 185.3Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M200.78 185.3L154.78 211.94L173.05 243C173.402 243.838 174.016 244.54 174.8 245C176.98 246.23 189.89 253.71 190.6 254.12C191.154 254.44 191.773 254.63 192.41 254.676C193.048 254.722 193.688 254.623 194.281 254.386C194.875 254.149 195.408 253.781 195.839 253.309C196.27 252.837 196.588 252.273 196.77 251.66L216.61 194.48L200.78 185.3Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M170.61 221.08L188.88 252.14C189.229 252.929 189.812 253.591 190.55 254.038C191.288 254.485 192.146 254.694 193.007 254.637C193.868 254.58 194.69 254.261 195.363 253.721C196.036 253.181 196.527 252.448 196.77 251.62L216.61 194.44L170.61 221.08Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M252.1 26L78.63 126.13C77.467 126.884 76.4985 127.902 75.8034 129.101C75.1083 130.3 74.7063 131.646 74.63 133.03V253.42C74.7037 254.799 75.105 256.141 75.8006 257.334C76.4962 258.527 77.4662 259.537 78.63 260.28L92.9 268.28C94.141 268.904 95.5108 269.23 96.9 269.23C98.2892 269.23 99.6591 268.904 100.9 268.28L274.38 168.09C275.541 167.334 276.509 166.316 277.203 165.117C277.898 163.919 278.301 162.573 278.38 161.19V40.8C278.306 39.4212 277.904 38.0799 277.208 36.887C276.513 35.6942 275.543 34.684 274.38 33.94L260.12 25.94C258.871 25.3232 257.496 25.0074 256.103 25.0178C254.71 25.0282 253.339 25.3646 252.1 26Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.3",
                                        d: "M278.31 40.0699C277.99 38.0699 276.36 37.3499 274.37 38.4899L100.91 138.65C99.728 139.388 98.7594 140.422 98.1 141.65L75.89 129C76.5566 127.845 77.4977 126.873 78.63 126.17L252.11 25.9999C253.352 25.3779 254.721 25.054 256.11 25.054C257.499 25.054 258.868 25.3779 260.11 25.9999L274.37 33.9999C275.42 34.6741 276.314 35.5641 276.994 36.6106C277.673 37.6572 278.122 38.8365 278.31 40.0699Z",
                                        fill: "white"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M96.92 266.4V146C96.9962 144.617 97.3984 143.273 98.0935 142.075C98.7887 140.878 99.7572 139.862 100.92 139.11L274.38 38.9999C276.57 37.7299 278.38 38.7599 278.38 41.2999V161.65C278.301 163.033 277.898 164.379 277.203 165.577C276.509 166.776 275.541 167.794 274.38 168.55L100.9 268.7C98.7 270 96.92 268.94 96.92 266.4Z",
                                        fill: "#F84C4D"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.2",
                                        d: "M100.9 268.24C99.6544 268.849 98.2864 269.165 96.9 269.165C95.5137 269.165 94.1456 268.849 92.9 268.24L78.64 260.24C77.4771 259.5 76.5075 258.494 75.8118 257.304C75.1161 256.115 74.7144 254.776 74.64 253.4V133C74.711 131.579 75.1485 130.201 75.91 129L98.1 141.63C97.3686 142.806 96.9615 144.155 96.92 145.54V265.93C96.92 268.26 98.56 269.6 100.9 268.24Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M145.59 170L143.86 169C143.198 168.621 142.448 168.422 141.685 168.422C140.922 168.422 140.172 168.621 139.51 169L128.94 175.1V160.66L148.51 149.37C149.426 148.829 150.185 148.058 150.711 147.134C151.238 146.21 151.513 145.164 151.51 144.1V136C151.513 134.936 151.238 133.89 150.711 132.966C150.185 132.041 149.426 131.27 148.51 130.73C147.585 130.194 146.534 129.912 145.465 129.912C144.396 129.912 143.345 130.194 142.42 130.73L115.28 146.4C113.673 147.326 112.339 148.66 111.412 150.266C110.485 151.873 109.998 153.695 110 155.55V230.74C109.995 231.805 110.27 232.853 110.796 233.78C111.323 234.706 112.082 235.478 113 236.02C113.926 236.553 114.976 236.834 116.045 236.834C117.114 236.834 118.164 236.553 119.09 236.02L125.86 232.12C126.778 231.578 127.537 230.806 128.064 229.88C128.59 228.953 128.865 227.905 128.86 226.84V197.34L145.52 187.72C146.18 187.336 146.728 186.786 147.109 186.125C147.49 185.463 147.69 184.713 147.69 183.95V173.79C147.704 173.029 147.517 172.279 147.148 171.613C146.78 170.948 146.242 170.391 145.59 170Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M119.71 235.66L119.13 236C118.204 236.532 117.154 236.812 116.086 236.811C115.018 236.811 113.968 236.529 113.043 235.996C112.118 235.462 111.349 234.695 110.813 233.771C110.277 232.847 109.993 231.798 109.99 230.73V155.54C109.993 153.794 110.429 152.076 111.26 150.54L117.35 154.05C116.515 155.584 116.079 157.303 116.08 159.05V233.54C116.082 233.964 116.194 234.381 116.406 234.749C116.618 235.117 116.923 235.423 117.289 235.637C117.656 235.851 118.072 235.966 118.497 235.97C118.921 235.974 119.339 235.867 119.71 235.66Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M128.94 160.66V182.14L145.57 172.55C145.793 172.419 146.046 172.35 146.304 172.349C146.562 172.347 146.816 172.415 147.04 172.544C147.264 172.673 147.449 172.859 147.577 173.083C147.706 173.308 147.772 173.562 147.77 173.82V184C147.77 184.759 147.57 185.505 147.191 186.163C146.812 186.821 146.267 187.369 145.61 187.75L128.94 197.37V226.86C128.944 227.923 128.669 228.968 128.143 229.891C127.616 230.814 126.857 231.583 125.94 232.12L119.78 235.68C119.41 235.895 118.99 236.008 118.562 236.008C118.134 236.009 117.714 235.896 117.344 235.682C116.974 235.468 116.666 235.16 116.453 234.789C116.24 234.418 116.129 233.998 116.13 233.57V159.05C116.13 157.196 116.618 155.374 117.545 153.768C118.472 152.162 119.805 150.828 121.41 149.9L148.29 134.38C148.625 134.187 149.005 134.085 149.391 134.085C149.778 134.085 150.157 134.187 150.492 134.381C150.827 134.575 151.104 134.853 151.297 135.188C151.49 135.523 151.591 135.903 151.59 136.29V144.12C151.593 145.18 151.317 146.221 150.79 147.141C150.264 148.061 149.505 148.826 148.59 149.36L128.94 160.66Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M187 115.24C186.692 114.196 186.151 113.235 185.418 112.431C184.685 111.626 183.779 110.998 182.769 110.593C181.758 110.189 180.669 110.019 179.583 110.097C178.497 110.174 177.443 110.496 176.5 111.04L169.77 114.93C168.903 115.429 168.15 116.105 167.559 116.912C166.969 117.72 166.553 118.642 166.34 119.62L146.27 211C146.113 211.77 146.201 212.57 146.522 213.288C146.843 214.005 147.381 214.604 148.06 215L149.9 216.06C150.47 216.389 151.117 216.562 151.775 216.562C152.433 216.562 153.08 216.389 153.65 216.06L161.76 211.38C162.889 210.689 163.808 209.703 164.42 208.53C165.104 207.345 165.606 206.064 165.91 204.73L169.17 188.07L185.57 178.6L187.27 185.37C187.511 186.253 188.061 187.019 188.82 187.53C189.5 187.93 194.23 190.64 194.91 191.05C195.349 191.238 195.831 191.304 196.305 191.24C196.778 191.177 197.226 190.987 197.6 190.69L207.5 184.97L187 115.24ZM173.67 165.07L177.18 147L177.39 146L181.11 160.77L173.67 165.07Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M194.83 191C193.94 190.47 189.48 187.92 188.83 187.53C188.071 187.019 187.521 186.253 187.28 185.37L185.58 178.6L190.12 175.98L193.37 188.88C193.61 189.728 194.123 190.473 194.83 191Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M187.2 164.28L181.11 160.76L177.39 146C177.39 146 177.39 146 177.39 145.94C177.71 144.5 178.03 142.86 178.39 141.04C178.82 138.77 179.22 136.35 179.6 133.76C180.033 135.84 180.463 137.757 180.89 139.51C181.32 141.26 181.72 142.76 182.1 144.02L187.2 164.28Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M152.47 214C152.416 214.24 152.425 214.49 152.496 214.725C152.568 214.961 152.699 215.174 152.877 215.343C153.056 215.512 153.275 215.632 153.514 215.691C153.753 215.751 154.003 215.746 154.24 215.68V215.76L153.67 216.08C153.1 216.409 152.453 216.582 151.795 216.582C151.137 216.582 150.49 216.409 149.92 216.08L148.06 215C147.381 214.604 146.843 214.005 146.522 213.288C146.201 212.57 146.113 211.77 146.27 211L166.33 119.66C166.514 118.815 166.853 118.011 167.33 117.29L173.42 120.81C172.937 121.525 172.598 122.326 172.42 123.17L152.47 214Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M207.51 185L197.6 190.72C196.49 191.36 195.6 191.48 194.92 191.08C194.162 190.568 193.612 189.802 193.37 188.92L190.12 176L169.12 188.09L165.87 204.75C165.557 206.086 165.051 207.369 164.37 208.56C163.761 209.733 162.841 210.716 161.71 211.4L154.54 215.55C154.299 215.687 154.023 215.751 153.746 215.735C153.469 215.72 153.203 215.624 152.979 215.46C152.755 215.297 152.583 215.072 152.484 214.813C152.385 214.554 152.363 214.271 152.42 214L172.37 123.14C172.585 122.164 173.001 121.244 173.591 120.438C174.182 119.632 174.934 118.958 175.8 118.46L182.27 114.72C182.73 114.455 183.244 114.297 183.774 114.26C184.303 114.222 184.835 114.305 185.327 114.502C185.82 114.7 186.262 115.006 186.619 115.399C186.977 115.792 187.24 116.261 187.39 116.77L207.51 185ZM187.2 164.3L182.1 144C181.72 142.75 181.32 141.24 180.89 139.49C180.46 137.74 180.03 135.82 179.6 133.74C179.23 136.33 178.82 138.74 178.4 141.02C177.98 143.3 177.56 145.26 177.18 146.96L172.12 172.96L187.2 164.3Z",
                                        fill: "#FAFAFA"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M254.91 150C256.656 146.998 258.19 143.877 259.5 140.66C260.853 137.344 261.988 133.943 262.9 130.48C263.82 126.98 264.521 123.427 265 119.84C265.491 116.217 265.738 112.566 265.74 108.91C265.847 103.535 265.159 98.174 263.7 92.9999C262.659 89.1117 260.666 85.5442 257.9 82.6199C257.029 81.7855 256.054 81.0663 255 80.4799L249 76.9999C247.1 75.8988 244.963 75.2711 242.77 75.1699C239.25 74.9699 235.35 76.1066 231.07 78.5799C226.591 81.2102 222.621 84.6246 219.35 88.6599C215.743 93.0386 212.705 97.857 210.31 103C205.156 114.092 202.467 126.169 202.43 138.4C202.326 143.782 203.021 149.151 204.49 154.33C205.528 158.23 207.529 161.806 210.31 164.73C211.177 165.59 212.156 166.33 213.22 166.93C214.22 167.49 218.17 169.79 219.15 170.36C221.074 171.473 223.239 172.101 225.46 172.19C228.98 172.363 232.887 171.213 237.18 168.74C239.007 167.685 240.742 166.481 242.37 165.14L244.85 167.99C245.188 168.337 245.572 168.636 245.99 168.88C246.69 169.29 251.67 172.15 252.05 172.38C252.718 172.79 253.498 172.979 254.28 172.92C255.728 172.747 257.119 172.252 258.35 171.47L268.86 165.41L254.91 150ZM245.53 124.9C244.893 128.428 243.87 131.875 242.48 135.18C241.261 138.108 239.628 140.846 237.63 143.31C235.805 145.558 233.59 147.459 231.09 148.92C229.258 150.107 227.149 150.796 224.97 150.92C223.874 149.144 223.093 147.192 222.66 145.15C221.891 141.616 221.535 138.006 221.6 134.39C221.581 130.386 221.936 126.388 222.66 122.45C223.281 118.924 224.287 115.476 225.66 112.17C226.89 109.229 228.534 106.478 230.54 104C232.377 101.722 234.613 99.7968 237.14 98.3199C238.939 97.1695 241.007 96.5077 243.14 96.3999C244.248 98.1914 245.039 100.16 245.48 102.22C246.264 105.758 246.637 109.376 246.59 113C246.602 117.004 246.247 121.001 245.53 124.94V124.9Z",
                                        fill: "#E0E0E0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M218.9 170.25C217.63 169.52 214.14 167.49 213.22 166.97C212.156 166.37 211.177 165.63 210.31 164.77C207.529 161.846 205.528 158.27 204.49 154.37C203.021 149.191 202.326 143.823 202.43 138.44C202.43 132.282 203.121 126.144 204.49 120.14C205.71 114.672 207.479 109.342 209.77 104.23L215.86 107.75C211.05 118.529 208.55 130.196 208.52 142C208.416 147.379 209.11 152.744 210.58 157.92C211.616 161.823 213.617 165.403 216.4 168.33C217.16 169.06 217.999 169.704 218.9 170.25Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M248.57 99C247.982 98.2627 247.247 97.6554 246.412 97.2164C245.578 96.7775 244.661 96.5165 243.72 96.45C243.55 96.45 243.37 96.45 243.2 96.45C244.303 98.2393 245.091 100.204 245.53 102.26C246.295 105.787 246.65 109.391 246.59 113C246.606 117.024 246.251 121.041 245.53 125C244.893 128.528 243.87 131.975 242.48 135.28C241.261 138.208 239.628 140.946 237.63 143.41C235.805 145.658 233.59 147.559 231.09 149.02C229.258 150.207 227.149 150.896 224.97 151.02C225.188 151.371 225.432 151.705 225.7 152.02C226.287 152.763 227.026 153.371 227.868 153.804C228.71 154.237 229.634 154.485 230.58 154.53C232.928 154.518 235.221 153.823 237.18 152.53C239.68 151.069 241.895 149.168 243.72 146.92C245.714 144.453 247.347 141.716 248.57 138.79C249.962 135.482 250.984 132.032 251.62 128.5C252.341 124.541 252.696 120.524 252.68 116.5C252.738 112.901 252.382 109.308 251.62 105.79C251.143 103.321 250.099 100.996 248.57 99Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        opacity: "0.1",
                                        d: "M244.1 163.68C243.53 164.2 242.96 164.68 242.37 165.18L244.85 168.03C245.188 168.377 245.572 168.676 245.99 168.92C246.67 169.32 251.36 172.01 251.99 172.39C251.602 172.152 251.246 171.867 250.93 171.54L244.1 163.68Z",
                                        fill: "black"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M268.86 165.45L258.35 171.52C257.119 172.293 255.733 172.785 254.29 172.96C253.661 172.991 253.033 172.879 252.452 172.634C251.872 172.388 251.355 172.014 250.94 171.54L244.1 163.68C241.985 165.626 239.665 167.336 237.18 168.78C232.887 171.253 228.98 172.403 225.46 172.23C222.052 172.105 218.816 170.697 216.4 168.29C213.621 165.361 211.62 161.782 210.58 157.88C209.119 152.716 208.425 147.366 208.52 142C208.557 129.769 211.246 117.692 216.4 106.6C218.799 101.445 221.844 96.6168 225.46 92.2299C228.733 88.1968 232.703 84.7829 237.18 82.1499C241.46 79.6699 245.36 78.5332 248.88 78.7399C252.274 78.902 255.485 80.329 257.88 82.7399C260.651 85.664 262.645 89.2362 263.68 93.1299C265.148 98.2855 265.842 103.63 265.74 108.99C265.741 112.645 265.497 116.297 265.01 119.92C264.521 123.523 263.813 127.093 262.89 130.61C261.975 134.07 260.836 137.467 259.48 140.78C258.174 143.998 256.64 147.12 254.89 150.12L268.86 165.45ZM221.6 134.45C221.535 138.069 221.891 141.683 222.66 145.22C223.131 147.676 224.157 149.991 225.66 151.99C226.251 152.729 226.991 153.334 227.832 153.767C228.673 154.199 229.596 154.449 230.54 154.5C232.887 154.487 235.18 153.792 237.14 152.5C239.64 151.039 241.855 149.138 243.68 146.89C245.677 144.424 247.313 141.686 248.54 138.76C249.914 135.45 250.921 132 251.54 128.47C252.267 124.512 252.622 120.494 252.6 116.47C252.663 112.871 252.307 109.277 251.54 105.76C251.071 103.303 250.045 100.987 248.54 98.9899C247.95 98.2523 247.213 97.645 246.377 97.2061C245.541 96.7672 244.622 96.5063 243.68 96.4399C241.358 96.4209 239.083 97.0889 237.14 98.3599C234.611 99.83 232.374 101.752 230.54 104.03C228.537 106.51 226.894 109.261 225.66 112.2C224.291 115.508 223.285 118.955 222.66 122.48C221.937 126.415 221.582 130.409 221.6 134.41V134.45Z",
                                        fill: "#FAFAFA"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2210:
/***/ ((module) => {

module.exports = import("@chakra-ui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,664,403], () => (__webpack_exec__(5311)));
module.exports = __webpack_exports__;

})();