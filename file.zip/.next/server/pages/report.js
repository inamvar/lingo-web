"use strict";
(() => {
var exports = {};
exports.id = 686;
exports.ids = [686];
exports.modules = {

/***/ 4819:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

;// CONCATENATED MODULE: external "html-pdf"
const external_html_pdf_namespaceObject = require("html-pdf");
var external_html_pdf_default = /*#__PURE__*/__webpack_require__.n(external_html_pdf_namespaceObject);
;// CONCATENATED MODULE: ./common/pdfHelper.js

const componentToPDFBuffer = (html)=>{
    return new Promise((resolve, reject)=>{
        // const html = renderToStaticMarkup(component);
        const options = {
            format: "A4",
            orientation: "portrait",
            border: "10mm",
            footer: {
                height: "10mm"
            },
            type: "pdf",
            timeout: 30000,
            childProcessOptions: {
                env: {
                    OPENSSL_CONF: "/dev/null"
                }
            }
        };
        const buffer = external_html_pdf_default().create(html, options).toBuffer((err, buffer)=>{
            if (err) {
                return reject(err);
            }
            return resolve(buffer);
        });
    });
};
/* harmony default export */ const pdfHelper = ({
    componentToPDFBuffer
});


/***/ }),

/***/ 8208:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_pdfHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4819);
/* harmony import */ var _services_appServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7512);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_appServices__WEBPACK_IMPORTED_MODULE_2__]);
_services_appServices__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Index = (props)=>{
    setTimeout(()=>{
        console.log(props.props.pdfBlob);
        const url = window.URL.createObjectURL(new Blob([
            props.props.pdfBlob
        ]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "order-hsistory.pdf");
        document.body.appendChild(link);
        link.click();
        next_router__WEBPACK_IMPORTED_MODULE_3__.router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].MyTransactions */ .Z.MyTransactions);
    }, 1000);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
Index.getInitialProps = async (context)=>{
    const query = context.query;
    const req = context.req;
    const res = context.res;
    const id = query.id;
    const result = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_2__/* .getOrderHistoryPDF */ .nu)(id, context);
    const isServer = !!req;
    if (isServer) {}
    return {
        props: {
            pdfBlob: result
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [403,85,512], () => (__webpack_exec__(8208)));
module.exports = __webpack_exports__;

})();