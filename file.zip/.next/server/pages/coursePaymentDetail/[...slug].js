"use strict";
(() => {
var exports = {};
exports.id = 963;
exports.ids = [963,289];
exports.modules = {

/***/ 2305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ validator)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);

// Define a reusable validation method for the gender field
// yup.addMethod(yup.string, 'selectNotNull', function (name) {
//     return this.notOneOf([null, '---انتخاب کنید ---'],`انتخاب ${name} اجباری است`)
// });
yup__WEBPACK_IMPORTED_MODULE_0__.addMethod(yup__WEBPACK_IMPORTED_MODULE_0__.string, "isMatch", function(pattern, message) {
    return this.matches(pattern, message);
});
yup__WEBPACK_IMPORTED_MODULE_0__.addMethod(yup__WEBPACK_IMPORTED_MODULE_0__.string, "isPhoneNumber", function() {
    return this.matches(/[abcdefghijklmnopqrstuvwxyz]+/, "فرمت شماره همراه وارد شده صحیح نمی باشد");
});
// Export the customized yup object with the global gender method
const validator = yup__WEBPACK_IMPORTED_MODULE_0__;


/***/ }),

/***/ 2215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ withAuth)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3361);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1403);





function withAuth(WrappedComponent) {
    return function AuthenticatedWrapper(props) {
        const context = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
        const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
        (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
            if ("authenticated" in context.authState && !context.authState.authenticated) {
                const current = router.asPath;
                router.push(_common_appRoutes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].LoginReturn */ .Z.LoginReturn(current));
            }
        }, [
            context.authState
        ]);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WrappedComponent, {
            authContext: context,
            ...props
        });
    };
}


/***/ }),

/***/ 1146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ price)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function price(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.pricings.map((p)=>{
            if (p.currencyType == "IRR") {
                const price = (p.amount / 10).toLocaleString();
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: price
                });
            }
        })
    });
}


/***/ }),

/***/ 5544:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BasicUsage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var _common_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2305);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1908);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1599);
/* harmony import */ var _progressTimerPhoneNumberRequest__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9068);
/* harmony import */ var _common_notifier__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(643);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_6__, _progressTimerPhoneNumberRequest__WEBPACK_IMPORTED_MODULE_7__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_6__, _progressTimerPhoneNumberRequest__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function BasicUsage(props) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (props.setOpen) {
            onOpen();
        } else {
            onClose();
        }
    }, [
        props
    ]);
    function close() {
        props.onClick();
        onClose();
    }
    const schema = _common_validator__WEBPACK_IMPORTED_MODULE_2__/* .validator.object */ .s.object({
        code: _common_validator__WEBPACK_IMPORTED_MODULE_2__/* .validator.string */ .s.string().required("نوشتن کد تایید اجباری است")
    });
    const { register , handleSubmit , watch , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__.yupResolver)(schema)
    });
    const OTPCode = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    async function handleClick() {
        const OTPCodeNumber = OTPCode.current.value;
        const result = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_6__/* .ConfirmPhoneNumber */ .q2)(OTPCodeNumber);
        if (result) {
            close();
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_8__/* .pushAlert */ .V)({
                message: "شماره شما تایید شد",
                type: "success"
            });
            props.confirmNumber();
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "p-0 bg-inherit",
                children: props.text
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
                isOpen: isOpen,
                onClose: close,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white flex flex-col justify-center items-center rounded p-5 gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-gray-500",
                                        children: "لطفا کد فعال سازی دریافت شده را وارد نمایید."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        name: "code",
                                        ref: OTPCode,
                                        type: "text",
                                        required: true,
                                        className: "rounded w-full py-3 px-3 text-black text-sm bg-grey darkgrey-color focus:outline-none"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_progressTimerPhoneNumberRequest__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        expireTime: props.expireTime,
                                        requestTime: props.reqTime,
                                        onProgressFinished: props.onProgressFinished,
                                        request: props.request
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        onClick: handleClick,
                                        className: "bg-red btn-page text-white text-center text-sm hover:bg-red-600 md:text-base w-full",
                                        children: "فعالسازی"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ price)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function price(props) {
    console.log(props.pricings);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.pricings.map((p)=>{
            if (p.currencyType == "USDT") {
                const price = p.amount.toLocaleString();
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: price
                });
            }
        })
    });
}


/***/ }),

/***/ 9068:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1599);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__]);
_services_clientAppService__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ProgressBarTimer = ({ expireTime , requestTime , onProgressFinished , request  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [finished, setFinished] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let currentTime = new Date().getTime();
    let expTime = new Date(expireTime).getTime();
    let reqTime = new Date(requestTime).getTime();
    let remain = expTime - currentTime;
    const [remainingTime, setRemainingTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(remain);
    const [finalProgress, setFinalProgress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(100);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setFinished(false);
        const interval = setInterval(()=>{
            setRemainingTime((prev)=>{
                let currentTime = new Date().getTime();
                let remain = expTime - currentTime;
                return remain;
            });
        }, 1000);
        return ()=>clearInterval(interval);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (remainingTime <= 0) {
            setFinished(true);
            setFinalProgress(0);
        } else {
            setFinalProgress((prev)=>{
                let vv = expTime - currentTime;
                let total = expTime - reqTime;
                let res = vv / total;
                return res;
            });
        }
    }, [
        remainingTime
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-grey rounded flex justify-end",
            style: {
                height: "10px",
                width: "100%"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-darkGreen rounded",
                style: {
                    height: "10px",
                    width: `${finalProgress * 100}%`
                }
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBarTimer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const authContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authContext);


/***/ }),

/***/ 1769:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_appServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7512);
/* harmony import */ var _components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1146);
/* harmony import */ var _components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(488);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3361);
/* harmony import */ var _components_Authorized__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2215);
/* harmony import */ var _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1599);
/* harmony import */ var _common_validator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2305);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1908);
/* harmony import */ var _components_PhoneNumberModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5544);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _common_appRoutes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1403);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_appServices__WEBPACK_IMPORTED_MODULE_2__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__, _components_PhoneNumberModal__WEBPACK_IMPORTED_MODULE_12__]);
([_services_appServices__WEBPACK_IMPORTED_MODULE_2__, _services_clientAppService__WEBPACK_IMPORTED_MODULE_8__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__, _components_PhoneNumberModal__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const paymentDetail = ({ result , golden , confirmPhoneNumber , authContext  })=>{
    if (authContext.authState.authenticated) {
        const goldenPackage = result;
        const [port, setPort] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("IRR");
        let confirmNumber = confirmPhoneNumber.phoneNumberConfirmed;
        const [ConfirmNumber, setConfirmNumber] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(confirmNumber);
        (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
            console.log(ConfirmNumber);
        }, [
            ConfirmNumber
        ]);
        function handleConfirm() {
            setConfirmNumber(true);
        }
        function handleChange(event) {
            setPort(event.target.value);
        }
        const handleClick = async ()=>{
            if (port == "IRR") {
                const res = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_8__/* .postOrderIRR */ .L0)(result.id, port);
            } else {
                const res = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_8__/* .postOrderUSDT */ .Rb)(result.id);
            }
        };
        const schema = _common_validator__WEBPACK_IMPORTED_MODULE_9__/* .validator.object */ .s.object({
            phoneNumber: _common_validator__WEBPACK_IMPORTED_MODULE_9__/* .validator.string */ .s.string().required("نوشتن تلفن همراه اجباری است")
        });
        const { register , handleSubmit , watch , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
            resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_11__.yupResolver)(schema)
        });
        const inputNumber = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
        const [openModal, setOpenModal] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
        const [expireTime, setExpireTime] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
        const [reqTime, setReqTime] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
        const [progressFinished, setProgressFinished] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
        const handleProgressFinished = ()=>{
            setProgressFinished(true);
            setProgressFinished(false);
        };
        (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
            if (expireTime != undefined) {
                const date1 = moment__WEBPACK_IMPORTED_MODULE_13___default()(expireTime);
                const date2 = moment__WEBPACK_IMPORTED_MODULE_13___default()();
                const duration = date1.diff(date2, "milliseconds");
                localStorage.setItem("PhoneNumberConfirm-expireTime", expireTime);
                setTimeout(()=>{
                    localStorage.removeItem("PhoneNumberConfirm-expireTime");
                    setOpenModal(false);
                }, duration);
            }
        }, [
            expireTime
        ]);
        async function handleClickModal() {
            const check = localStorage.getItem("PhoneNumberConfirm-expireTime");
            if (check == null) {
                const moment = __webpack_require__(2245);
                const number = inputNumber.current.value;
                console.log(number);
                const result = await (0,_services_clientAppService__WEBPACK_IMPORTED_MODULE_8__/* .ConfirmPhoneNumberRequest */ .WR)(number);
                console.log(result);
                if (result) {
                    setExpireTime(result.securityCodeExpiresAt);
                    setReqTime(moment().format());
                    setOpenModal(true);
                }
            } else {
                setOpenModal(true);
            }
        }
        function handleChildClick() {
            setOpenModal(false);
        }
        if (golden == false) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: "flex flex-col justify-center items-center gap-6 mt-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "darkBlue-color text-lg font-bold text-center div-mypackage",
                            children: "جزئیات پرداخت"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white w-4/5 md:w-1/3 rounded gap-1 justify-between p-5 div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex w-1/2 rounded justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        className: "rounded w-40",
                                        src: result.thumbnailImageUrl,
                                        width: 450,
                                        height: 450,
                                        quality: 100,
                                        alt: "picture"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col w-2/3 md:w-1/2 md:text-base text-xs items-center justify-evenly",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "grey-color",
                                            children: result.title
                                        }),
                                        port == "IRR" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "grey-color pt-3 flex gap-2",
                                            children: [
                                                "قیمت دوره: ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    pricings: result.pricings
                                                }),
                                                "تومان"
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "grey-color pt-3 flex gap-2",
                                            children: [
                                                "قیمت دوره: ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                    pricings: result.pricings
                                                }),
                                                " تتر"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        ConfirmNumber == false && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base justify-center items-center flex-col p-5 gap-3 w-4/5 md:w-1/3 rounded div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-gray-500",
                                    children: "شماره همراه خود را وارد کنید."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    className: "flex w-11/12 md:w-4/5 gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex-auto",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "phoneNumber",
                                                    ref: inputNumber,
                                                    type: "text",
                                                    required: true,
                                                    className: "rounded w-full py-3 px-3 text-black text-sm bg-grey darkgrey-color focus:outline-none"
                                                }),
                                                errors.phoneNumber?.message && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-red-500 text-xs mt-1",
                                                    children: errors.phoneNumber?.message
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PhoneNumberModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                            onClick: handleChildClick,
                                            expireTime: expireTime,
                                            reqTime: reqTime,
                                            onProgressFinished: handleProgressFinished,
                                            request: handleClickModal,
                                            confirmNumber: handleConfirm,
                                            text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                onClick: handleClickModal,
                                                className: "bg-darkBlue btn-page text-white text-center text-xs md:text-sm hover:bg-blue-950 whitespace-nowrap flex justify-center items-center h-full",
                                                children: "ارسال کد فعال سازی"
                                            }),
                                            setOpen: openModal
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base flex-col p-5 gap-3 w-4/5 md:w-1/3 rounded divide-y-2 div-mypackage divide-gray-300",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "darkBlue-color font-bold",
                                    children: "جزئیات سفارش"
                                }),
                                port == "IRR" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت دوره: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            pricings: result.pricings
                                        }),
                                        "تومان"
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت دوره: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            pricings: result.pricings
                                        }),
                                        " تتر"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3",
                                    children: [
                                        "درصد تخفیف: ",
                                        result.discount.discountValue,
                                        "%"
                                    ]
                                }),
                                port == "IRR" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت نهایی:",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            pricings: result.discount.finalAmounts
                                        }),
                                        " تومان"
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت نهایی: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            pricings: result.discount.finalAmounts
                                        }),
                                        " تتر"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base p-5 gap-5 w-4/5 md:w-1/3 rounded div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "darkBlue-color text-lg font-bold text-center",
                                    children: "روش پرداخت:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-center items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            defaultChecked: true,
                                            onChange: handleChange,
                                            type: "radio",
                                            value: "IRR",
                                            name: "typePort",
                                            id: "internalPort"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            for: "internalPort",
                                            className: "grey-color",
                                            children: "درگاه داخلی"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-center items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            onChange: handleChange,
                                            type: "radio",
                                            value: "USDT",
                                            name: "typePort",
                                            id: "crypto"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            for: "crypto",
                                            className: "grey-color",
                                            children: "کریپتو"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            onClick: handleClick,
                            className: "bg-red btn-page text-white text-center text-sm hover:bg-red-600 md:text-base w-4/5 md:w-1/3",
                            children: "پرداخت میکنم"
                        })
                    ]
                })
            });
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col justify-center items-center gap-6 mt-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "darkBlue-color text-lg font-bold text-center div-mypackage",
                            children: "جزئیات پرداخت"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white w-4/5 md:w-1/3 rounded gap-1 justify-between p-5 div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex w-1/2 rounded justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        className: "rounded w-40",
                                        src: goldenPackage[0].thumbnailUrl,
                                        width: 450,
                                        height: 450,
                                        quality: 100,
                                        alt: "picture"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col w-2/3 md:w-1/2 md:text-base text-xs items-center justify-evenly",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "grey-color",
                                            children: goldenPackage.name
                                        }),
                                        port == "IRR" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "grey-color pt-3 flex gap-2",
                                            children: [
                                                "قیمت دوره: ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    pricings: goldenPackage[0].courses[0].pricings
                                                }),
                                                "تومان"
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "grey-color pt-3 flex gap-2",
                                            children: [
                                                "قیمت دوره: ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                    pricings: goldenPackage[0].courses[0].pricings
                                                }),
                                                " تتر"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        ConfirmNumber == false && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base justify-center items-center flex-col p-5 gap-3 w-4/5 md:w-1/3 rounded div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-gray-500",
                                    children: "شماره همراه خود را وارد کنید."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    className: "flex w-11/12 md:w-4/5 gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex-auto",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "phoneNumber",
                                                    ref: inputNumber,
                                                    type: "text",
                                                    required: true,
                                                    className: "rounded w-full py-3 px-3 text-black text-sm bg-grey darkgrey-color focus:outline-none"
                                                }),
                                                errors.phoneNumber?.message && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-red-500 text-xs mt-1",
                                                    children: errors.phoneNumber?.message
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PhoneNumberModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                            onClick: handleChildClick,
                                            expireTime: expireTime,
                                            reqTime: reqTime,
                                            onProgressFinished: handleProgressFinished,
                                            request: handleClickModal,
                                            confirmNumber: handleConfirm,
                                            text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                onClick: handleClickModal,
                                                className: "bg-darkBlue btn-page text-white text-center text-xs md:text-sm hover:bg-blue-950 whitespace-nowrap flex justify-center items-center h-full",
                                                children: "ارسال کد فعال سازی"
                                            }),
                                            setOpen: openModal
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base flex-col p-5 gap-3 w-4/5 md:w-1/3 rounded divide-y-2 div-mypackage divide-gray-300",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "darkBlue-color font-bold",
                                    children: "جزئیات سفارش"
                                }),
                                port == "IRR" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت دوره: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IRRPrice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            pricings: goldenPackage[0].courses[0].pricings
                                        }),
                                        "تومان"
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "grey-color pt-3 flex gap-2",
                                    children: [
                                        "قیمت دوره: ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_USDTPrace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            pricings: goldenPackage[0].courses[0].pricings
                                        }),
                                        " تتر"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-white text-xs md:text-base p-5 gap-5 w-4/5 md:w-1/3 rounded div-mypackage",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "darkBlue-color text-lg font-bold text-center",
                                    children: "روش پرداخت:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-center items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            defaultChecked: true,
                                            onChange: handleChange,
                                            type: "radio",
                                            value: "IRR",
                                            name: "typePort",
                                            id: "internalPort"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "grey-color",
                                            children: "درگاه داخلی"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-center items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            onChange: handleChange,
                                            type: "radio",
                                            value: "USDT",
                                            name: "typePort",
                                            id: "crypto"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "grey-color",
                                            children: "کریپتو"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "bg-red btn-page text-white text-center text-sm md:text-base w-4/5 md:w-1/3 hover:bg-red-600",
                            children: "پرداخت میکنم"
                        })
                    ]
                })
            });
        }
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
};
async function getServerSideProps(context) {
    const res = context.query.slug;
    if (res != undefined) {
        if (res.length >= 2 && res[2] == "GoldenPackage") {
            const slug = `${res[0]}/${res[1]}`;
            const test = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_2__/* .getStatusPhoneNumber */ .QC)(context);
            if (test != undefined) {
                const confirmPhoneNumber = test;
                const result = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_2__/* .getGoldenPackage */ .Qp)(context);
                const golden = true;
                return {
                    props: {
                        result,
                        golden,
                        confirmPhoneNumber
                    }
                };
            } else {
                return {
                    props: {}
                };
            }
        } else {
            const slug = `${res[0]}/${res[1]}`;
            const test = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_2__/* .getStatusPhoneNumber */ .QC)(context);
            if (test != undefined) {
                const confirmPhoneNumber = test;
                const result = await (0,_services_appServices__WEBPACK_IMPORTED_MODULE_2__/* .courseDetail */ .or)(slug, context);
                const golden = false;
                return {
                    props: {
                        result,
                        golden,
                        confirmPhoneNumber
                    }
                };
            } else {
                return {
                    props: {}
                };
            }
        }
    } else {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_Authorized__WEBPACK_IMPORTED_MODULE_7__/* .withAuth */ .Q)(paymentDetail));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 2210:
/***/ ((module) => {

module.exports = import("@chakra-ui/react");;

/***/ }),

/***/ 1908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,675,403,85,512,599], () => (__webpack_exec__(1769)));
module.exports = __webpack_exports__;

})();