"use strict";
exports.id = 85;
exports.ids = [85];
exports.modules = {

/***/ 6896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// apiRoutes.js
const API_ROUTES = {
    LOGIN: "/Auth/SignIn",
    SIGN_UP: "/Auth/SingnUp",
    PACKAGES: "/Package",
    SELECTEDPACKAGE: "/Package/SelectedPackages",
    SIGN_OUT: "/Auth/Signout",
    PACKAGE: (slug)=>{
        return `/Package/${slug}`;
    },
    COURSE: (slug)=>{
        return `/Course/${slug}`;
    },
    VIDEO: (slug)=>`/Course/Videos/${slug}`,
    REFRESHTOKEN: "/Auth/RefreshToken",
    SITESETTING: "/setting",
    MYPROFILE: "/user/profile",
    CHANGEPASSWORD: "/User/ChangePassword",
    UPDATEMYPROFILE: "/user/profile",
    BANNER: "/Banner",
    FREEPACKAGE: "/Package/Free",
    GOLDENPACKAGE: "/Package/Golden",
    SEARCH: "/Search",
    MYCOURSES: "/Report/PurchasedCourses",
    ORDERHISTORY: "/Report/OrderHistory",
    ORDER: "/Order",
    SENDMESSAGES: "/Comment",
    NEWMESSAGE: "/Comment/ToAdmin",
    MESSAGEDETAIL: (id)=>{
        return `/Comment/${id}`;
    },
    RESETPASSWORDREQUEST: "/User/ResetPasswordRequest",
    RESETPASSWORD: "/User/ResetPassword",
    SEENMESSAGE: (id)=>{
        return `/Comment/SeenReply/${id}`;
    },
    STATUSPHONENUMBER: "/user/PhoneNumberStatus",
    CONFIRMPHONENUMBERREQUEST: "/User/ConfirmPhoneNumberRequest",
    CONFIRMPHONENUMBER: "/User/ConfirmPhoneNumber",
    ORDERHISRORYPDF: (id)=>{
        return `/Report/GetOrderHistoryPdf/${id}`;
    },
    SEARCHBYTAG: "/Search/ByTag"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (API_ROUTES);


/***/ }),

/***/ 9642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ Constants)
/* harmony export */ });
const Constants = {
    token: "accessToken",
    refreshToken: "refreshToken",
    tokenExpireTime: "accessTokenExpireTime",
    InstagramAddress: "InstagramAddress",
    WhatsAppAddress: "WhatsappNumber",
    TwitterAddress: "TwitterAddress",
    TelegramAddress: "TelegramChannelAddress",
    YouTubeChannelAddress: "YouTubeChannelAddress",
    MobileAppIOSDownloadLink: "MobileAppIOSLink",
    MobileAppAndroidDownloadLink: "MobileAndroidAppGooglePlayLink",
    MobileAppBazarDownloadLink: "MobileAppAndroidBazarLink"
};


/***/ }),

/***/ 5567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ handleApiError)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _appRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1403);


const handleApiError = (error, context)=>{
    console.log("_________________________________________________________________________________________________________");
    console.log(error);
    console.log("_____________________________________________________________________________________________________________");
    if (context == undefined || context.ctx == undefined) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon: "error",
            title: "خطا",
            text: "عدم امکان ارتباط با سرور",
            confirmButtonText: "باشه"
        });
        return "";
    }
    const res = context.ctx.res;
    if (error.response) {
        const status = error.response.status;
        const data = error.response.data;
        const errorMessage = data?.message ?? "عملیات با شکست مواجه شد";
        if (status === 401 && res != undefined && res != null) {
            console.log("get 401");
            res.writeHead(302, {
                Location: _appRoutes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].Login */ .Z.Login
            });
            res.end();
        } else if (status === 400) {
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                icon: "error",
                title: "خطا",
                text: data.errorMessages,
                confirmButtonText: "باشه"
            });
        } else {
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                icon: "error",
                title: "خطا",
                text: errorMessage,
                confirmButtonText: "باشه"
            });
        }
    } else {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon: "error",
            title: "خطا",
            text: "عدم امکان ارتباط با سرور",
            confirmButtonText: "باشه"
        });
    }
};


/***/ }),

/***/ 643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ pushAlert)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _appRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1403);


const pushAlert = (result)=>{
    const { message , type  } = result;
    switch(type){
        case "success":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "success",
                    title: "موفق",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
        case "error":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "error",
                    title: "خطا",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
        case "warning":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "warning",
                    title: "هشدار",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
    }
};


/***/ }),

/***/ 457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Configs)
/* harmony export */ });
const isDevelopment = "production" !== "production";
const Configs = {
    serverSideUrl: isDevelopment ? "https://api.lingo4030.com/api/v1" : "http://127.0.0.1:5004/api/v1",
    // serverSideUrl:isDevelopment?"https://127.0.0.1:5004/api/v1":"http://127.0.0.1:5004/api/v1",
    clientSideUrl: isDevelopment ? "https://api.lingo4030.com/api/v1" : "https://api.lingo4030.com/api/v1"
};


/***/ })

};
;