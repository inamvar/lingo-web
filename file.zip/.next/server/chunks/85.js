"use strict";
exports.id = 85;
exports.ids = [85];
exports.modules = {

/***/ 6896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// apiRoutes.js
const API_ROUTES = {
    LOGIN: "/Auth/SignIn",
    SIGN_UP: "/Auth/SingnUp",
    PACKAGES: "/Package",
    SIGN_OUT: "/Auth/Signout",
    PACKAGE: (slug)=>{
        return `/Package/${slug}`;
    },
    COURSE: (slug)=>{
        return `/Course/${slug}`;
    },
    VIDEO: (slug)=>`/Course/Videos/${slug}`,
    REFRESHTOKEN: "/Auth/RefreshToken",
    SITESETTING: "/setting",
    MYPROFILE: "/user/profile",
    UPDATEMYPROFILE: "/user/profile",
    BANNER: "/Banner"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (API_ROUTES);


/***/ }),

/***/ 1403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const AppRoutes = {
    Signup: "/auth/signup",
    Login: "/auth/login",
    LoginReturn: (url)=>{
        return `auth/login?returnUrl=${url}`;
    },
    Main: "/",
    ForgotPassword: "/auth/forgot-password",
    Profile: "/dashboard/myProfile",
    Dashboard: "/dashboard",
    Package: (slug)=>{
        return `/package/${slug}`;
    },
    Course: (slug)=>{
        return `/package/course/${slug}`;
    },
    DetailCourse: "/package/course/courseEpisodes",
    Video: (slug)=>{
        return `/package/course/courseEpisodes/${slug}`;
    },
    Cart: "/dashboard/cart",
    MyPackages: "/dashboard/myPackages",
    MyProfile: "/dashboard/myProfile",
    MyTransactions: "/dashboard/myTransactions"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppRoutes);


/***/ }),

/***/ 9642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ Constants)
/* harmony export */ });
const Constants = {
    token: "accessToken",
    refreshToken: "refreshToken",
    InstagramAddress: "InstagramAddress",
    WhatsAppAddress: "WhatsappAddress",
    TwitterAddress: "TwitterAddress",
    TelegramAddress: "TelegramAddress",
    FooterDescription: "FooterDescription"
};


/***/ }),

/***/ 5567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ handleApiError)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _appRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1403);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



const handleApiError = (error, context)=>{
    if (context == undefined || context.ctx == undefined) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon: "error",
            title: "خطا",
            text: "عدم امکان ارتباط با سرور",
            confirmButtonText: "باشه"
        });
        return;
    }
    console.log("gggggggggggggggggggggggggg");
    console.log(context.ctx.req);
    console.log("cvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv");
    const req = context.ctx.req;
    const res = context.ctx.res;
    const currentUrl = req.url;
    console.log("currentUrl");
    console.log(currentUrl);
    console.log("currentUrl");
    if (error.response) {
        const { status , data  } = error.response;
        console.log(status);
        console.log(data);
        const errorMessage = data?.message ?? "عملیات با شکست مواجه شد";
        if (status === 401 && res != undefined && res != null) {
            // if (currentUrl!=undefined){
            //     res.writeHead(302, { Location: appRoutes.LoginReturn(currentUrl) });
            //     res.end();
            // }
            // else{
            res.writeHead(302, {
                Location: _appRoutes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].Login */ .Z.Login
            });
            res.end();
        // }
        } else if (status === 400) {
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                icon: "error",
                title: "خطا",
                text: data.errorMessages,
                confirmButtonText: "باشه"
            });
        } else {
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                icon: "error",
                title: "خطا",
                text: errorMessage,
                confirmButtonText: "باشه"
            });
        }
    } else {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon: "error",
            title: "خطا",
            text: "عدم امکان ارتباط با سرور",
            confirmButtonText: "باشه"
        });
    }
};


/***/ }),

/***/ 643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ pushAlert)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _appRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1403);


const pushAlert = (result)=>{
    const { message , type  } = result;
    switch(type){
        case "success":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "success",
                    title: "موفق",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
        case "error":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "error",
                    title: "خطا",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
        case "warning":
            {
                sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
                    icon: "warning",
                    title: "هشدار",
                    text: message,
                    confirmButtonText: "تایید"
                });
                break;
            }
    }
};


/***/ }),

/***/ 457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Configs)
/* harmony export */ });
const isDevelopment = "production" !== "production";
const Configs = {
    serverSideUrl: isDevelopment ? "https://127.0.0.1:5004/api/v1" : "http://127.0.0.1:5004/api/v1",
    // serverSideUrl:isDevelopment?"https://127.0.0.1:5004/api/v1":"http://127.0.0.1:5004/api/v1",
    clientSideUrl: isDevelopment ? "https://127.0.0.1:5004/api/v1" : "http://45.92.93.170:5004/api/v1"
};


/***/ })

};
;