exports.id = 485;
exports.ids = [485];
exports.modules = {

/***/ 1146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ price)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function price(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.pricings.map((p)=>{
            if (p.currencyType == "IRR") {
                const price = (p.amount / 10).toLocaleString();
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: price
                });
            }
        })
    });
}


/***/ }),

/***/ 2557:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ courseMultiItemCarousel)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-multi-carousel"
var external_react_multi_carousel_ = __webpack_require__(5804);
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_);
// EXTERNAL MODULE: ./node_modules/react-multi-carousel/lib/styles.css
var styles = __webpack_require__(2694);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./common/appRoutes.js
var appRoutes = __webpack_require__(1403);
// EXTERNAL MODULE: ./components/IRRPrice.js
var IRRPrice = __webpack_require__(1146);
;// CONCATENATED MODULE: ./components/courseCarouselItem.jsx





function CourseCarouselItem(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        className: "item-size flex justify-center",
        href: appRoutes/* default.Course */.Z.Course(props.slug),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                width: "90%"
            },
            className: "flex flex-col rounded-xl bg-white p-3 w-full h-full justify-between gap-3",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        height: "80%"
                    },
                    className: "relative w-full flex justify-center items-center overflow-hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center items-center h-full max-h-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            quality: 100,
                            className: "h-auto w-auto max-h-full max-w-full rounded",
                            alt: "picture",
                            height: 900,
                            width: 900,
                            src: props.picture
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    style: {
                        height: "20%"
                    },
                    className: "flex flex-col items-center justify-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "grey-color",
                            children: props.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "grey-color",
                            children: props.title
                        }),
                        props.costType == "Free" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "grey-color flex gap-2 border-gray-200 pt-2 mt-2 pb-1 border-t-2 w-full justify-center",
                            children: "رایگان"
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "green-color flex gap-2 border-gray-200 pt-2 mt-2 pb-1 border-t-2 w-full justify-center",
                            children: [
                                "تومان",
                                /*#__PURE__*/ jsx_runtime_.jsx(IRRPrice/* default */.Z, {
                                    pricings: props.pricings
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/courseMultiItemCarousel.jsx





const CourseMultiItemCarousel = ({ courses  })=>{
    console.log(courses);
    const [dragging, setDragging] = (0,external_react_.useState)(false);
    const responsive = {
        screen: {
            breakpoint: {
                max: 3000,
                min: 1600
            },
            items: 4,
            slidesToSlide: 1
        },
        desktop: {
            breakpoint: {
                max: 1600,
                min: 1200
            },
            items: 3,
            slidesToSlide: 1
        },
        tablet: {
            breakpoint: {
                max: 1200,
                min: 760
            },
            items: 2,
            slidesToSlide: 1
        },
        mobile: {
            breakpoint: {
                max: 760,
                min: 1
            },
            items: 1,
            slidesToSlide: 1
        }
    };
    const handleDragStart = ()=>{
        setDragging(true);
    };
    const handleDragEnd = ()=>{
        setDragging(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_multi_carousel_default()), {
        className: "flex flex-row",
        swipeable: true,
        draggable: false,
        showDots: false,
        responsive: responsive,
        ssr: true,
        infinite: true,
        autoPlay: false,
        keyBoardControl: true,
        customTransition: "transform 600ms ease-in-out",
        transitionDuration: 600,
        containerClass: "carousel-container",
        // removeArrowOnDeviceType={["tablet", "mobile"]}
        itemClass: "multi-pack-item",
        rtl: true,
        children: courses.map((i)=>/*#__PURE__*/ jsx_runtime_.jsx(CourseCarouselItem, {
                id: i.id,
                costType: i.costType,
                name: i.name,
                title: i.title,
                picture: i.thumbnailImageUrl,
                pricings: i.pricings,
                slug: i.slug
            }))
    });
};
/* harmony default export */ const courseMultiItemCarousel = (CourseMultiItemCarousel);


/***/ }),

/***/ 2368:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const headerContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (headerContext);


/***/ }),

/***/ 2694:
/***/ (() => {



/***/ })

};
;