"use strict";
exports.id = 599;
exports.ids = [599];
exports.modules = {

/***/ 4140:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _configs_configs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(457);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9642);
/* harmony import */ var _appRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1403);
/* harmony import */ var _apiRoutes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6896);
/* harmony import */ var _handleApiError__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5567);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const ax = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _configs_configs__WEBPACK_IMPORTED_MODULE_1__/* .Configs.clientSideUrl */ .z.clientSideUrl,
    httpsAgent: new (https__WEBPACK_IMPORTED_MODULE_2___default().Agent)({
        rejectUnauthorized: false
    })
});
ax.interceptors.request.use(function(config) {
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_3__.parseCookies)(config.ctx);
    const token = cookies[_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.token */ .g.token];
    if (token) {
        config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
}, function(error) {
    return Promise.reject(error);
});
// ax.interceptors.response.use(
//     (response) => {
//             return response;
//     },
//     async (error) => {
//
//         if (error!=null && error!=undefined && error.res!=undefined){
//             const originalRequest = error.res;
//         }
//
//
//         const res = error.config.ctx.res;
//         const cookies = parseCookies(error.config.ctx);
//         const refreshToken = cookies[Constants.refreshToken];
//         if (error.response.status === 401) {
//             if (!refreshToken) {
//                 // If there is no refresh token, redirect to the login page
//
//                 res.writeHead(302, { Location: appRoutes.Login });
//                 res.end();
//                 return Promise.reject(error);
//             }
//
//             try {
//                 const response = await ax.post(API_ROUTES.REFRESHTOKEN,{ refreshToken: refreshToken }
//                 );
//
//                 const { accessToken } = response.data;
//
//                 // Update the access token in cookies and the axios instance headers
//                 setCookie(error.config.ctx, Constants.token, accessToken, {
//                     expires:399999
//                 });
//                 ax.defaults.headers.common.Authorization = `Bearer ${accessToken}`;
//
//                 // Retry the original request with the new access token
//                 originalRequest.headers.Authorization = `Bearer ${accessToken}`;
//                 return ax(originalRequest);
//             } catch (error) {
//
//                 //destroyCookie(error.config.ctx,Constants.token);
//                 // If there is an error while getting a new access token, redirect to the login page
//                 res.writeHead(302, { Location: appRoutes.Login });
//                 res.end();
//                 return Promise.reject(error);
//             }
//         } else {
//             // Handle other errors using the handleApiError function
//             handleApiError(error);
//             return Promise.reject(error);
//         }
//     }
// );
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ax);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SA": () => (/* binding */ signUpUser),
/* harmony export */   "df": () => (/* binding */ getSiteSetting),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "lF": () => (/* binding */ updateMyProfile),
/* harmony export */   "pH": () => (/* binding */ loginUser)
/* harmony export */ });
/* harmony import */ var _common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6896);
/* harmony import */ var _common_handleApiError__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5567);
/* harmony import */ var _common_notifier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(643);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9642);
/* harmony import */ var _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4140);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__, js_cookie__WEBPACK_IMPORTED_MODULE_6__]);
([_common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__, js_cookie__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const getSiteSetting = async (context)=>{
    try {
        const response = await _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SITESETTING */ .Z.SITESETTING, {
            ctx: context
        });
        if (response.data.success == true) {
            const result = response.data.data;
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const signUpUser = async (firstname, lastname, password, confirmPassword, email, phoneNumber, marketerCode)=>{
    try {
        let response = await _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__/* ["default"].post */ .Z.post(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SIGN_UP */ .Z.SIGN_UP, {
            confirmPassword: confirmPassword,
            email: email,
            firstName: firstname,
            lastName: lastname,
            password: password,
            phoneNumber: phoneNumber,
            marketerCode: marketerCode
        });
        if (response.data.success == true) {
            const { accessToken , refreshToken  } = response.data.data.authToken;
            const decodedToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().decode(accessToken);
            const remainingTime = decodedToken.exp - Date.now() / 1000;
            js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].set(_common_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.token */ .g.token, accessToken, {
                expires: remainingTime / (60 * 60 * 24)
            });
            js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].set(_common_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.refreshToken */ .g.refreshToken, refreshToken, {
                expires: 365
            });
            // pushAlert({
            //     message:'ثبت نام با موفقیت انجام شد',
            //     type:'success'
            // })
            return {
                authenticated: true,
                user: decodedToken
            };
        } else {
            console.log(response.data.message);
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
        }
    } catch (error) {
        console.log(error.response);
        if (error.response.status == "400" || error.response.status == "404") {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: error.response.data.errorMessages,
                type: "error"
            });
        }
    }
};
const loginUser = async (username, password)=>{
    try {
        let response = await _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__/* ["default"].post */ .Z.post(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].LOGIN */ .Z.LOGIN, {
            userName: username,
            password: password
        });
        if (response.data.success == true) {
            const { accessToken , refreshToken  } = response.data.data;
            const decodedToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().decode(accessToken);
            const remainingTime = decodedToken.exp - Date.now() / 1000;
            js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].set(_common_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.token */ .g.token, accessToken, {
                expires: remainingTime / (60 * 60 * 24)
            });
            js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].set(_common_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.refreshToken */ .g.refreshToken, refreshToken, {
                expires: 365
            });
            //
            // pushAlert({
            //     message:'ورود با موفقیت انجام شد',
            //     type:'success'
            // })
            return {
                authenticated: true,
                user: decodedToken
            };
        } else {
            console.log(response.data.message);
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
        }
    } catch (error) {
        (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
            message: error.response.data.errorMessages,
            type: "error"
        });
        console.log(error);
    }
};
const updateMyProfile = async (input, ctx)=>{
    try {
        const response = await _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__/* ["default"].put */ .Z.put(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].UPDATEMYPROFILE */ .Z.UPDATEMYPROFILE, {
            firstName: input.firstName,
            lastName: input.lastName,
            phoneNumber: input.phoneNumber
        }, {
            ctx: ctx
        });
        if (response.data.success == true) {
            const result = response.data.data;
            console.log(result);
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        console.log(error);
    }
};
const logout = async ()=>{
    const response = await _common_apiClientSideRequest__WEBPACK_IMPORTED_MODULE_5__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SIGN_OUT */ .Z.SIGN_OUT);
    if (response.status == 200) {
        console.log(response);
        js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].remove("accessToken");
        js_cookie__WEBPACK_IMPORTED_MODULE_6__["default"].remove("refreshToken");
        return true;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;