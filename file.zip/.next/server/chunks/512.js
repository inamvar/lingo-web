"use strict";
exports.id = 512;
exports.ids = [512];
exports.modules = {

/***/ 3174:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _configs_configs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(457);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9642);
/* harmony import */ var _handleApiError__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5567);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ax = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _configs_configs__WEBPACK_IMPORTED_MODULE_1__/* .Configs.serverSideUrl */ .z.serverSideUrl,
    httpsAgent: new (https__WEBPACK_IMPORTED_MODULE_2___default().Agent)({
        rejectUnauthorized: false
    })
});
let isRefreshing = false;
let refreshSubscribers = (/* unused pure expression or super */ null && ([]));
ax.interceptors.request.use(async (config)=>{
    const cookies = nookies__WEBPACK_IMPORTED_MODULE_3___default().get(config.ctx);
    const refreshToken = cookies[_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.refreshToken */ .g.refreshToken];
    const accessTokenExpires = cookies[_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.tokenExpireTime */ .g.tokenExpireTime];
    if (accessTokenExpires) {
        if (await isTokenExpired(accessTokenExpires) === true) {
            console.log("token is expired");
            if (!isRefreshing) {
                isRefreshing = true;
                try {
                    const refreshTokenResult = await refreshAccessToken(refreshToken);
                    console.log("refreshToken Result is:");
                    console.log(refreshTokenResult);
                    if (refreshTokenResult == null) {
                        console.log("refreshToken NotFound");
                        return config;
                    }
                    console.log("decoding");
                    const decodedToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_6___default().decode(refreshTokenResult.accessToken);
                    const remainingTime = decodedToken.exp - Date.now() / 1000;
                    console.log(remainingTime);
                    console.log("setting cookies");
                    nookies__WEBPACK_IMPORTED_MODULE_3___default().set(config.ctx, _constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.token */ .g.token, refreshTokenResult.accessToken, {
                        maxAge: remainingTime,
                        path: "/"
                    });
                    nookies__WEBPACK_IMPORTED_MODULE_3___default().set(config.ctx, _constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.refreshToken */ .g.refreshToken, refreshTokenResult.refreshToken, {
                        maxAge: 365,
                        path: "/"
                    });
                    nookies__WEBPACK_IMPORTED_MODULE_3___default().set(config.ctx, _constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.tokenExpireTime */ .g.tokenExpireTime, refreshTokenResult.accessTokenExpiresAt, {
                        maxAge: 365,
                        path: "/"
                    });
                    console.log("cookies seted");
                    config.headers["Authorization"] = `Bearer ${refreshTokenResult.accessToken}`;
                    isRefreshing = false;
                } catch (error) {
                    (0,_handleApiError__WEBPACK_IMPORTED_MODULE_5__/* .handleApiError */ .z)(error);
                    isRefreshing = false;
                    return config;
                }
            }
        } else {
            const token = cookies[_constants__WEBPACK_IMPORTED_MODULE_4__/* .Constants.token */ .g.token];
            console.log("token is not expired");
            config.headers["Authorization"] = `Bearer ${token}`;
        }
    }
    return config;
}, function(error) {
    console.log("--- request rejected ---");
    return Promise.reject(error);
});
async function isTokenExpired(token) {
    try {
        const expDate = new Date(token);
        const newExpDate = expDate;
        const utcExp = newExpDate.toUTCString();
        console.log(utcExp);
        const currentDate = new Date();
        const currentUtc = currentDate.toUTCString();
        console.log(currentUtc);
        var result = currentUtc >= utcExp;
        console.log("is Token expired:" + result);
        return result;
    } catch (e) {
        console.log("checking is tokenexpired got error");
        console.log(e);
        return false;
    }
}
async function refreshAccessToken(refreshToken) {
    try {
        const response = await ax.post("/Auth/RefreshToken", {
            refreshToken
        });
        if (response.data.success == true) {
            const { accessToken , refreshToken , accessTokenExpiresAt  } = response.data.data;
            return {
                accessToken,
                refreshToken,
                accessTokenExpiresAt
            };
        } else {
            return null;
        }
    } catch (error) {
        return null;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ax);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7512:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Eg": () => (/* binding */ getBanner),
/* harmony export */   "O2": () => (/* binding */ getVideoDetail),
/* harmony export */   "QC": () => (/* binding */ getStatusPhoneNumber),
/* harmony export */   "Qp": () => (/* binding */ getGoldenPackage),
/* harmony export */   "Rp": () => (/* binding */ getSendMessages),
/* harmony export */   "SM": () => (/* binding */ getOrderHistory),
/* harmony export */   "Sz": () => (/* binding */ getBestPackages),
/* harmony export */   "UB": () => (/* binding */ getBestSellingPackages),
/* harmony export */   "US": () => (/* binding */ getMyProfile),
/* harmony export */   "Xt": () => (/* binding */ getMessageDetail),
/* harmony export */   "_w": () => (/* binding */ getMyCoursesList),
/* harmony export */   "aK": () => (/* binding */ getPackageCourseList),
/* harmony export */   "cf": () => (/* binding */ getSelectedPackagesList),
/* harmony export */   "hk": () => (/* binding */ getFreePackagesList),
/* harmony export */   "nu": () => (/* binding */ getOrderHistoryPDF),
/* harmony export */   "or": () => (/* binding */ courseDetail),
/* harmony export */   "r_": () => (/* binding */ getMyPassword),
/* harmony export */   "sf": () => (/* binding */ getPackagesList)
/* harmony export */ });
/* harmony import */ var _common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6896);
/* harmony import */ var _common_handleApiError__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5567);
/* harmony import */ var _common_notifier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(643);
/* harmony import */ var _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3174);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__]);
_common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// export const getFreePackagesList = async (context) =>
// {
//     try
//     {
//         console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
//         let response = await ax.get(API_ROUTES.FREEPackage,{ctx:context});
//         console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
//         console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",response);
//         console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
//
//         if (response.data.success == true)
//         {
//             const packages = response.data.data.data;
//             return packages;
//         }
//         else {
//             pushAlert({message:response.data.message,type:'error'});
//             return null;
//         }
//     }
//     catch (error)
//     {
//         console.log("222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222");
//         handleApiError(error);
//     }
// }
const getOrderHistoryPDF = async (orderId, context)=>{
    try {
        console.log(orderId);
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].ORDERHISRORYPDF */ .Z.ORDERHISRORYPDF(orderId), {
            ctx: context,
            responseType: "blob"
        });
        if (response.status == 200) {
            return response.data;
        }
    } catch (error) {
        console.log(error);
    // pushAlert({
    //     message: error.response.data.errorMessages,
    //     type: 'error'
    // })
    }
};
const getOrderHistory = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].ORDERHISTORY */ .Z.ORDERHISTORY, {
            ctx: context
        });
        console.log(response);
        if (response.data.success == true) {
            const history = response.data.data.data;
            return history;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getMyCoursesList = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].MYCOURSES */ .Z.MYCOURSES, {
            ctx: context
        });
        if (response.data.success == true) {
            const packages = response.data.data.data;
            return packages;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getGoldenPackage = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].GOLDENPACKAGE */ .Z.GOLDENPACKAGE);
        if (response.data.success == true) {
            const packages = response.data.data.data;
            return packages;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getFreePackagesList = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].FREEPACKAGE */ .Z.FREEPACKAGE, {
            ctx: context
        });
        if (response.data.success == true) {
            const packages = response.data.data.data;
            return packages;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getSelectedPackagesList = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SELECTEDPACKAGE */ .Z.SELECTEDPACKAGE, {
            ctx: context
        });
        if (response.data.success == true) {
            const packages = response.data.data.data;
            return packages;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getPackagesList = async (context)=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].PACKAGES */ .Z.PACKAGES, {
            ctx: context
        });
        if (response.data.success == true) {
            const packages = response.data.data.data;
            return packages;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getSendMessages = async (context)=>{
    try {
        let response = await (0,_common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
            method: "get",
            url: _common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SENDMESSAGES */ .Z.SENDMESSAGES,
            data: {},
            ctx: context
        });
        if (response.data.success == true) {
            const res = response.data.data.data;
            return res;
        }
    // let response = await ax.get(API_ROUTES.SENDMESSAGES,{ctx:context});
    // console.log(response);
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getMessageDetail = async (id, ctx)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].MESSAGEDETAIL */ .Z.MESSAGEDETAIL(id), {
            ctx: ctx
        });
        if (response.data.success == true) {
            const detail = response.data.data;
            return detail;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, ctx);
    }
};
const getPackageCourseList = async (slug, ctx)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].PACKAGE */ .Z.PACKAGE(slug), {
            ctx: ctx
        });
        if (response.data.success == true) {
            const courses = response.data.data.data;
            return courses;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, ctx);
    }
};
const getBestSellingPackages = async ()=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SEARCHBYTAG */ .Z.SEARCHBYTAG, {
            params: {
                Filter: "پرفروش"
            }
        });
        if (response.status == 200) {
            const result = response.data.data.data;
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error);
    }
};
const getBestPackages = async ()=>{
    try {
        let response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].SEARCHBYTAG */ .Z.SEARCHBYTAG, {
            params: {
                Filter: "برتر"
            }
        });
        if (response.status == 200) {
            const result = response.data.data.data;
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error);
    }
};
const getStatusPhoneNumber = async (context)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].STATUSPHONENUMBER */ .Z.STATUSPHONENUMBER, {
            ctx: context
        });
        if (response.data.success == true) {
            const data = response.data.data;
            return data;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const courseDetail = async (slug, context)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].COURSE */ .Z.COURSE(slug), {
            ctx: context
        });
        if (response.data.success == true) {
            const course = response.data.data;
            console.log(course);
            return course;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getVideoDetail = async (slug, context)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].VIDEO */ .Z.VIDEO(slug), {
            ctx: context
        });
        if (response.data.success == true) {
            const course = response.data.data;
            return course;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};
const getMyProfile = async (ctx)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].MYPROFILE */ .Z.MYPROFILE, {
            ctx: ctx
        });
        if (response.data.success == true) {
            const result = response.data.data;
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, ctx);
    }
};
const getMyPassword = async (ctx)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].CHANGEPASSWORD */ .Z.CHANGEPASSWORD, {
            ctx: ctx
        });
        if (response.data.success == true) {
            const result = response.data.success;
            return result;
        } else {
            (0,_common_notifier__WEBPACK_IMPORTED_MODULE_2__/* .pushAlert */ .V)({
                message: response.data.message,
                type: "error"
            });
            return null;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, ctx);
    }
};
const getBanner = async (context)=>{
    try {
        const response = await _common_apiServerSideRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(_common_apiRoutes__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BANNER */ .Z.BANNER);
        if (response.data.success == true) {
            const result = response.data.data;
            return result;
        }
    } catch (error) {
        (0,_common_handleApiError__WEBPACK_IMPORTED_MODULE_1__/* .handleApiError */ .z)(error, context);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;