"use strict";
(() => {
var exports = {};
exports.id = 635;
exports.ids = [635];
exports.modules = {

/***/ 4914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ discount_discount)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./public/picture/discount.png
/* harmony default export */ const discount = ({"src":"/_next/static/media/discount.f9c1f8b7.png","height":663,"width":665,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA20lEQVR42mMAgfcZ2Uwg+ktbJzMDFDxmYACxEeANA0PGWwaGE+9cPI+9ZmCoBIk9Z2BgZACB9yHhyR9Ky/9/O3jw/7d9+/+/yc77/5SBoZ4BBt5Fx535ef3G/28XL/16N2v2zxcFRf8fMTBcYQCBj1OmsjxnYLn8qrD4/6fde/78vH//14vG5v/3GBgePi0sFmIAgSem1oUPGBj+v1mx6v/zOXP/33Ny/n9Nz7CUAQYeSalwP9A3r7rFwPDkrrTwmgc+blYg8VcgRz5U1mFkgIL3S+bzMkDBB6gPABbXXSBn8QBzAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/meta.jsx
var meta = __webpack_require__(9161);
;// CONCATENATED MODULE: ./pages/discount/index.jsx




function discount_discount() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(meta/* default */.Z, {
                title: "تخفیفات"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col justify-center items-center gap-7",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: discount,
                        alt: "pic",
                        width: 400,
                        height: 400,
                        quality: 100
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "darkBlue-color font-bold text-lg",
                        children: "تخفیف های لینگو"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-center items-center gap-4 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-1/3 flex justify-end",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-paleRed rounded-xl w-80 p-5 ",
                                            children: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است."
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-center items-center w-1/8",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "bg-red rounded-full absolute red-color w-5 h-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                className: "m-h-discount border border-red"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "darkBlue-color font-bold text-lg w-1/3",
                                        children: "%20"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-center items-center gap-4 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "darkBlue-color font-bold text-lg w-1/3 text-left",
                                        children: "%30"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex justify-center items-center w-1/8",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "bg-red rounded-full absolute red-color w-5 h-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                className: "m-h-discount border border-red"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-1/3 flex justify-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-paleRed rounded-xl w-80 p-5 ",
                                            children: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است."
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-center items-center gap-4 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-1/3 flex justify-end",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-paleRed rounded-xl w-80 p-5 ",
                                            children: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است."
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex justify-center items-center w-1/8",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "bg-red rounded-full absolute red-color w-5 h-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                className: "m-h-discount border border-red"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "darkBlue-color font-bold text-lg w-1/3",
                                        children: "%40"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-center items-center gap-4 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "darkBlue-color font-bold text-lg w-1/3 text-left",
                                        children: "%50"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex justify-center items-center w-1/8",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "bg-red rounded-full absolute red-color w-5 h-5"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                className: "m-h-discount border border-red"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-1/3 flex justify-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-paleRed rounded-xl w-80 p-5 ",
                                            children: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است."
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,675,161], () => (__webpack_exec__(4914)));
module.exports = __webpack_exports__;

})();